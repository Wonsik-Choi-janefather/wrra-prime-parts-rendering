"""Isolated 0.6–0.10 compute/verifier replay without modifying inherited files."""
from pathlib import Path
import tempfile,zipfile,shutil,subprocess,os,json,hashlib
from replay_early import compare
ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent
def main():
 env=dict(os.environ,OPENBLAS_NUM_THREADS='1');out=[]
 for i in range(6,11):
  with tempfile.TemporaryDirectory() as tmp:
   dest=Path(tmp)/f'stage_0_{i}'
   if i==6:
    with zipfile.ZipFile(ROOT/'upstream_snapshots/WRRA_Parts_Followup_0_6_Reproducibility.zip') as z:z.extractall(tmp)
    source=Path(tmp)/'parts_followup_0_6';dest=source
    original=ROOT/'source_snapshots/0_6_results.json'
   else:
    source=ROOT/'stages'/f'0_{i}'
    dest.mkdir()
    for f in source.iterdir():
     if f.is_file() and f.suffix!='.zip':shutil.copy(f,dest/f.name)
    original=ROOT/'source_snapshots'/f'0_{i}_results.json'
   base=json.loads(original.read_text())
   row=dict(stage=f'0.{i}',original_sha256=hashlib.sha256(original.read_bytes()).hexdigest())
   for script in ['compute.py','verify_release.py' if i==6 else 'verify.py']:
    cmd=subprocess.run(['python3',script],cwd=dest,env=env,capture_output=True,text=True,timeout=180)
    row[script+'_returncode']=cmd.returncode
    row[script+'_tail']=(cmd.stdout+cmd.stderr)[-450:]
    if cmd.returncode:break
   if row.get('compute.py_returncode')==0:
    new=json.loads((dest/'results.json').read_text())
    row['first_difference']=compare(base,new)
    row['replayed_sha256']=hashlib.sha256((dest/'results.json').read_bytes()).hexdigest()
   else:row['first_difference']='run_failed'
   out.append(row)
   print(json.dumps({k:v for k,v in row.items() if not k.endswith('_tail')}),flush=True)
 (ROOT/'late_replay.json').write_text(json.dumps(out,indent=2)+'\n')
 if any(z['first_difference'] is not None or any(v!=0 for k,v in z.items() if k.endswith('_returncode')) for z in out):raise SystemExit(1)
if __name__=='__main__':main()
