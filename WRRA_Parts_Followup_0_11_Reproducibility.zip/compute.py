"""Cross-stage typed reconciliation of WRRA prime-parts followups 0.1–0.10.

Preserves the address, finite-pool and selected-six-baryon denominators. It
does not splice the selected photon-absorption module into the whole pool.
"""
from pathlib import Path
import json,csv,hashlib,math
from dataclasses import dataclass
P=Path(__file__).resolve().parent;S=P/'source_snapshots'
R={i:json.loads((S/f'0_{i}_results.json').read_text()) for i in range(1,11)}
def rows(name):
 with (S/name).open() as f:return list(csv.DictReader(f))
def close(a,b,abs_tol=2e-6,rel_tol=2e-11):return math.isclose(float(a),float(b),abs_tol=abs_tol,rel_tol=rel_tol)
def one(items,**wanted):
 found=[z for z in items if all(str(z[k])==str(v) if k in ['K','order','mode'] else close(z[k],v) for k,v in wanted.items())]
 if len(found)!=1:raise AssertionError((wanted,len(found)))
 return found[0]
@dataclass(frozen=True)
class Quantity:
 value:float
 kind:str
 unit:str
 denominator:str
 assembly:str
 def __add__(self,other):
  if (self.kind,self.unit,self.denominator,self.assembly)!=(other.kind,other.unit,other.denominator,other.assembly):
   raise ValueError('typed ledger incompatible: kind/unit/denominator/assembly')
  return Quantity(self.value+other.value,self.kind,self.unit,self.denominator,self.assembly)
checks={}
def check(k,ok):
 checks[k]=bool(ok)
 if not ok:raise AssertionError(k)
def main():
 q=[R[i][key] for i,key in [(1,'beta_Q_MeV'),(2,'beta_Q_MeV'),(3,'Q_MeV'),(4,'Q_MeV'),(5,'binding_inputs_and_outputs_MeV'),(6,'beta_Q_MeV')]]
 q[4]=q[4]['beta_Q'];m=R[6]['inherited_masses_MeV'];mn,mp,me=m['neutron'],m['proton'],m['electron']
 for i,x in enumerate(q,1):check(f'beta_Q_stage_{i}',close(x,mn-mp-me,abs_tol=3e-11))
 for i in range(1,6):
  a=R[i]['verified_inputs'];check(f'arithmetic_stage_{i}',a['N']==1_000_000 and a['alpha']==R[1]['verified_inputs']['alpha'] and a['beta']==R[1]['verified_inputs']['beta'] and a['neutron_component_labels']==[5,47])
  check(f'mass_and_lifetime_stage_{i}',a['recorded_rest_energies_MeV']=={'proton':mp,'neutron':mn,'electron':me} and a['neutron_mean_life_s']==878.3)
 check('finite_addresses',R[1]['addresses']==421502)
 check('filter_conditioned_fraction',close(R[1]['filter_weight'],.05,abs_tol=1e-12))
 supply=one(R[4]['source_comparison'],K=15,order='small')
 pool=one(rows('0_5_finite_pool_grid.csv'),K=15,order='small',capture_ratio=100,fusion_ratio=100,time_s=180)
 release=one(rows('0_6_release_grid.csv'),K=15,order='small',mode='finite_pool',capture_ratio=100,fusion_ratio=100,time_s=180,eta=0)
 B=1_000_000;active=int(pool['active_initial_B']);N=int(pool['initial_n']);Pp=int(pool['initial_p']);reserved=int(pool['reserved_B'])
 check('common_source_per_address',close(R[5]['source_mean_B'],supply['common_source_B'],abs_tol=1e-10) and close(R[5]['source_mean_E_MeV'],supply['common_supply_MeV_per_address'],abs_tol=1e-9))
 check('pool_initial_B',active+reserved==B and N+Pp==active and active==int(float(release['active_B'])))
 check('pool_source_mass_scaled',close(float(supply['common_supply_MeV_per_address'])/float(supply['common_source_B'])*B,pool['common_source_E_MeV'],abs_tol=.002))
 check('macro_same_energy_0_5_0_6',close(pool['common_source_E_MeV'],release['common_source_MeV'],abs_tol=.002))
 check('macro_same_beta_input',close(mn-mp-me,R[6]['beta_Q_MeV'],abs_tol=1e-12))
 F=float(release['fusion_events']);C=float(release['capture_events']);beta=float(release['new_beta_events'])
 check('alpha_from_actual_fusion',close(4*F/active,pool['alpha_B_fraction_of_active'],abs_tol=2e-11))
 check('deuteron_after_fusion',close(2*(C-2*F)/active,pool['deuteron_B_fraction_of_active'],abs_tol=2e-11))
 check('beta_events_match_0_5',close(beta/active,pool['beta_events_per_active_B'],abs_tol=2e-11))
 check('source_origin_capacity',int(pool['initial_quartets'])==N//2 and N>=129234)
 origin=json.loads((S/'origin_examples.json').read_text())
 src=[z['source_pair'] for z in origin[:2]];target=origin[2]['source_pair']
 check('original_K15_small_tags',all(z['K']==15 and z['order']=='small' for z in origin[:3]) and [x['n_prime_tag'] for x in [*src,target]]==[5,5,47])
 check('origins_in_same_prepared_K15_pool',all(x['n_source_slot']<N and N<=x['p_source_slot']<B for x in [*src,target]) and len({v for x in [*src,target] for v in [x['n_source_slot'],x['p_source_slot']]})==6)
 Bd=R[5]['binding_inputs_and_outputs_MeV']['deuteron_binding'];Qf=R[5]['binding_inputs_and_outputs_MeV']['two_deuterons_to_alpha_release']
 g=R[6]['nuclear_lines'];gc,tc=g['capture']['photon_MeV'],g['capture']['recoil_MeV'];gf,tf=g['fusion']['photon_MeV'],g['fusion']['recoil_MeV']
 check('capture_binding_line_recoil',close(gc+tc,Bd,abs_tol=1e-10))
 check('fusion_binding_line_recoil',close(gf+tf,Qf,abs_tol=1e-10))
 check('pool_gamma_capture',close(float(release['capture_photon_MeV']),gc*C,abs_tol=2e-5))
 check('pool_gamma_fusion',close(float(release['fusion_photon_MeV']),gf*F,abs_tol=2e-5))
 check('pool_recoil_capture',close(float(release['capture_recoil_cooling_MeV']),tc*C,abs_tol=2e-5))
 check('pool_recoil_fusion',close(float(release['fusion_recoil_cooling_MeV']),tf*F,abs_tol=2e-5))
 check('pool_full_energy',close(float(release['active_rest_MeV'])+float(release['protected_storage_MeV'])+float(release['resolved_release_MeV']),float(release['common_source_MeV']),abs_tol=.002))
 check('beta_initial_not_new',close(float(release['electron_antinu_records'])-float(release['new_beta_events']),float(release['initial_p_motifs']),abs_tol=1e-6))
 check('nuclear_binding_not_double_counted',close(C*Bd+F*Qf,float(release['capture_photon_MeV'])+float(release['fusion_photon_MeV'])+float(release['capture_recoil_cooling_MeV'])+float(release['fusion_recoil_cooling_MeV']),abs_tol=3e-5))
 micro7=R[7];micro8=R[8];micro9=R[9];micro10=R[10]
 check('micro_quartet_shell',close(micro7['cold_photon_thresholds_MeV']['deuteron_breakup'],((mn+mp)**2-m['deuteron']**2)/(2*m['deuteron']),abs_tol=1e-10))
 check('cross_photon_above_threshold',micro7['fusion_photon_deuteron_breakup']['allowed'] and gf>micro7['cold_photon_thresholds_MeV']['deuteron_breakup'])
 check('micro_target_hot_kinetic',close(micro8['target_hot_kinetic_MeV'],gf-(mn+mp-m['deuteron']),abs_tol=1e-10))
 case=next(z for z in micro9['cases'] if z['cooling_s_inv']==.1 and z['scale_m_per_cell']==5*299792458 and z['target_cell']==[0,0,2] and z['attempt_probability']==.1 and z['observation_s']==180)
 check('micro_origin_embedded_not_inferred',micro9['source_origin']==src and micro9['target_origin']==target and micro9['coupling_status'].startswith('External'))
 check('finite_ray_photon_partition',abs(case['photon_partition_residual'])<1e-10 and 0<case['photon_absorbed']<case['source_fusion']/6)
 check('selected_six_baryon_origin',all(z['origins']['source_pairs']==src and z['origins']['target_pair']==target for z in micro10['witnesses']))
 check('selected_six_baryon_conservation',all(abs(e['energy_residual_MeV'])<1e-8 and abs(e['momentum_residual_MeV'])<1e-10 and (e['baryon'],e['charge'],e['lepton'])==(6,0,0) for w in micro10['witnesses'] for e in w['events']))
 check('work_outside_source',micro10['source_local_readiness_external_work_MeV']==.002 and micro10['photon_vacuum_work_MeV']==0)
 check('separate_denominator_refusal',refuses_incompatible())
 result=dict(version='0.11',author='Wonsik Choi',method='cross-stage typed joint ledger; stage results and source archives retained',
  source_manifest={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(S.iterdir()) if f.is_file()},
  numeric_links=dict(filtered_address_fraction=R[1]['filter_weight'],common_B_per_conditional_address=R[5]['source_mean_B'],
   common_energy_MeV_per_conditional_address=R[5]['source_mean_E_MeV'],K15_finite_pool_source_B=B,K15_pool_initial_active_B=active,
   K15_pool_initial_neutron_B=N,K15_pool_initial_quartets=int(pool['initial_quartets']),
   K15_pool_common_source_MeV=float(pool['common_source_E_MeV']),K15_pool_capture_count=C,K15_pool_fusion_count=F,
   K15_pool_new_beta_count=beta,K15_pool_alpha_fraction_active=float(pool['alpha_B_fraction_of_active']),
   K15_pool_photon_MeV=float(release['total_photon_MeV']),K15_pool_release_MeV=float(release['resolved_release_MeV']),
   selected_six_baryon_source_MeV=6*mn,selected_ray_180s_absorption_probability=case['photon_absorbed'],
   selected_ray_180s_surviving_deuteron_probability=case['target_surviving_d'],selected_event_witnesses=len(micro10['witnesses'])),
  distinctions=['0.2 energy-supply candidates differ from 0.4 common B/E envelope',
   'K15 pool and six-baryon conditional module have different denominators',
   '0.8 continuous hazard and 0.9 finite Bernoulli contacts have different clocks',
   '0.10 event four-momenta condition on a branch; no full angular ensemble distribution',
   '0.4/0.5 protected reservoirs are not observed free neutrons',
   '0.7/.9 external preparation and physical positions/couplings remain supplied choices'],
  integration_gate=dict(shared_calibrated_inputs='closed',K15_macro_source_population_radiation='closed for declared preparation',
   selected_origin_six_baryon_photon_feedback='closed for declared embedding and q',
   full_pool_spatial_feedback='open: no unique placement, absorber matching or multi-target coupled evolution',
   microscopic_cooling_absorption_force='open',
   unconditional_parts_1_0='not certified by this 0.11 synthesis'),checks=checks,passed=sum(checks.values()),total=len(checks))
 (P/'results.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k in ['passed','total','numeric_links','integration_gate']}))
def refuses_incompatible():
 a=Quantity(1,'energy','MeV','per_finite_pool','K15-small')
 b=Quantity(1,'energy','MeV','per_six_baryon_module','K15-small')
 c=Quantity(1,'energy','MeV','per_finite_pool','K16-small')
 d=Quantity(1,'probability','unitless','per_finite_pool','K15-small')
 for item in [b,c,d]:
  try:a+item
  except ValueError:pass
  else:return False
 return (a+a).value==2
if __name__=='__main__':main()
