"""Typed common-ledger audit, finite arithmetic and archived physical inputs.
Run from any directory. No new physical mass decoder is assumed.
"""
from pathlib import Path
from dataclasses import dataclass
import json, math, csv, hashlib
import numpy as np
B=Path(__file__).resolve().parent
cfg=json.loads((B/'inputs.json').read_text())
N=cfg['N'];alpha=cfg['alpha'];beta=cfg['beta']
mass=cfg['recorded_rest_energies_MeV'];mp=mass['proton'];mn=mass['neutron'];me=mass['electron']
checks={}
def check(name,ok):
 checks[name]=bool(ok)
 if not ok:raise AssertionError(name)
@dataclass(frozen=True)
class Quantity:
 value:float
 kind:str
 unit:str
 denominator:str
 def add(self,other):
  if (self.kind,self.unit,self.denominator)!=(other.kind,other.unit,other.denominator):
   raise ValueError('ledger semantic/unit/denominator mismatch')
  return Quantity(self.value+other.value,self.kind,self.unit,self.denominator)
def blocked(a,b):
 try:a.add(b)
 except ValueError:return True
 return False
check('reject_count_plus_energy',blocked(Quantity(1,'count','1','per_initial_baryon'),Quantity(1,'energy','MeV','per_initial_baryon')))
check('reject_number_share_plus_load_share',blocked(Quantity(.1,'number_share','1','rendered_motifs'),Quantity(.1,'load_share','1','address_load')))
check('reject_conditional_plus_cosmic_share',blocked(Quantity(.1,'weight_share','1','admitted_addresses'),Quantity(.1,'weight_share','1','all_addresses')))
check('reject_mass_plus_energy',blocked(Quantity(1,'mass','kg','one_particle'),Quantity(1,'energy','MeV','one_particle')))
check('compatible_addition',Quantity(.2,'number_share','1','motifs').add(Quantity(.3,'number_share','1','motifs')).value==.5)
s=np.ones(N+1,bool);s[:2]=False
for p in range(2,math.isqrt(N)+1):
 if s[p]:s[p*p::p]=False
v=np.arange(2,N+1);mask=(v%2==1)&~s[2:];n=v[mask]
z=float(np.sum(v.astype(float)**-alpha));a=beta*n.astype(float)**-alpha/z
phi=float(a.sum());w=a/phi
check('admitted_address_count',len(n)==421502)
check('conditional_weight_normalization',abs(w.sum()-1)<1e-12)
check('inherited_filter_weight_5percent',abs(phi-.05)<1e-12)
rows=[]
for K in [15,16]:
 pool=np.flatnonzero(s)[:K]
 for order,parts in [('small',pool),('large',pool[::-1])]:
  full=n//parts.sum();c=np.repeat(full[:,None],K,axis=1);r=n-full*parts.sum()
  while np.any(r>=2):
   for j,p in enumerate(parts):
    fits=r>=p;c[:,j]+=fits;r-=p*fits
  check(f'arithmetic_address_conservation_K{K}_{order}',np.all(c@parts+r==n))
  avg=w@c;neutron=np.isin(parts,cfg['neutron_component_labels']);en=float(avg[neutron].sum());ep=float(avg[~neutron].sum())
  total=en+ep;f=en/total
  # One motif is one baryon. Electrons belong to proton motifs but are not baryons.
  check(f'charge_neutral_K{K}_{order}',ep-ep==0)
  check(f'valence_charge_K{K}_{order}',abs((2*(2*ep+en)-(ep+2*en))/3-ep)<1e-10)
  check(f'baryon_count_K{K}_{order}',abs(ep+en-total)<1e-12)
  mean_address=float(w@n);mean_parts_load=float(avg@parts);mean_r=float(w@r)
  load_n=float(avg[neutron]@parts[neutron])/mean_address
  load_p=float(avg[~neutron]@parts[~neutron])/mean_address
  residual_load=mean_r/mean_address
  check(f'linear_load_partition_K{K}_{order}',abs(load_n+load_p+residual_load-1)<1e-12)
  physical_rest_n=en*mn/(en*mn+ep*(mp+me))
  row={'K':K,'order':order,'conditional_mean_motifs':total,'neutron_number_share':f,'neutron_linear_address_load_share':load_n,'proton_motif_linear_address_load_share':load_p,'unresolved_linear_address_load_share':residual_load,'neutron_assigned_rest_energy_share':physical_rest_n,'rest_energy_scope':'supplied masses on assigned motifs; excludes unresolved residue and binding','cosmic_neutron_assigned_linear_budget':.05*load_n,'cosmic_residual_linear_budget':.05*residual_load,'mean_address_load':mean_address}
  rows.append(row)
check('number_share_not_linear_load_share',all(abs(x['neutron_number_share']-x['neutron_linear_address_load_share'])>1e-6 for x in rows))
ref=json.loads((B/'reference_fold_results.json').read_text())
check('reference_fold_30checks_recorded',ref['verification']['all_passed'] and ref['verification']['passed']==30)
baseline=json.loads((B/'baseline_sources/WRRA_Parts_Research_Checkpoint_2026_10_04.json').read_text())
for row in rows:
 old=next(x for x in baseline['summary'] if x['K']==row['K'] and x['order']==row['order'])
 check(f"baseline_neutron_count_K{row['K']}_{row['order']}",math.isclose(row['neutron_number_share'],old['neutron_fraction_N1m'],rel_tol=1e-11,abs_tol=1e-12))
check('reject_additive_to_multiplicative_without_map',blocked(Quantity(47,'additive_component_label','integer','component'),Quantity(75,'multiplicative_nucleon_address','integer','fold_state')))
Q=mn-mp-me
check('beta_rest_energy_closure',abs(mp+me+Q-mn)<1e-12)
check('positive_beta_release',Q>0)
# A completed daughter bundle contains rest energy plus nonrest outputs, not just p+e rest.
check('incomplete_daughter_bundle_detected',abs(mp+me-mn)>.7)
capture=[]
f=next(x['neutron_number_share'] for x in rows if x['K']==16 and x['order']=='small')
for ratio in [0,.1,1,10,100]:
 for T in [30,180,600]:
  d=1/cfg['neutron_mean_life_s'];k=ratio*d;surv=math.exp(-(k+d)*T)
  free=f*surv;cap=f*k/(k+d)*(1-surv);dec=f*d/(k+d)*(1-surv);proton=1-f+dec
  check(f'capture_count_closure_{ratio}_{T}',abs(free+cap+dec-f)<1e-12 and abs(proton+free+cap-1)<1e-12)
  initial_rest=(1-f)*(mp+me)+f*mn
  final_rest=proton*(mp+me)+(free+cap)*mn
  beta_nonrest=dec*Q
  # Captured sink keeps the same neutron rest label in 0.1; nuclear binding not supplied.
  check(f'beta_energy_closure_{ratio}_{T}',abs(initial_rest-final_rest-beta_nonrest)<1e-10)
  capture.append({'ratio':ratio,'T_s':T,'captured':cap,'decayed':dec,'beta_nonrest_MeV_per_initial_baryon':beta_nonrest,'helium_baryon_proxy':2*cap,'binding_status':'unresolved: capture sink is not a bound nucleus'})
old_capture=json.loads((B/'capture_baseline.json').read_text())
for old,new in zip(old_capture['results'],capture):
 check(f"capture_baseline_{new['ratio']}_{new['T_s']}",math.isclose(new['helium_baryon_proxy'],old['helium4_mass_proxy'],rel_tol=1e-11,abs_tol=1e-12))
contract=[
 {'field':'n','kind':'address','unit':'integer','denominator':'one_admitted_address','status':'upstream address; not MeV'},
 {'field':'c_j','kind':'component_count','unit':'integer','denominator':'one_admitted_address','status':'additive renderer output'},
 {'field':'a_n','kind':'filter_weight','unit':'1','denominator':'all_finite_addresses','status':'calibrated arithmetic weight'},
 {'field':'w_n','kind':'conditional_weight','unit':'1','denominator':'admitted_addresses','status':'a_n / Phi; not measured population'},
 {'field':'f_n','kind':'number_share','unit':'1','denominator':'rendered_baryon_motifs','status':'fixed decoder; weighted counts'},
 {'field':'L_n','kind':'linear_load_share','unit':'1','denominator':'total_conditional_address_load','status':'declared E proportional to address; not f_n'},
 {'field':'epsilon','kind':'energy_per_address_unit','unit':'MeV/address_unit','denominator':'one_address_unit','status':'NOT fixed by dimensionless 5% alone'},
 {'field':'Q','kind':'energy','unit':'MeV','denominator':'one_beta_decay','status':'supplied masses -> available nonrest energy'},
 {'field':'Y_proxy','kind':'baryon_count_proxy','unit':'1','denominator':'initial_baryons','status':'2 captured; not exact helium mass fraction'},
 {'field':'n75_to_p45','kind':'multiplicative_nucleon_label_transition','unit':'integer_labels','denominator':'one_fold_state','status':'prior rate model'},
 {'field':'component47_to_neutron','kind':'additive_component_decoder','unit':'label','denominator':'one_component','status':'calibrated parts map; interface to label75 OPEN'}]
result={'version':'0.1','author':'Wonsik Choi','verified_inputs':cfg,'WRRA_transformation':'typed ledger -> finite address assembly -> separate denominators -> charge/baryon and beta-energy closure -> explicit unresolved interfaces','filter_weight':phi,'addresses':len(n),'assembly_ledger':rows,'capture_beta_energy_audit':capture,'beta_Q_MeV':Q,'units_contract':contract,'checks':checks,'passed':sum(checks.values()),'total':len(checks),'open_interfaces':['dimensional epsilon and physical reservoir','additive component decoder to multiplicative fold-state map','unresolved component physical state','capture binding energy and reaction network','beta release partition into recoil/electron/neutrino/photon spectra'],'falsification_conditions':['semantic or unit mismatch accepted','address/charge/baryon/energy closure failure','source results not reproduced','fixed constitutive physical decoder incompatible with observed constraints']}
(B/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
with (B/'ledger_comparison.csv').open('w') as out:
 writer=csv.DictWriter(out,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
print(json.dumps({'passed':result['passed'],'total':result['total'],'rows':rows,'Q':Q},ensure_ascii=False,indent=2))
