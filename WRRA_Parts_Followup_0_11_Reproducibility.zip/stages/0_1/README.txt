WRRA prime-parts followup 0.1 | Wonsik Choi only
Run python compute.py; requires numpy.
Typed quantities reject incompatible semantic types, units and denominators. Finite arithmetic and inherited decoder are recomputed. Beta nonrest energy closes the supplied-mass ledger; capture binding remains open. This is a common-ledger audit, not the 0.2 physical energy decoder.
