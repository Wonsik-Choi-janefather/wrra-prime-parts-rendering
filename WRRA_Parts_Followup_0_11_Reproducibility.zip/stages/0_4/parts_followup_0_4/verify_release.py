"""Recompute in an isolated directory and compare the published results."""
from pathlib import Path
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
import tempfile
ROOT=Path(__file__).resolve().parent
checks={}
def check(name,ok):
    checks[name]=bool(ok)
    if not ok: raise AssertionError(name)
def compare(a,b,path=''):
    if isinstance(a,dict):
        check('keys'+path,set(a)==set(b))
        for key in a:compare(a[key],b[key],path+'/'+key)
    elif isinstance(a,list):
        check('length'+path,len(a)==len(b))
        for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+'/'+str(i))
    elif isinstance(a,(int,float)) and not isinstance(a,bool):
        check('value'+path,math.isclose(a,b,rel_tol=2e-12,abs_tol=1e-9))
    else:
        check('literal'+path,a==b)
manifest=json.loads((ROOT/'source_manifest.json').read_text())
for name,wanted in manifest.items():
    check('source_hash_'+name,hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==wanted)
original=(ROOT/'reference/fold_compute_original.py').read_text()
fixed=(ROOT/'reference/fold_compute.py').read_text()
export_line="   rows.append({'basis':[names[a],names[b],names[c]],'amplitude':float(s[index])})\n"
check('export_repair_is_one_return_only',fixed==original.replace(export_line,export_line+'  return rows\n'))
before=json.loads((ROOT/'reference/fold_results.json').read_text())['spin_flavor']['matrix_elements']
after=json.loads((ROOT/'spin_color_results.json').read_text())['matrix_elements']
for key in before:check('unchanged_inherited_current_'+key,math.isclose(before[key],after[key],abs_tol=1e-12))
with tempfile.TemporaryDirectory(prefix='wrra_parts_04_') as tmp:
    fresh=Path(tmp)/'release'
    shutil.copytree(ROOT,fresh,ignore=shutil.ignore_patterns('__pycache__','*.pyc','verification.json','SHA256SUMS'))
    for name in ['results.json','run.log','spin_color_results.json','source_manifest.json','source_comparison.csv','time_evolution.csv','state_transfer_contract.csv','mass_accounting_audit.csv','WRRA_Parts_Followup_0_4_KO.txt','WRRA_Parts_Followup_0_4_EN.txt']:
        (fresh/name).unlink(missing_ok=True)
    env=os.environ.copy();env['OPENBLAS_NUM_THREADS']='1'
    p=subprocess.run([sys.executable,'compute.py'],cwd=fresh,env=env,capture_output=True,text=True)
    check('fresh_compute_succeeds',p.returncode==0)
    if p.returncode:print(p.stderr)
    compare(json.loads((ROOT/'results.json').read_text()),json.loads((fresh/'results.json').read_text()),'/results')
    p=subprocess.run([sys.executable,'generate_report.py'],cwd=fresh,env=env,capture_output=True,text=True)
    check('fresh_reports_succeed',p.returncode==0)
    for name in ['WRRA_Parts_Followup_0_4_KO.txt','WRRA_Parts_Followup_0_4_EN.txt','source_comparison.csv','time_evolution.csv','state_transfer_contract.csv','mass_accounting_audit.csv']:
        check('same_runtime_byte_replay_'+name,(fresh/name).read_bytes()==(ROOT/name).read_bytes())
out={'all_passed':all(checks.values()),'audit_assertions':len(checks),'compute_checks_are_separate':json.loads((ROOT/'results.json').read_text())['total'],'fresh_reproduction':'outputs deleted then recomputed in isolated folder; numeric comparison plus same-runtime byte replay for reports and CSVs','scope':'implementation/reproduction checks; not additional physical evidence','checks':checks}
(ROOT/'verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2))
