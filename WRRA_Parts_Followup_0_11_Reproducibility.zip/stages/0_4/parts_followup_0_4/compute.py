"""WRRA Parts Followup 0.4: common source budgets and tagged transitions.

Rest energies and one lifetime are inherited calibration inputs. The source
budget, decoder and response law are declared WRRA construction choices.
The archived weak phase-space kernel is not executed by this release.
"""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import math
import numpy as np
from scipy.linalg import expm

ROOT = Path(__file__).resolve().parent
cfg = json.loads((ROOT / 'inputs.json').read_text())
m = cfg['recorded_rest_energies_MeV']
tau = cfg['neutron_mean_life_s']
Q = m['neutron'] - m['proton'] - m['electron']
checks = {}
def check(name, value):
    checks[name] = bool(value)
    if not value:
        raise AssertionError(name)
def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def csvout(name, rows):
    with (ROOT / name).open('w') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

# The only executed entry point of this archived module is spin_flavor().
spec = importlib.util.spec_from_file_location('fold', ROOT / 'reference/fold_compute.py')
fold = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fold)
sf = fold.spin_flavor()
for name, ok in sf['checks'].items():
    check('inherited_matrix_' + name, ok)
dump(ROOT / 'spin_color_results.json', sf)
def unpack(rows):
    lookup = {'3u_up':0, '3u_down':1, '5d_up':2, '5d_down':3}
    state = np.zeros(64, complex)
    for row in rows:
        a,b,c = [lookup[x] for x in row['basis']]
        state[16*a+4*b+c] = row['amplitude']
    return state
pstate, nstate = unpack(sf['proton_state']), unpack(sf['neutron_state'])
tp = np.array([[0,1],[0,0]])
V = sum(fold.at_slot(np.kron(tp, np.eye(2)), i) for i in range(3))
v = complex(np.vdot(pstate, V @ nstate))
anchor_v = cfg['response_anchor_vector']
check('internal_vector_actually_maps_n_to_p', np.linalg.norm(V@nstate - v*pstate) < 1e-12)

# Per-tag map U0 sends n to n|blank>, D to p|complete-lepton-record>.
# The lepton record carries Q=-1, L=0 and even fermion parity. It is a
# coarse energy-shell label, not a resolved outgoing wavefunction.
U0 = np.zeros((128,2), complex)
U0[:64,0] = nstate
U0[64:,1] = pstate
check('state_decoder_is_isometry', np.linalg.norm(U0.conj().T@U0-np.eye(2)) < 1e-12)
physical_J = np.zeros((128,128), complex)
physical_J[64:,:64] = V
coarse_J = U0.conj().T @ physical_J @ U0
expected_J = np.array([[0,0],[v,0]])
check('current_compression_uses_same_internal_states', np.linalg.norm(coarse_J-expected_J) < 1e-12)

# Assembly metadata is an orthogonal spectator. Collapsing tags 5 and 47
# to one untagged n state would lose invertibility; retain both origins.
tagged_decoder = np.kron(np.eye(2), U0)
check('two_origin_tags_remain_orthogonal', np.linalg.norm(tagged_decoder.conj().T@tagged_decoder-np.eye(4)) < 1e-12)
untagged = np.column_stack([nstate,nstate])
check('discarding_origins_fails_isometry', np.linalg.norm(untagged.conj().T@untagged-np.eye(2)) > .5)
tagged_current = np.kron(np.eye(2),coarse_J)
check('tagged_current_keeps_origin_blocks', np.linalg.norm(tagged_current-np.kron(np.eye(2),expected_J)) < 1e-12)
source_quantum=np.array([0,1,0,1])  # Q,B,L,fermion parity
daughter_quantum=np.array([1,1,0,1])+np.array([-1,0,1,1])+np.array([0,0,-1,1])
daughter_quantum[3]%=2
check('full_daughter_ledger_conserves_Q_B_L_parity',np.array_equal(source_quantum,daughter_quantum))
def require_quantum_contract(source,output):
    if not np.array_equal(source,output):
        raise ValueError('source and output quantum ledgers differ')
for name,source,output in [('p_e_without_antinu',source_quantum,np.array([0,1,1,0])),('B0_to_B1',np.array([0,0,0,0]),source_quantum)]:
    try:
        require_quantum_contract(source,output)
        rejected=False
    except ValueError:
        rejected=True
    check('reject_'+name,rejected)

# Constitutive response fixed at the inherited shell and internal current.
# No GF/Vud, phase-space spectrum or new constituent interaction is added.
def response(overlap=1., current=v):
    return abs(current/anchor_v)**2 * overlap**2 / tau
gamma = response()
check('lifetime_anchor_reproduced', abs(1/gamma-tau) < 1e-9)
check('frozen_anchor_retains_current_dependence',abs(response(current=v/2)/gamma-.25)<1e-12)
archive = json.loads((ROOT / 'reference/fold_results.json').read_text())
check('archived_shell_rate_agrees', abs(gamma-archive['rate_bridge']['calibrated_rate_per_s']) < 1e-14)
overlaps=[]
for row in archive['extra_overlap_cases']:
    overlap=row['additional_amplitude_overlap']
    rate=response(overlap)
    check('inherited_overlap_response_' + str(overlap), abs(rate-row['rate_per_s']) < 1e-14)
    overlaps.append({'overlap':overlap, 'rate_per_s':rate, 'mean_life_s':1/rate if rate else None})

# Energy shell basis n,D,inert n-like reserve. All three include energy mn.
# D includes mp+me plus Q in antineutrino/kinetic/recoil; no extra mass term.
J = np.zeros((3,3)); J[1,0]=math.sqrt(gamma)
I=np.eye(3);JJ=J.T@J
liouvillian = np.kron(J,J)-.5*(np.kron(I,JJ)+np.kron(JJ.T,I))
for index,name in enumerate(['Q','B','L','parity']):
    observable=np.diag([source_quantum[index],daughter_quantum[index],source_quantum[index]])
    adjoint=J.T@observable@J-.5*(JJ@observable+observable@JJ)
    check('generator_conserves_'+name,np.linalg.norm(adjoint)<1e-12)
def kraus(t):
    if t < 0:
        raise ValueError('elapsed time must be nonnegative')
    survival=math.exp(-gamma*t)
    K0=np.diag([math.sqrt(survival),1,1])
    K1=np.zeros((3,3));K1[1,0]=math.sqrt(-math.expm1(-gamma*t))
    return [K0,K1]
def apply(rho,t):
    return sum(K@rho@K.conj().T for K in kraus(t))
rng=np.random.default_rng(20261004)
z=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3))
rho=z@z.conj().T;rho/=np.trace(rho)
energy=m['neutron']*I
rest_observable=np.diag([m['neutron'],m['proton']+m['electron'],m['neutron']])
release_observable=np.diag([0.,Q,0.])
def adjoint_generator(observable):
    return J.T@observable@J-.5*(JJ@observable+observable@JJ)
check('rest_plus_release_is_full_shell',np.linalg.norm(rest_observable+release_observable-energy)<1e-10)
check('rest_loss_equals_release_gain_as_operator',np.linalg.norm(adjoint_generator(rest_observable)+adjoint_generator(release_observable))<1e-12)
for t in [0,1,100,tau,1000,5*tau]:
    label=str(t)
    ks=kraus(t); evolved=apply(rho,t)
    by_generator=(expm(liouvillian*t)@rho.reshape(9,order='F')).reshape(3,3,order='F')
    check('channel_complete_'+label,np.linalg.norm(sum(K.conj().T@K for K in ks)-I)<1e-12)
    check('channel_positive_'+label,np.linalg.eigvalsh(evolved).min()>-1e-12 and abs(np.trace(evolved)-1)<1e-12)
    check('matrix_generator_agrees_'+label,np.linalg.norm(evolved-by_generator)<1e-12)
    check('shell_energy_preserved_'+label,abs(np.trace(evolved@energy)-np.trace(rho@energy))<1e-9)
check('semigroup_on_coherent_state',np.linalg.norm(apply(apply(rho,111),222)-apply(rho,333))<1e-12)
try:
    kraus(-1)
    reject_negative=False
except ValueError:
    reject_negative=True
check('negative_time_rejected',reject_negative)
check('zero_current_and_overlap_stop_transition',response(0)==0 and response(current=0)==0)

# Tags need not be classical: the channel preserves a two-tag marginal.
z=rng.normal(size=(6,6))+1j*rng.normal(size=(6,6));rho_tag=z@z.conj().T;rho_tag/=np.trace(rho_tag)
evolved_tag=sum(np.kron(np.eye(2),K)@rho_tag@np.kron(np.eye(2),K.conj().T) for K in kraus(tau))
def marginal_tag(x):
    return np.trace(x.reshape(2,3,2,3),axis1=1,axis2=3)
check('tag_marginal_preserved_even_for_coherence',np.linalg.norm(marginal_tag(rho_tag)-marginal_tag(evolved_tag))<1e-12)

# Recompute every finite address and both assembly orders.
N=cfg['N'];sieve=np.ones(N+1,bool);sieve[:2]=False
for prime in range(2,math.isqrt(N)+1):
    if sieve[prime]:
        sieve[prime*prime::prime]=False
all_n=np.arange(2,N+1);addresses=all_n[(all_n%2==1)&~sieve[2:]]
w=addresses.astype(float)**-cfg['alpha'];w/=w.sum()
check('same_admitted_address_count',len(addresses)==421502)
check('conditional_weights_normalized',abs(w.sum()-1)<1e-12)
cache=[]
for K in [15,16]:
    pool=np.flatnonzero(sieve)[:K]
    for order,parts in [('small',pool),('large',pool[::-1])]:
        cyc=addresses//parts.sum();c=np.repeat(cyc[:,None],K,axis=1);r=addresses-cyc*parts.sum()
        while np.any(r>=2):
            for j,prime in enumerate(parts):
                fits=r>=prime;c[:,j]+=fits;r-=prime*fits
        is_n=np.isin(parts,cfg['neutron_component_labels'])
        cn=c[:,is_n].sum(axis=1);cp=c[:,~is_n].sum(axis=1);ct=cn+cp
        check(f'address_identity_{K}_{order}',np.all(c@parts+r==addresses))
        cache.append({'K':K,'order':order,'parts':parts,'mean_c':w@c,'n':cn,'D':cp,'ct':ct,'r':r})

# A common neutral n-like B budget is the pointwise envelope of motif counts.
# Residual-address energy is quarantined; it carries no baryon allocation.
Bcommon=np.maximum.reduce([item['ct'] for item in cache])
Rcommon=np.maximum.reduce([item['r'] for item in cache])
Ecommon=m['neutron']*(Bcommon+Rcommon)
mean_B=float(w@Bcommon);mean_E=float(w@Ecommon)
baseline=json.loads((ROOT/'reference/parts_0_3_results.json').read_text())
comparisons=[];times=[];transfers=[];mass_audit=[]
for item in cache:
    K,order=item['K'],item['order'];label=f'{K}_{order}'
    cn,cp,ct,r=item['n'],item['D'],item['ct'],item['r']
    reserve=Bcommon-ct;neutral_buffer=m['neutron']*(Rcommon-r)
    check('source_reserve_nonnegative_'+label,np.all(reserve>=0))
    check('common_B_all_addresses_'+label,np.array_equal(ct+reserve,Bcommon))
    check('residue_buffer_nonnegative_'+label,np.all(neutral_buffer>=0))
    rest=cn*m['neutron']+cp*(m['proton']+m['electron'])
    nonrest=cp*Q;resE=m['neutron']*r;reserveE=m['neutron']*reserve
    balance=rest+nonrest+resE+reserveE+neutral_buffer
    check('common_energy_all_addresses_'+label,np.allclose(balance,Ecommon,rtol=2e-14,atol=1e-7))
    original=next(row for row in baseline['assemblies'] if row['K']==K and row['order']==order)
    mean_ct=float(w@ct);mean_n=float(w@cn);mean_D=float(w@cp);mean_res=float(w@reserve)
    check('inherits_03_neutron_fraction_'+label,abs(mean_n/mean_ct-original['neutron_fraction'])<1e-12)
    comparisons.append({'K':K,'order':order,'mean_active_B':mean_ct,'common_source_B':mean_B,'mean_reserved_B':mean_res,'active_B_fraction_of_common':mean_ct/mean_B,'initial_neutron_fraction_of_active':mean_n/mean_ct,'initial_neutron_fraction_of_common':mean_n/mean_B,'common_supply_MeV_per_address':mean_E,'initial_active_rest_MeV_per_address':float(w@rest),'initial_nonrest_MeV_per_address':float(w@nonrest),'reserve_MeV_per_address':float(w@reserveE),'address_residue_MeV_per_address':float(w@resE),'neutral_energy_buffer_MeV_per_address':float(w@neutral_buffer)})
    for prime,mean_count in zip(item['parts'],item['mean_c']):
        transfers.append({'K':K,'order':order,'additive_prime_tag':int(prime),'mean_motif_count':float(mean_count),'initial_channel':'n' if prime in cfg['neutron_component_labels'] else 'D=p+e+antinu','internal_n_label':75 if prime in cfg['neutron_component_labels'] else '', 'internal_p_label':45,'tag_behavior':'original additive tag persists; never 47=75 or 5=75'})
    for t in [0.,100.,tau,1000.,5*tau]:
        survival=math.exp(-gamma*t);nt=cn*survival;dt=cp+cn*(-math.expm1(-gamma*t))
        restt=nt*m['neutron']+dt*(m['proton']+m['electron']);nonrestt=dt*Q
        check('dynamic_B_all_addresses_'+label+'_'+str(t),np.allclose(nt+dt+reserve,Bcommon,rtol=1e-14,atol=1e-10))
        check('dynamic_energy_all_addresses_'+label+'_'+str(t),np.allclose(restt+nonrestt+reserveE+resE+neutral_buffer,Ecommon,rtol=2e-14,atol=1e-7))
        check('dynamic_lepton_all_addresses_'+label+'_'+str(t),np.all(dt-dt==0))
        # Apply the actual matrix channel to mean populations, not just an exponential table.
        initial=np.diag([mean_n,mean_D,mean_res])/mean_B
        actual=apply(initial,t)*mean_B
        check('decoder_to_matrix_populations_'+label+'_'+str(t),np.allclose(np.diag(actual),[float(w@nt),float(w@dt),mean_res],rtol=1e-12,atol=1e-12))
        times.append({'K':K,'order':order,'time_s':t,'neutron_fraction_of_active_B':float(w@nt)/mean_ct,'daughter_fraction_of_active_B':float(w@dt)/mean_ct,'electron_count_per_common_B':float(w@dt)/mean_B,'antinu_count_per_common_B':float(w@dt)/mean_B,'reserved_B_fraction':mean_res/mean_B,'active_rest_MeV_per_address':float(w@restt),'nonrest_MeV_per_address':float(w@nonrestt),'closed_total_MeV_per_address':mean_E})
    # Rest and nonrest bookkeeping is independent of an unresolved internal mass decomposition.
    full_nuc=float(w@(cn*m['neutron']+cp*m['proton']));electron=float(w@cp)*m['electron']
    for share in [0.,.012,.1,.5,1.]:
        # These are artificial accounting splits, not measured quark mass shares.
        bare=share*full_nuc;internal=(1-share)*full_nuc
        correct=bare+internal+electron+float(w@nonrest)+float(w@reserveE)+float(w@resE)+float(w@neutral_buffer)
        check('internal_mass_no_double_count_'+label+'_'+str(share),abs(correct-mean_E)<1e-8)
        wrong=correct+internal
        if share<1:
            check('double_count_rejected_'+label+'_'+str(share),wrong>mean_E+1e-5)
        mass_audit.append({'K':K,'order':order,'artificial_internal_rest_split':share,'summed_once_MeV_per_address':correct,'double_count_excess_MeV_per_address':internal,'scope':'bookkeeping sensitivity only; no quark/gluon mass fraction fitted or inferred'})

check('common_source_has_order_independent_energy',max(x['common_supply_MeV_per_address'] for x in comparisons)==min(x['common_supply_MeV_per_address'] for x in comparisons))
check('common_source_has_order_independent_B',max(x['common_source_B'] for x in comparisons)==min(x['common_source_B'] for x in comparisons))
check('additive_and_multiplicative_labels_distinct',47!=75 and 5!=75 and 75-45!=Q)
check('Q_positive_for_fixed_shell',Q>0)
csvout('source_comparison.csv',comparisons)
csvout('time_evolution.csv',times)
csvout('state_transfer_contract.csv',transfers)
csvout('mass_accounting_audit.csv',mass_audit)
source_manifest={str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest() for path in [ROOT/'inputs.json',*sorted((ROOT/'reference').glob('*.py')),*sorted((ROOT/'reference').glob('*.json'))]}
dump(ROOT/'source_manifest.json',source_manifest)
out={'version':'0.4','author':'Wonsik Choi','date':'2026-10-04','verified_inputs':cfg,'construction_choices':{'source':'pointwise common B=max active motif count; Q=L=0; energy per B=mn','residue':'common residual allowance=max r; neutral remainder energy quarantined','decoder':'orthogonal additive origin tag tensor inherited internal n/p state and complete lepton-record label','response':'Gamma=abs(v/v_anchor)^2 * overlap^2 / tau; same fixed energy shell; independent inert reserve','initialization':'order-dependent preparation under a common supplied source budget; no preparation rate/Hamiltonian derived'},'same_state_current':{'vector_matrix_element':float(v.real),'bare_axial_matrix_element':sf['matrix_elements']['bare_axial_z_n_to_p'],'decoder_isometry_dimension':[128,2],'coarse_current':expected_J.real.tolist()},'Q_MeV':Q,'rate_per_s':gamma,'mean_life_s':1/gamma,'source_comparison':comparisons,'time_evolution':times,'overlap_responses':overlaps,'mass_split_audit':'artificial split reallocation leaves total invariant; adding internal mass energy to full nucleon rest energy is detected as double counting','executed_dependencies':['finite spin_flavor() states and matrix V from archived fold_compute.py','inherited lifetime and fixed shell masses','fresh finite renderer counts','matrix Kraus and Liouvillian evolution'],'archive_only':['legacy GF/Vud/axial-dressed phase-space and spectrum kernel; not executed here'],'checks':checks,'passed':sum(checks.values()),'total':len(checks),'falsification_conditions':['unequal common initial B or E between assembly orders','negative reserve or budget','loss of origin-tag isometry','failed Q/B/L or rest-plus-nonrest closure','same prepared shell disagrees with frozen current/rate response','unrecorded reserve activation or nuclear capture invalidates isolated channel'],'open_tasks':['physical source/preparation Hamiltonian and its energy/time cost','selecting actual assembly order and reserve activation','complete same-state lepton spin/helicity/momentum amplitude','nuclear binding and capture in 0.5','radiation energy partition/spectra in 0.6','source origin of baryon asymmetry and internal nucleon mass decomposition']}
dump(ROOT/'results.json',out)
print(json.dumps({'passed':out['passed'],'total':out['total'],'rate_per_s':gamma,'Q_MeV':Q,'source_comparison':comparisons,'K16_small_time_evolution':[x for x in times if x['K']==16 and x['order']=='small']},ensure_ascii=False,indent=2))
