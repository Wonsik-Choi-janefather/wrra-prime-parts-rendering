WRRA Parts Rendering Followup 0.4 | Wonsik Choi | 2026-10-04

This is the continuation of parts followups 0.1–0.3, not the old upstream 0.4.
Run from this directory:
  OPENBLAS_NUM_THREADS=1 python compute.py
  python generate_report.py
  OPENBLAS_NUM_THREADS=1 python verify_release.py

Dependencies: Python 3, numpy, scipy. Producing runtime: Python 3, numpy 2.3.5,
scipy 1.17.0. No network calls, external accounts or large dense address matrices.
Check source_manifest.json for input provenance and SHA256SUMS for packaged files.

The lifetime and rest masses are supplied calibrations. Source envelope, decoder,
inactive reserve and response law are declared choices. No source/preparation
Hamiltonian, radiation spectrum, nuclear binding or cosmic abundance is derived.
The archived legacy weak kernel is not executed. Only its finite spin_flavor()
states/current are used. The repaired state_rows exporter adds one missing return;
the original file is preserved. Do not run archived module main() as a release
entry point: its old paths and full weak-kernel workflow are outside this task.

Files: inputs.json; compute.py; results.json; spin_color_results.json;
source_comparison.csv; time_evolution.csv; state_transfer_contract.csv;
mass_accounting_audit.csv; Korean/English reports; reference snapshots; manifests.
Verification counts are mathematical/implementation audits, not observations.
