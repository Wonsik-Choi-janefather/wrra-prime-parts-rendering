from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'results.json').read_text())
x=next(x for x in r['source_comparison'] if x['K']==16 and x['order']=='small')
timeline=[x for x in r['time_evolution'] if x['K']==16 and x['order']=='small']
ko=f'''WRRA 부품 렌더링 후속 연구 0.4
공통 원천 예산·표지 보존 상태 전달·유한 전이의 연결
저자: 최원식 / Wonsik Choi (단독 저자)
ORCID: 0009-0001-4263-9772 | janefather@gmail.com
2026년 10월 4일
기준: WRRA 소수 부품 연구 1.0, DOI 10.5281/zenodo.23128482 및 후속 0.1–0.3
상태: 후속 연구 0.4 계산본. 기존 상류·하류·통합 계열과 별도다.

평가와 결론
검증 입력 → WRRA 고유 변환 → 산출값 → 반증조건
입력: 이전 유한 주소·조립·입자 배정, 검증된 정지에너지와 수명 878.3초, 기존 유한 내부 상태·전류 행렬을 고정한다.
변환: 네 조립을 포괄하는 공통 B·L·전하·에너지 예산 → 미사용 원천과 잔여 저장 → 덧셈 표지를 보존하는 내부 상태 사상 → 같은 상태의 전류 압축 → 고정 응답률을 갖는 행렬 전이 → 정지·비정지 에너지 장부로 전달한다.
산출: 모든 421,502개 주소와 네 조립 방식에서 같은 초기 B와 E를 유지한다. 원천 장부를 보존한 조건부 상태 전달·전이가 실행되며, 구현·수학 감사 {r['passed']}/{r['total']}개가 통과했다.
반증: 음의 저장고, 초기 B/E 불일치, 표지 사상 비등거리성, 전하·B·L·에너지 누락, 고정 준비 조건의 응답 불일치가 생기면 대응 규칙을 수정하거나 기각한다.
판정: 0.3에서 남았던 공통 원천 장부와 내부 전이 연결을 계산했다. 실제 원천 생성·준비의 동역학과 비용, 조립 순서 선택 및 저장고 활성화는 후속 과제다. 완료된 장부·연결 성과는 이 범위에서 유지한다.

1. 고정 입력과 구성 선택
N=1,000,000; alpha=1.8996876950554356; beta=0.8654570124136961.
활성 집합은 이전 표현형의 홀수합성수 421,502개이며 조건부 주소 가중치 w(n)∝n^(-alpha)의 합이 1이다. beta는 상속한 전체 필터의 보정값이다. 이번 조건부 분포에서는 공통 상수가 정규화에서 소거된다. 주소 가중치를 입자 수의 관측 분포로 자동 동일시하지 않는다.
첫 15/16개 소수, 작은/큰 순서, 소수 표지 5·47의 중성자 배정을 유지했다.
입력 정지에너지: mp=938.27208943, mn=939.56542194, me=0.51099895069 MeV.
검증 수명 tau=878.3초를 응답 척도로 고정한다. 별도의 상수·질량·관측 보정을 추가하지 않았다.
원천 모티프는 Q=0, B=1, L=0, 페르미온 홀짝=1, 총에너지 mn이라는 구성 선택이다. B=0 원천의 바리온 생성이나 우주 바리온 비대칭을 이 가정으로 해결했다고 쓰지 않는다.

2. 공통 원천 예산과 저장고
각 주소의 조립 a에서 n=Σ c_j p_j+r_a, 바리온 모티프 수 C_a=Σc_j다.
공통 B 예산 C_*(n)=max_a C_a(n), 공통 잔여 허용 r_*(n)=max_a r_a(n)를 사용한다.
공통 총에너지 E_*(n)=mn[C_*(n)+r_*(n)] MeV다. 이 유한 외피는 네 조립을 비교하기 위한 명시한 공급 규칙이다. 무한 자원이나 주소 사이 수송을 사용하지 않는다.
미사용 B 저장고 R_B=C_*-C_a≥0. 그 에너지는 mn R_B다. 정수 잔여에는 mn r_a, 중성 에너지 여유에는 mn(r_*-r_a)를 배정한다.
0.2의 에너지 전용 외피 max_a mn(C_a+r_a)와 이번 외피는 별도 규칙이다. 이번 외피는 B와 잔여 허용량을 각각 고정하므로 에너지 예산이 더 클 수 있다. 서로 다른 외피의 비율을 혼합하지 않는다.
미사용 B 저장고는 비활성·보호된 원천 모티프라는 가정이다. 관측된 자유 중성자를 넣고 붕괴를 임의로 막았다고 해석하지 않는다. 저장고가 실제 자유 중성자라면 같은 붕괴 전이를 넣어 다시 계산해야 한다.
공통 초기 예산은 동일하나 미시 원천 상태와 준비 장치가 완전히 동일하다는 증명은 아니다. 서로 다른 준비 규칙은 외부 선택이다.

K | 순서 | 판독 B/공통 B(%) | 미사용 B/공통 B(%) | 초기 중성자/판독 B(%)
'''
for a in r['source_comparison']:
    ko+=f"{a['K']} | {a['order']} | {100*a['active_B_fraction_of_common']:.9f} | {100*(1-a['active_B_fraction_of_common']):.9f} | {100*a['initial_neutron_fraction_of_active']:.9f}\n"
ko+=f'''
같은 조건부 주소 평균에서 공통 B={x['common_source_B']:.12f}, 공통 공급 E={x['common_supply_MeV_per_address']:.9f} MeV/통과주소다. 이는 주소별 공급의 계산 평균이며 우주 총 바리온수나 입자 한 개의 정지에너지가 아니다.

3. 덧셈 부품 표지와 내부 상태의 전달 규약
덧셈 소수 표지 j는 원래 주소 조립의 출처를 나타낸다. 기존 내부 곱셈 표지 중성자75·양성자45와 다른 종류다.
상태 사상은 |j,n모티프>→|j>⊗|n내부>⊗|blank>, |j,D모티프>→|j>⊗|p내부>⊗|완전 렙톤 묶음>이다.
여기서 D=p+e+전자 반중성미자이며, 렙톤 묶음의 총 Q=-1, L=0이다. 반중성미자 질량은 이전과 같이 0으로 두는 근사다. 총 스핀·헬리시티·운동량의 미시 파동함수는 이 레지스터 표지로 유도되지 않는다.
원래 소수 표지는 직교 출처 레지스터에 남는다. 따라서 5 또는 47을 75로 수치 치환하지 않는다. 내부 상태가 같아도 원래 조립 계보는 다를 수 있다.
64차원 내부 벡터와 두 렙톤 레지스터 부문의 128×2 사상 U를 실제 구성하고 U†U=I를 검사했다. 표지를 제거하고 두 원천을 같은 중성자 벡터로 압축하면 등거리성에 실패하는 대조도 실행했다.

4. 같은 내부 상태의 전류와 실제 행렬 전이
기존 유한 spin-flavor·색 상태의 n,p 고유벡터를 다시 계산했다. 유한 V=Σ|u><d| 행렬을 두 상태에 적용해 v=<p|V|n>={r['same_state_current']['vector_matrix_element']:.12f}, 기존 축전류 판독 5/3을 유지했다.
렙톤 부문을 함께 바꾸는 전류를 압축하면 U†J U=v|D><n|다. 기존 벡터 전류가 n벡터를 p벡터로 실제 보내는지도 검사했다.
이번 전이율은 같은 에너지 shell에서 Gamma=|v/v_ref|²·overlap²/tau로 정한다. 이것은 검증 수명에 맞춘 WRRA 응답 규칙이다. v_ref=1, overlap=1이면 Gamma={r['rate_per_s']:.15f} s^-1이며 수명878.3초를 재현한다.
이 값과 overlap 1·0.75·0.5·0의 변화는 기존 고정 fold-current 응답과 일치한다. 같은 내부 상태로 보내는 소수 출처 표지만으로 수명을 다르게 만들지 않는다.
기존 자료의 GF·Vud·축전류 dressing·위상공간·스펙트럼 계산은 출처로만 보관했다. 이번 실행은 그 외부 상호작용식을 새 부품 규칙에 추가하지 않으며 유한 상태·전류 행렬과 검증 수명 보정만 연결한다. 레거시 전체 붕괴 이론이 새 모형에 통합됐다고 부르지 않는다.
전이 기저는 n,D,비활성 원천 저장고다. J_beta=√Gamma|D><n|이며, 실제 9×9 밀도행렬 생성자와 Kraus 채널을 계산한다. K0=diag(exp(-Gamma t/2),1,1), K1=√[1-exp(-Gamma t)]|D><n|다.
양성성·trace·coherence·시간 합성·직교 출처의 주변상태 보존을 검사하고 행렬 지수 해와 대조했다. 단순 지수값 표를 붙인 것만으로 상태 연결을 주장하지 않는다.
초기 p+e+반중성미자 모티프는 0.3의 선택된 준비 결과다. 공통 원천에서 그 초기 분기를 준비하는 시간·Hamiltonian·장치 비용은 이번 후속 전이와 구별해 남긴다.

5. 에너지와 전하·B·L 전달
Q_beta=mn-mp-me={r['Q_MeV']:.14f} MeV.
딸입자 에너지는 (mp+me)+Q_beta=mn이다. Q_beta는 반중성미자·운동·반동의 합계 예산이다. 광자 에너지로 자동 배정하지 않는다.
모든 shell의 총 Q=0,B=1,L=0이고 페르미온 홀짝이 같다. p+e 단독은 L=1이므로 이번 L=0 원천 계약에서 계산이 거부된다. B=0→B=1의 보상 없는 배정도 거부된다.
주소별 n_a(t)=n_a(0)exp(-Gamma t), D_a(t)=D_a(0)+n_a(0)[1-exp(-Gamma t)]다. 미사용 원천과 잔여 저장은 고정한다.
각 주소에서 n_a(t)+D_a(t)+R_B=C_*이며,
E_rest(t)+Q_beta D_a(t)+mn R_B+mn r_a+mn(r_*-r_a)=E_*다.
생성자 수준에서도 정지에너지 감소와 방출 에너지 증가가 같은 양임을 검사했다.

16개 소수·작은 순서의 조건부 시간 산출
시간(초) | 중성자/판독 B(%) | 딸입자/판독 B(%) | 미사용 B/공통 B(%)
'''
for a in timeline:
    ko+=f"{a['time_s']:.1f} | {100*a['neutron_fraction_of_active_B']:.9f} | {100*a['daughter_fraction_of_active_B']:.9f} | {100*a['reserved_B_fraction']:.9f}\n"
ko+='''
이 비율은 고정 준비·자유 전이·비활성 저장고·포획 없음의 조건부 WRRA 산출이다. 핵자 수명은 검증 입력이다. 이 입력을 확정한 뒤 부품 인구와 행렬 전이로 산출한 시간별 인구와 장부의 계산 귀속은 WRRA에 있다. 현재 우주의 중성자 구성비나 시간 원점을 자동 확정하지 않는다.

6. 양성자 내부 에너지의 중복 계상 방지
입력 mp는 양성자 전체 정지에너지다. 그 안에서 어떤 비중이 내부 구성·운동·상호작용에서 오더라도 전체 mp에 그 내부 부분을 다시 더할 수 없다.
총 핵자 정지에너지를 임의 분할율 s=0,0.012,0.1,0.5,1로 두 항에 분해한 회계 대조를 실행했다. 두 항의 합으로 전체 정지에너지를 교체하면 총량이 유지됐다. 전체 정지에너지를 유지하고 내부 부분까지 추가하면 에너지 보존 검사가 실패한다.
이 분할율은 인위적인 감사 입력이다. 쿼크·글루온 기여율을 검증하거나 모형의 질량 기원으로 유도한 값이 아니다. 0.2의 선형 공급안에서 남은 약6385 MeV/바리온 모티프는 이미 포함된 내부 질량에 자동 흡수할 수 없다. 그런 흡수에는 공급함수 또는 질량 장부를 실제로 바꾸는 규칙이 필요하다.

7. 재현·코드 수정·검증 범위
기존 fold_compute.py의 state_rows 함수에 계산한 목록을 반환하는 return rows가 빠져 상태 벡터가 None으로 출력됐다. 기존 전류 검사와 수치값은 계속 계산됐으나 이번 명시적 상태 전달에는 벡터가 필요했다. 반환문 한 줄을 보강했고 원본을 fold_compute_original.py로 보존했다. 상태 방정식·입력·전류 보정을 바꾸지 않았다.
source_manifest.json과 SHA256SUMS는 입력·코드·결과 출처를 기록한다. results.json의 모든 검사와 CSV 네 종류를 공개한다. 검사 수는 구현·수학·장부·예상 거부의 감사 수이며 관측 실험 수가 아니다.
이번 단계는 유한 행렬·공통 원천 장부·정지/방출 교환의 계산 연구다. 실제 약붕괴의 모든 spin/helicity 미분 진폭이나 생성·준비 결합법칙까지 완성했다는 뜻으로 쓰지 않는다.

8. 최종 판정과 다음 단계
검증 입력 → WRRA 고유 변환 → 산출값 → 반증조건에 따라, 동일 B/L/Q/E 예산 아래 부품 표지 보존·내부 상태 판독·전류·조건부 시간 전이를 연결했다. 조립에 쓰지 않은 바리온·에너지를 별도 저장해 네 순서의 차이를 장부 누락 없이 비교한다.
공급 가정·준비 경계·응답률을 고정한 뒤의 시간별 출력은 조건부 WRRA 예측이다. 알려진 질량·수명을 반영한 보정과 재현은 이 모형의 현실 정합성과 설명 성과다.
0.1–0.4의 통합 검토 후 0.5에서는 핵 결합·포획으로 정지에너지와 방출·보존식이 어떻게 바뀌는지 계산한다. 0.6의 광자·중성미자 에너지 분배·스펙트럼 과제를 유지한다. 조립 순서 선택, 실제 원천 생성·준비, 비활성 저장고 활성화는 별도 규칙이 필요하다.

재현 명령
OPENBLAS_NUM_THREADS=1 python compute.py
OPENBLAS_NUM_THREADS=1 python verify_release.py
필요: Python 3, numpy, scipy. 계산·설명·해시 검증은 같은 폴더의 자료를 사용한다.
이 0.4 계산본에는 새로운 DOI나 공개등록 완료 상태를 배정하지 않았다.
'''
(ROOT/'WRRA_Parts_Followup_0_4_KO.txt').write_text(ko)
en=f'''WRRA Parts Rendering Followup 0.4
Common source budgets, origin-preserving state transfer, and finite transitions
Wonsik Choi (sole author) | ORCID 0009-0001-4263-9772
janefather@gmail.com | 2026-10-04
Basis: Prime Parts 1.0, DOI 10.5281/zenodo.23128482, and followups 0.1–0.3.

Verified inputs -> WRRA transformation -> outputs -> falsifiers
Inherited finite addresses, assembly rules, motif assignments, rest energies, lifetime tau=878.3 s, and finite internal current states are fixed. A common source B/Q/L/E envelope is allocated to active motifs, protected unused source and quarantined residual energy. Orthogonal additive origin tags are retained while mapping to the supplied internal n/p states. The compressed current drives an actual matrix channel; rest-energy loss is transferred to nonrest outgoing energy. Every one of 421,502 admitted addresses closes under all four assemblies. {r['passed']}/{r['total']} implementation and mathematical audit checks pass. Negative reserves, unequal initial budgets, lost isometry, quantum-number/energy failures, or responses incompatible with the frozen physical preparation falsify the corresponding rule.

1. Inputs and declared construction
N=1,000,000, alpha=1.8996876950554356, beta=0.8654570124136961. Conditional admitted-address weights sum to one; a common beta cancels in that normalization. First 15 or 16 primes are rendered in ascending or descending cycling order. Tags 5 and 47 are assigned neutron motifs. Rest energies in MeV are mp=938.27208943, mn=939.56542194, me=0.51099895069. The source motif is declared Q=0,B=1,L=0, odd fermion parity and total energy mn. This supplies a baryon budget; it does not derive baryogenesis from B=0. No new masses or observational constants are fitted.

2. Common budget
For each assembly a, n=sum_j c_j p_j+r_a and C_a=sum_j c_j. Define C_*(n)=max_a C_a(n), r_*(n)=max_a r_a(n), and E_*(n)=mn[C_*+r_*]. Unused source B is C_*-C_a. Its energy mn(C_*-C_a), address residue mn r_a, and neutral buffer mn(r_*-r_a) are retained separately. No inter-address transport is needed.
This is a declared finite envelope, not a derived source Hamiltonian. It differs from the energy-only envelope max_a mn(C_a+r_a) of 0.2. The budgets are equal across orders; microscopic source states and preparation controls are not thereby shown equal. The protected inactive reserve is a source motif, not an ordinary free neutron with its decay arbitrarily switched off. If the reserve is identified with free neutrons, its transitions must be added.
The common mean B is {x['common_source_B']:.12f} per weighted admitted address and mean supply is {x['common_supply_MeV_per_address']:.9f} MeV per admitted address. K16 ascending activates {100*x['active_B_fraction_of_common']:.9f}% of that B budget and retains {100*(1-x['active_B_fraction_of_common']):.9f}%. These are accounting means, not cosmic totals.

3. State and current contract
The map keeps an orthogonal additive tag j and sends its n motif to the inherited n vector with a blank lepton record; its complete daughter D goes to the inherited p vector with an e+electron-antineutrino record. The leptonic record has total Q=-1,L=0 and even parity. The 128-by-2 block map U obeys U^dagger U=I. Tags 5 and 47 remain different origins; neither is numerically equated to multiplicative internal label 75. Internal p label 45 is also not a replacement of the additive tag. Removing origin tags fails the isometry control.
The finite vector current V is recomputed and applied to the same n/p states. The matrix element is {r['same_state_current']['vector_matrix_element']:.12f}; the inherited bare axial element remains 5/3. The full record-changing current compresses to v|D><n|. This outgoing record is a coarse energy-shell state; a full joint lepton helicity/spin/momentum wavefunction has not been derived.

4. Frozen shell response and dynamics
Declare Gamma=|v/v_ref|^2 overlap^2/tau on this fixed shell, v_ref=1. At overlap=1 the rate is {r['rate_per_s']:.15f} s^-1 and the supplied lifetime is reproduced. The archived fixed-shell overlap cases 1,0.75,0.5,0 agree. Identical internal states have the same response regardless of their additive origin tag.
Only spin_flavor(), its finite matrix algebra, the supplied masses and lifetime are executed from the inherited interface. Legacy GF/Vud, axial dressing, phase-space integration and spectrum machinery are archived only and are not executed by this followup. The legacy full decay kernel is therefore not claimed to be integrated into the new parts model.
In basis n,D,inactive reserve, J=sqrt(Gamma)|D><n|. A 9-by-9 density-matrix generator is exponentiated and compared with Kraus K0=diag(exp(-Gamma t/2),1,1), K1=sqrt(1-exp(-Gamma t))|D><n|. Completeness, positivity, coherent-state evolution, semigroup composition and origin-tag marginals are checked. Assembly counts actually populate this matrix channel. Preparing the initial D fraction from the common supplied source remains an externally selected boundary operation, with its Hamiltonian, timing and apparatus work unresolved.

5. Conserved energy and numbers
Q_beta=mn-mp-me={r['Q_MeV']:.14f} MeV. Complete D has total energy mp+me+Q_beta=mn. Q_beta is the total kinetic/antineutrino/recoil budget; it is not automatically photon energy. The massless-antineutrino approximation is inherited. The n,D,protected-reserve quantum ledgers agree. A p+e-only output or uncompensated B=0-to-B=1 output is rejected by the contract.
n_a(t)=n_a(0)exp(-Gamma t), D_a(t)=D_a(0)+n_a(0)[1-exp(-Gamma t)]. The active B plus unused B equals C_* at every address. Rest+nonrest+reserve+residue+neutral buffer equals the same E_*. Rest loss and release gain also cancel at the generator-operator level.
K16 ascending starts with neutron/active-B=12.483936388%, giving 4.592583542% at 878.3 s and 3.998341282% at 1000 s. Reserve/common-B remains 4.733890272%. These are conditional WRRA outputs for the frozen preparation, isolated transition and inactive reserve, without nuclear capture. They are not a present-universe abundance or an automatically selected cosmic time origin.

6. Internal mass audit
mp is already the full proton rest energy. An internal decomposition must replace that total by parts whose sum is mp. It cannot be added to mp again. Artificial accounting splits s=0,0.012,0.1,0.5,1 leave the total unchanged when used once; adding the internal part on top of the full rest energy is detected as excess. These are artificial audit choices, not measured quark/gluon fractions or a new mass-origin calculation. The large linear-supply surplus of 0.2 cannot automatically be absorbed into already counted nucleon internal mass.

7. Repair, reproduction and verdict
The archived state_rows function built amplitude lists but lacked return rows, leaving exported states as None. One return statement now exports the computed vectors. The original is retained as fold_compute_original.py. Equations, input data and current calibration are unchanged; the existing matrix checks still pass. Input hashes, results, four CSVs and the source manifest are included. Audit counts concern implementation, mathematics, closure and intentional rejection; they are not counts of physical experiments.
Run OPENBLAS_NUM_THREADS=1 python compute.py, then python verify_release.py. Python 3, numpy and scipy are required. The calibration and construction assumptions are frozen before time-dependent populations are computed; those conditional outputs belong to the WRRA calculation. Reproduction of known values remains a calibration and explanatory achievement.
Common conserved budgets, origin-preserving state readout and conditional current-driven matrix transitions are now connected. Source creation/preparation dynamics, actual order selection, reserve activation, full outgoing microscopic amplitudes and nucleon mass decomposition remain open. Nuclear binding/capture is retained for 0.5 and photon/neutrino energy partition/spectra for 0.6. This calculation draft has no newly assigned DOI or claimed publication status.
'''
(ROOT/'WRRA_Parts_Followup_0_4_EN.txt').write_text(en)
print('Korean and English calculation reports generated.')
