"""One directed fusion-photon opportunity and a disjoint cold deuteron.
Deterministic vacuum flight, finite interaction window, declared hazard.
No measured cross section or microscopic force is inferred.
"""
from pathlib import Path
import csv,json,itertools
import numpy as np
from scipy.integrate import solve_ivp
from scipy.special import roots_legendre
import source07 as s
P=Path(__file__).resolve().parent
C=299792458.0
# Target states following absorption: X hot np, A cooled np, B beta endpoint,
# H recaptured hot d, D recaptured cold d.
K=s.gf-(s.n+s.p-s.d)
TL=np.array([
 [s.n+s.p+s.e,s.qb,s.gc,K,s.tc],
 [s.n+s.p+s.e,s.qb,s.gc,0,s.tc+K],
 [2*s.p+2*s.e,2*s.qb,s.gc,0,s.tc+K],
 [s.d+s.e,s.qb,2*s.gc,s.tc,s.tc+K],
 [s.d+s.e,s.qb,2*s.gc,0,2*s.tc+K]])
T0=np.array([s.d+s.e,s.qb,s.gc,0,s.tc])
def target_generator(cooling):
 q=np.zeros((5,5))
 for i,j,k in [(0,1,cooling),(1,2,1/878.3),(1,3,100/878.3),(3,4,cooling)]:
  q[i,j]+=k;q[i,i]-=k
 return q
def setup(cooling):
 q,rw,_=s.build(cooling,cooling,0)
 x=np.zeros(35);x[0]=1
 src=solve_ivp(lambda t,y:np.r_[y[:27]@q,y[:27]@rw],[0,600],x,method='DOP853',rtol=2e-12,atol=1e-14,dense_output=True)
 tq=target_generator(cooling);y=np.zeros(5);y[0]=1
 tar=solve_ivp(lambda t,y:y@tq,[0,600],y,method='DOP853',rtol=2e-12,atol=1e-14,dense_output=True)
 assert src.success and tar.success
 return src.sol,tar.sol
def integrate(cooling,tau,kappa,window,eta,t,nodes=64,solvers=None):
 src,tar=solvers or setup(cooling)
 xg,wg=roots_legendre(nodes)
 def nodes_on(lo,hi):return lo+(hi-lo)*(xg+1)/2,wg*(hi-lo)/2
 source_full=src(t);source_prob=source_full[:27];source_ledger=source_prob@s.L
 fusion=float(source_prob[25]+source_prob[26]);arrived=contact=escaped=absorbed=0.;target=np.zeros(5)
 last=max(0,t-tau)
 # Split the finite-window kink at t-tau-window.
 split=sorted(set([0.,max(0,last-window),last]))
 for lo,hi in zip(split[:-1],split[1:]):
  if hi==lo:continue
  u,wu=nodes_on(lo,hi);j=(100/878.3)*src(u)[s.ST.index(('T','T')),:]
  age=t-tau-u;vmax=np.minimum(window,age)
  arrived+=float(np.dot(wu,j))
  contact+=float(np.dot(wu,j*np.where(age<window,np.exp(-kappa*age),0)))
  escaped+=float(np.dot(wu,j*np.where(age>=window,np.exp(-kappa*window),0)))
  if kappa>0:
   v=vmax[:,None]*(xg[None,:]+1)/2
   weights=wu[:,None]*j[:,None]*vmax[:,None]*wg[None,:]/2*kappa*np.exp(-kappa*v)
   ages=(age[:,None]-v).reshape(-1)
   target+=tar(ages).reshape(5,nodes,nodes).reshape(5,-1)@weights.reshape(-1)
   absorbed+=float(weights.sum())
 target*=eta;absorbed*=eta;contact*=eta;escaped*=eta
 flight=eta*(fusion-arrived);unaligned=(1-eta)*fusion
 # Source ledger includes every emitted fusion photon. Only actual absorption
 # consumes it; all flight/contact/escape records retain their energy.
 combined=source_ledger[:5]+(1-absorbed)*T0+target@TL
 combined[2]-=s.gf*absorbed
 return dict(cooling_s_inv=cooling,flight_time_s=tau,distance_m=C*tau,absorption_hazard_s_inv=kappa,
  contact_window_s=window,aligned_fraction=eta,time_s=t,source_fusion_probability=fusion,
  photon_in_flight=flight,photon_in_contact=contact,photon_escaped=escaped+unaligned,
  photon_absorbed=absorbed,photon_balance_residual=flight+contact+escaped+unaligned+absorbed-fusion,
  target_unabsorbed_deuteron_probability=1-absorbed,target_hot_np_probability=float(target[0]),
  target_cold_np_probability=float(target[1]),target_beta_endpoint_probability=float(target[2]),
  target_recaptured_hot_d_probability=float(target[3]),target_recaptured_cold_d_probability=float(target[4]),
  target_surviving_deuteron_probability=float(1-absorbed+target[3]+target[4]),
  additional_capture_photons=float(target[3]+target[4]),
  rest_MeV=float(combined[0]),beta_nonrest_MeV=float(combined[1]),photon_MeV=float(combined[2]),
  active_nuclear_recoil_MeV=float(combined[3]),bath_gain_MeV=float(combined[4]),
  external_work_MeV=float(.001*source_full[34]),external_work_remaining_MeV=float(.002-.001*source_full[34]),
  source_energy_MeV=6*s.n,energy_residual_MeV=float(combined.sum()-6*s.n),
  target_population_normalization_residual=float(1-absorbed+target.sum()-1))
def main():
 rows=[]
 for cooling in [.01,.1]:
  sol=setup(cooling)
  for tau,kappa,w,eta,t in itertools.product([0.,1.,10.,100.],[0.,.01,.1,1.],[1.,10.],[0.,1/6,1.],[30.,180.,600.]):
   rows.append(integrate(cooling,tau,kappa,w,eta,t,solvers=sol))
 result=dict(version='0.8',fixed_speed_m_s=C,target_states=['X','A','B','H','D'],target_hot_kinetic_MeV=K,cases=rows)
 (P/'results.json').write_text(json.dumps(result,indent=2)+'\n')
 with (P/'photon_feedback_grid.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 print(json.dumps(dict(cases=len(rows),max_energy_error=max(abs(z['energy_residual_MeV']) for z in rows),max_photon_error=max(abs(z['photon_balance_residual']) for z in rows))))
if __name__=='__main__':main()
