"""Finite quartet preparation gates and explicit radiation-record return.
Effective hazards are declared choices, not cross sections or forces.
"""
from pathlib import Path
import json, csv, itertools, hashlib
import numpy as np
from scipy.linalg import expm

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'reference_0_6_results.json'
r=json.loads(BASE.read_text()); m=r['inherited_masses_MeV']
n,p,e,d,a=[m[k] for k in ['neutron','proton','electron','deuteron','alpha_nucleus']]
qb=n-p-e; gc=r['nuclear_lines']['capture']['photon_MeV']; tc=r['nuclear_lines']['capture']['recoil_MeV']
gf=r['nuclear_lines']['fusion']['photon_MeV']; tf=r['nuclear_lines']['fusion']['recoil_MeV']
ST=list(itertools.product('ABHRT', repeat=2))+['FH','FT']
# A=np; B=beta endpoint; H=d with recoil and its photon;
# R=cold d; T=cold d admitted to next reaction. FH/FT=hot/cold alpha.
def state_ledger(s):
    if isinstance(s,str):
        return np.array([a+2*e,2*qb,2*gc+gf,tf if s=='FH' else 0,2*tc+(tf if s=='FT' else 0),4,0,0,2,1,0.])
    rest=2*e; beta=2*qb; photons=hot=bath=nb=nc=0.
    for x in s:
        if x=='A': rest+=n+p
        elif x=='B': rest+=2*p+e; beta+=qb; nb+=1
        else:
            rest+=d; photons+=gc; nc+=1
            if x=='H': hot+=tc
            else: bath+=tc
    return np.array([rest,beta,photons,hot,bath,4,0,0,nc,0,nb])
L=np.array([state_ledger(s) for s in ST]); energy=L[:,:5].sum(axis=1)
def build(cooling,transfer,reverse):
    q=np.zeros((27,27)); rewards=np.zeros((27,8)); edges=[]
    def edge(i,j,rate,kind):
        if rate==0:return
        q[i,j]+=rate; q[i,i]-=rate
        rewards[i,kind]+=rate; edges.append((i,j,rate,kind))
    gb=1/878.3; kc=kf=100*gb
    for i,s in enumerate(ST):
        if isinstance(s,str):
            if s=='FH':
                edge(i,26,cooling,4)
                edge(i,ST.index(('T','T')),reverse,6)
            continue
        for k,x in enumerate(s):
            def change(y,rate,kind):
                z=list(s);z[k]=y;edge(i,ST.index(tuple(z)),rate,kind)
            if x=='A':change('B',gb,0);change('H',kc,1)
            if x=='H':change('R',cooling,3);change('A',reverse,5)
            if x=='R':change('T',transfer,7) # admission/transfer counter
        if s==('T','T'):edge(i,25,kf,2)
    return q,rewards,edges

def run(cooling,transfer,reverse,t):
    q,rw,edges=build(cooling,transfer,reverse)
    aug=np.zeros((35,35));aug[:27,:27]=q;aug[:27,27:]=rw
    initial=np.zeros(35);initial[0]=1
    evolved=initial@expm(aug*t); prob=evolved[:27]; counts=evolved[27:]
    vals=prob@L
    return dict(cooling_s_inv=cooling,transfer_s_inv=transfer,hot_return_s_inv=reverse,time_s=t,
      helium_probability=float(prob[25]+prob[26]),cold_helium_probability=float(prob[26]),
      retained_capture_photons=float(vals[8]),retained_fusion_photons=float(vals[9]),
      gross_capture_events=float(counts[1]),gross_fusion_events=float(counts[2]),
      capture_return_events=float(counts[5]),fusion_return_events=float(counts[6]),
      transfer_events=float(counts[7]),external_work_MeV=float(.001*counts[7]),
      rest_MeV=float(vals[0]),beta_nonrest_MeV=float(vals[1]),photon_MeV=float(vals[2]),
      active_nuclear_recoil_MeV=float(vals[3]),cooling_bath_gain_MeV=float(vals[4]),
      source_energy_MeV=float(4*n),energy_residual_MeV=float(vals[:5].sum()-4*n),
      normalization_error=float(abs(prob.sum()-1)),min_probability=float(prob.min()),
      population=prob.tolist(),counts=counts.tolist())

def main():
    rows=[run(c,tr,rev,t) for c in [0,.01,.1,1,10] for tr in [0,.01,.1,1,10] for rev in [0,.01,.1] for t in [30,180,600]]
    threshold_c=((n+p)**2-d*d)/(2*d)
    threshold_f=((2*d)**2-a*a)/(2*a)
    invariant=cross_s=d*d+2*d*gf
    cm=np.sqrt(cross_s); ee_n=(cross_s+n*n-p*p)/(2*cm); kk=np.sqrt(ee_n*ee_n-n*n)
    velocity=gf/(d+gf); gamma=(d+gf)/cm
    cross=[]
    for cosine in [-1.,0.,1.]:
        en=gamma*(ee_n+velocity*kk*cosine); ep=d+gf-en
        pnz=gamma*(kk*cosine+velocity*ee_n); ppx=-kk*np.sqrt(1-cosine*cosine)
        pnx=-ppx; ppz=gf-pnz
        cross.append(dict(cosine=cosine,neutron_energy_MeV=en,proton_energy_MeV=ep,
          neutron_momentum_MeV=[pnx,0,pnz],proton_momentum_MeV=[ppx,0,ppz],
          total_kinetic_MeV=en+ep-n-p))
    result=dict(version='0.7',reference_sha256=hashlib.sha256(BASE.read_bytes()).hexdigest(),
      states=[list(s) if isinstance(s,tuple) else s for s in ST],
      cold_photon_thresholds_MeV={'deuteron_breakup':threshold_c,'alpha_to_two_deuterons':threshold_f},
      own_line_deficits_MeV={'capture':threshold_c-gc,'fusion':threshold_f-gf},
      fusion_photon_deuteron_breakup=dict(allowed=gf>threshold_c,threshold_MeV=threshold_c,
        photon_MeV=gf,lab_excess_MeV=gf-(n+p-d),witnesses=cross),cases=rows)
    (ROOT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    fields=[k for k in rows[0] if k not in ['population','counts']]
    with (ROOT/'finite_preparation_grid.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows({k:z[k] for k in fields} for z in rows)
    print(json.dumps({k:v for k,v in result.items() if k not in ['cases','states']}))
if __name__=='__main__':main()
