from pathlib import Path
import json
P=Path(__file__).resolve().parent
r=json.loads((P/'results.json').read_text());v=json.loads((P/'verification.json').read_text())
b=r['particle_translation_conditional_bound'];base=json.loads((P/'reference_0_9_results.json').read_text())
ref=next(x for x in base['cases'] if x['cooling_s_inv']==.1 and x['scale_m_per_cell']==5*299792458 and x['target_cell']==[0,0,2] and x['attempt_probability']==.1 and x['observation_s']==180)
ko=f'''WRRA 부품 렌더링 후속 연구 0.10
핵 반동·환경 저장·광자 이동의 유한 4운동량 장부
최원식 / Wonsik Choi — 단독 저자
ORCID 0009-0001-4263-9772 | janefather@gmail.com
2026년 10월 4일
소수 부품 1.0: https://doi.org/10.5281/zenodo.23128482

검증 입력 → WRRA 고유 변환 → 산출값 → 반증조건
검증 입력: 0.6~0.9의 검증 질량·광자선·부품 출처·여섯 방사축, 고정 광속, 0.9의 공간 배치/접촉 규칙을 계승한다. 유한 환경의 초기 정지에너지는 각1,000,000,000MeV로 구성 선택하고 0.7의 외부 작업 예산0.002MeV도 별도 계승한다.
WRRA 고유 변환: 원래 슬롯을 가진 세 np쌍과 선행 베타 표지 → 중수소 포획·냉각 → 원천 두 d의 융합 → 광자 비행 → 별도 표적 d의 흡수·n/p 분해 → 핵자 냉각 → 재포획 또는 베타 종점. 매 사건에서 방사·핵·환경의 (에너지,3운동량)과 외부 작업 장부를 함께 갱신한다.
산출값: 23개 유한 사건 증인, 총359개 중간 상태에서 원천6mn, 총 운동량0, B=6,Q=L=0과 핵종 질량 shell을 재현했다. 광자 경로10광초에서 진공 비행 자체의 선택 작업 비용은0이며, 기존0.002MeV는 원천 내부의 두 준비 사건 비용으로만 기록된다.
반증조건: 사건의 출처 변경·반동/광자 중복·핵자 shell·환경 4운동량·외부 예산·에너지/운동량/Q/B/L 실패, 또는 준비를 고정한 관측의 불일치다.
판정: 0.10에서 핵 결합·분해와 냉각/광자 경로에 대한 유한 사건 수준의 4운동량 보존을 연결했다. 공간 이동의 실제 역학적 힘/비용이나 흡수 확률 q를 소수 표지에서 미시적으로 유도한 결과는 아니다. 0.9의 조건부 인구와 이번 사건별 운동량 증인을 결합한 WRRA 설명 성과다.

1. 계승 입력과 사건 준비
K15 작은 순서의 원천 두 np쌍 (0,129234),(1,129235), 표적 np쌍 (129232,258466)과 소수표지5/2,5/2,47/2를 고정한다. 세 초기 양성자 모티프 각각은 기존 전자+전자 반중성미자 표지의 한 유한 정지계 운동학 증인을 사용한다. p는 정지하고 e/반중성미자는 반대 방향으로 같은 크기의 운동량 k를 가지며 두 렙톤 에너지 합은 mn−mp다. k=[(mn−mp)^2−me^2]/[2(mn−mp)]로 계산한다. 이 대칭 준비는 0.6의 베타 분배 전체를 새로 도출하거나 대체하지 않는다.
따라서 세 n+p와 선행 렙톤 셋의 원천 에너지는6mn이고 총 운동량은0이다. 표적 첫 포획의 광자·반동·저장고를 먼저 실제 사건으로 생성한다. 초기 표적 d를 무상으로 추가하지 않는다.
정지 핵자 입력의 광자선은 포획2.223248711921MeV, 융합23.770682374953MeV이고 각각의 반동은0.001317658079MeV 및0.075795825047MeV다. 질량을 검증값으로 보정한 뒤 고유 장부로 재현하는 것은 정당한 현실 정합과 설명 성과다.

2. 4운동량을 갖는 냉각 저장
표적 첫 포획 광자 +x와 핵 반동 −x를 만들고, 원천의 두 포획 광자 +y/−y와 반동을 만든다. 각 뜨거운 중수소를 정지시킬 때 해당 반동의 에너지와 운동량을 명명된 유한 환경에 이전한다. 두 원천 d가 준비된 뒤 융합 광자는 +z, alpha 반동은 −z이며 alpha를 정지시킬 때 이를 융합 환경에 기록한다.
광자는0.9의 축상10광초 경로를 고정 c로 이동하고 표적에 도달한다. 비행 중 광자의 4운동량은 정지 진공 시험에서 유지된다. 흡수 사건에서 융합 광자 기록을 딱 한 번 지우고, 표적 d를 질량 shell을 만족하는 n+p 쌍으로 바꾼다. 세 유한 각도 cosθ=−1,0,+1의 최종 핵자 에너지·운동량을 실제 계산한다.
흡수 직후 두 핵자의 운동에너지 합 K=E_gamma−(mn+mp−md)={23.770682374953-(939.56542194+938.27208943-1875.612945):.12f}MeV이며 총 운동량은 들어온 광자와 같다. 냉각 완료 때 K와 두 핵자의 총 운동량을 분해 환경으로 옮긴다. 이는 완료 전후 4운동량 이전의 증인이다. 환경이 어떤 힘으로 어느 경로에서 핵자를 감속시키는지는 구성하지 않았다.
재포획 분기에서는 냉각된 n+p가 새 중수소·포획 광자·반동을 만들고 여섯 광자 방향을 계산한다. 원래 표적 포획 광자와 새로운 포획 광자는 서로 다른 기록으로 남긴다. 베타 분기에서는 냉각 중성자가 양성자로 바뀌고 한 전자/반중성미자 묶음을 추가한다. 중수소 상태에 자유중성자 수명을 넣지 않는다.

3. 유한 환경과 원천 밖 작업 장부
각 이름 붙은 환경의 최초 정지에너지 R=10^9MeV는 외부 배경이며 WRRA 원천 에너지에 더하지 않는다. 냉각마다 환경의 증가량 (ΔE,Δp)을 이전하고 최종 환경의 (R+ΔE)^2−|Δp|^2를 검사한다. 모든 증인의 환경 4운동량은 timelike이고 불변 정지에너지 증가가 가능하다. 이는 선언한 큰 유한 환경의 운동학 가능성 검증이며 온도·마찰·열역학적 엔트로피 계산은 아니다.
원천 두 d의 ‘반응 준비 완료’ 사건당 외부 작업0.001MeV를 원래0.002MeV 작업 은행에서 싱크로 이전한다. 은행+작업 싱크=0.002MeV를 항상 보존하고, 이 외부 에너지를6mn 핵·방사 원천에 중복 가산하지 않는다. 실제 이동거리·가속 방식이 입력되지 않았으므로 이0.001MeV를 역학적 운반 비용으로 재명명하지 않는다.
광자의 이상적 정지 진공 비행에는 추가 작업을0으로 둔다. 광자의 운동량은 존재하지만 별도의 추진 연료가 필요하다는 계산은 하지 않는다. 중력장·적색편이·산란 매질은 이 선택에 포함되지 않는다.

4. 광자 거리와 핵자 이동을 구별하는 경계
0.9 축상 거리10c초={b['photon_path_m']:,.0f}m는 광자가 이동한 거리다. 핵자가 같은 거리를10초에 이동한다고 바꾸면 평균 속도가 c가 되어 이 모형의 질량을 가진 d에는 불가능하다.
추가로 외부0.002MeV 전액을 단일 d의 운동에너지로 사용하고 회수를 고려하지 않는 제한 준비에서 γ=1+0.002/md이므로 최대 순간 속도 {b['maximum_inertial_speed_m_s_if_all_budget_given_as_kinetic']:,.3f}m/s, 그 속도를10초 유지해도 {b['maximum_distance_in_10s_m']:,.3f}m다. 이는 조건부 예산 경계다. 실제 핵자 수송을 가정한 거리·시간 관계의 도출 결과가 아니다. 0.7의 준비 표지가 두 공간 위치 사이 핵자 이동을 이미 수행했다는 판정은 하지 않는다.

5. 같은 장부와 원래 출처
모든 중간 상태에서 활성 핵자·전자/반중성미자·남은 포획/융합 광자+환경 증가분=6mn, 전체3운동량=0을 확인했다. 초기 표적 포획 광자, 원천 두 포획 광자, 융합 광자는 서로 별도 이벤트다. 흡수 시 원천 융합 광자만 제거한다.
모든 활성 핵종·전자·광자는 각 질량 shell을 만족한다. 포획 뒤 잔류 반동을 핵과 환경에 동시에 두지 않는다. 세 출처 슬롯 묶음은 반응의 산물까지 구분되어 보존되고 Q=0,B=6,L=0이다. 세 선행 전자/반중성미자와 베타 분기의 새 렙톤을 중복하지 않는다.
0.9의 144개 시간별 인구/접촉 조건은 입력 변경 없이 참조한다. 예를 들어 같은10초 광자 경로와 q=0.1에서180초 흡수 {100*ref['photon_absorbed']:.6f}%다. 이번23개 사건 증인은 흡수 여부·각도·재포획/베타 분기를 고정한 미시 사건 장부이며, 전체144조건의 각 운동량 방향 분포를 확률적으로 도출했다고 표현하지 않는다.

6. 감사·재현·열린 물리 규칙
{v['passed']}/{v['total']}개 질량 shell·전하/B/L·원천·운동량·환경·작업 검사 통과. 최대 사건 에너지 잔차 {v['maximum_event_energy_residual_MeV']:.3e}MeV, 운동량 잔차 {v['maximum_event_momentum_residual_MeV']:.3e}MeV. 23개 경로에359개 중간 상태가 있다. 감사 수는 독립 물리실험 수가 아니다. 새 폴더에서 입력·결과·한영 원고까지 동일 재실행한다.
이번 단계에서 닫은 것은 조건부 경로의 사건별 보존과 환경/외부 은행의 회계다. 냉각 힘·시간분포의 미시 도출, 핵자 실제 이동 경로, 흡수 q와 위치 배치의 물리적 확정, 모든 방향의 시간별 운동량 분포는 여전히 열려 있다. 0.11 통합에서는 닫힌 사건/인구 규칙의 범위를 공통 입력 장부에 표기하고 열린 매개변수를 이미 계산됐다고 처리하지 않아야 한다.
재현: OPENBLAS_NUM_THREADS=1 python compute.py; OPENBLAS_NUM_THREADS=1 python verify.py; python generate_report.py. Python, numpy, scipy. 원본 스냅샷·23개 사건 이력·검사·한영 원고·해시를 포함한다. 새 DOI·GitHub/Zenodo 등록 완료는 배정하지 않았다.
'''
en=f'''WRRA Parts Rendering Followup 0.10
Finite four-momentum ledger for recoil, cooling, photon flight and external work
Wonsik Choi / 최원식 — sole author
ORCID 0009-0001-4263-9772 | janefather@gmail.com
2026-10-04
Prime Parts 1.0: https://doi.org/10.5281/zenodo.23128482

Verified inputs → WRRA transformation → outputs → falsification
Inputs: preserve the0.6–0.9 calibrated masses, photon/recoil lines, six axial channels, original part origins, fixed c and the0.9 declared geometry/contact rule. A finite10^9MeV initial bath rest energy and the inherited0.002MeV external readiness-work bank are separate construction choices.
Transformation: three origin-tagged np pairs and pre-existing beta motifs → target/source captures and cooling → source fusion → photon flight → disjoint-target breakup → pair cooling → recapture or beta branch, updating every nuclear/radiation/bath four-vector and external-work ledger after each event.
Outputs:23 finite histories with359 intermediate states reproduce source6mn, zero total 3-momentum, B=6,Q=L=0 and particle mass shells. The photon travels a10-light-second chosen vacuum path at zero declared flight work. The separate0.002MeV pays only two source-local readiness events.
Falsification: loss or duplicate consumption of prime origins, photons or recoils; failure of mass shells, bath timelike condition, external bank, energy-momentum/Q/B/L or observation under the frozen configuration.
Verdict: finite event-level momentum conservation now connects source, photon and target histories. Cooling force/time law, actual mechanical transport cost and microscopic absorption q remain open, rather than being consequences of prime tags. The event witnesses and0.9 conditional population together are an explanatory result of this WRRA configuration.

1. Preparation and inherited calibration
The K15 small-order source pairs are(0,129234),(1,129235), the disjoint target is(129232,258466), tagged5/2,5/2,47/2. For each of three initial proton motifs, use a physically allowed zero-total-momentum lepton-pair witness: stationary proton and opposed electron/antineutrino momenta k=[(mn−mp)^2−me^2]/[2(mn−mp)], with lepton energies summing to mn−mp. This selected witness does not replace the complete0.6 beta response distribution.
Three np pairs plus their three inherited lepton pairs have initial source energy6mn and total momentum zero. The target initial deuteron is produced with its own photon/recoil/cooling record; no free mass is added. Calibrated masses yield capture/fusion lines2.223248711921/23.770682374953MeV and recoils0.001317658079/0.075795825047MeV. Their known numerical values legitimately calibrate the phenotype; the WRRA origin/transition/ledger link is the model's structural calculation.

2. Four-momentum cooling witnesses
Target first capture emits along +x, two source captures along +y and −y. Recoiling hot deuterons are stopped by transferring their complete kinetic energy and momentum to separately labelled finite baths. The fusion photon travels along +z; the alpha recoils along −z and is cooled into its bath.
The fusion photon flies along the inherited on-axis10-light-second path at fixed c. At absorption its record is removed exactly once. For cosine −1,0,+1, compute the neutron/proton four-vectors using the invariant d+gamma→n+p shell. Their summed kinetic energy is K={23.770682374953-(939.56542194+938.27208943-1875.612945):.12f}MeV and their combined momentum is the incoming photon momentum. Upon pair cooling both are transferred to the breakup bath. This is a four-momentum completion witness; the continuous braking force is unspecified.
Recapture produces a new deuteron, capture photon and recoil in each of six axial directions. Earlier target/source capture photons remain distinct. The alternative beta endpoint appends an electron/antineutrino pair and converts the cold free neutron; no free-neutron lifetime is attached to a bound deuteron.

3. Baths, external bank and the actual traveller
Every bath has an external initial rest energy R=10^9MeV, excluded from the WRRA source. Cooling increments are tracked as (ΔE,Δp); (R+ΔE)^2−|Δp|^2 remains timelike and permits nondecreasing bath invariant mass in every chosen history. This verifies kinematic compatibility with a declared large finite reservoir; it does not derive temperature, friction or entropy.
Each of two local source readiness events debits0.001MeV from a separate0.002MeV bank into a work sink. Bank+sink always equals0.002MeV. Neither term is added to the nuclear/radiation6mn. Since no local displacement or applied force was specified, this accounting token cannot be relabelled a calculated mechanical transport cost.
In the chosen static vacuum, photon flight has zero extra work and unchanged four-momentum. The photon, not a deuteron, traverses {b['photon_path_m']:,.0f}m in10s. Reinterpreting that distance as a massive deuteron's displacement over10s would require average speed c, which is inadmissible. Under the more restrictive assumption that all0.002MeV is its available kinetic energy without recovery, a deuteron's maximum speed is {b['maximum_inertial_speed_m_s_if_all_budget_given_as_kinetic']:,.3f}m/s and its10s upper distance {b['maximum_distance_in_10s_m']:,.3f}m. This is a conditional budget bound, not an actual source-to-target nucleon trajectory.

4. Shared conservation and scope
At all intermediate events, active particles+retained radiation+bath increments=6mn and their total vector momentum is zero. The source and target original capture records remain distinct; absorption consumes only the fusion record. Rest-to-kinetic-to-bath and fresh binding-to-photon transitions never count energy twice. All masses are on shell and Q=0,B=6,L=0. Origins remain disjoint.
The inherited0.9 144-case finite contact grid is retained without refitting; in its reference10s flight, q=.1,180s condition absorption is {100*ref['photon_absorbed']:.6f}%. The23 event histories condition on absorption, direction and recapture/beta outcomes. They do not constitute a derived probability law for all momentum directions in the144-case population grid.
{v['passed']}/{v['total']} implementation and mathematical checks passed across23 witnesses and359 event states. Maximum energy error {v['maximum_event_energy_residual_MeV']:.3e}MeV, vector momentum error {v['maximum_event_momentum_residual_MeV']:.3e}MeV. These counts are not independent physical experiments. The package includes inherited snapshots, event records, tests, bilingual report and hashes.
Closed in0.10: event-level four-momentum and finite bath/external-bank conservation for the declared paths. Still open: microscopic cooling/force and time laws, mechanical nucleon path, physical geometry/q identification and a momentum distribution for the entire time-dependent ensemble. The0.11 synthesis should keep these scopes explicit.
Run: OPENBLAS_NUM_THREADS=1 python compute.py; OPENBLAS_NUM_THREADS=1 python verify.py; python generate_report.py. Python,numpy,scipy. No new DOI or completed GitHub/Zenodo registration is asserted.
'''
(P/'WRRA_Parts_Followup_0_10_KO.txt').write_text(ko)
(P/'WRRA_Parts_Followup_0_10_EN.txt').write_text(en)
(P/'inputs.json').write_text(json.dumps(dict(stage='0.10',inherits='0.9 geometry/contact and 0.6-0.8 masses, rays, reaction labels',bath_initial_rest_MeV=1e9,external_work_bank_MeV=.002,local_readiness_work_per_event_MeV=.001,c_m_s=299792458,selected_fusion_path_m=10*299792458,initial_spectator_motif='three beta-compatible opposed electron-antineutrino pairs with zero total pair momentum',breakup_cosine_witnesses=[-1,0,1],recapture_axial_directions=6,scope='event-level selected histories; no full ensemble angular dynamics or microscopic cooling/absorption law'),indent=2)+'\n')
(P/'requirements.txt').write_text('numpy\nscipy\n')
