"""Finite 4-momentum witnesses for the prime-part source/target chain.

Baths are finite external reservoirs. Source readiness work is a separate
account; no mechanical distance is inferred from a prime-origin identifier.
"""
from pathlib import Path
import json,csv,math,hashlib
import numpy as np
import source07 as s
import previous09 as p9
P=Path(__file__).resolve().parent
R=1e9
AX=np.eye(3)
AXES=[AX[0],-AX[0],AX[1],-AX[1],AX[2],-AX[2]]
def vec(E,p=(0.,0.,0.)):return np.array([float(E),*np.asarray(p,dtype=float)])
def invariant(v):return v[0]**2-np.dot(v[1:],v[1:])
def lepton_pair(Q,Eaxis=AX[2]):
 k=(Q*Q-s.e*s.e)/(2*Q)
 return vec(math.sqrt(s.e*s.e+k*k),k*Eaxis),vec(k,-k*Eaxis)
class Ledger:
 def __init__(self):
  self.active={};self.rad={};self.baths={};self.snapshots=[]
  for i in range(3):
   self.active[f'n{i}']=vec(s.n);self.active[f'p{i}']=vec(s.p)
   e,nu=lepton_pair(s.n-s.p,AXES[i]);self.rad[f'e{i}']=e;self.rad[f'nu{i}']=nu
  self.work_bank=.002;self.work_sink=0.
  self.record('initial_three_neutron_motifs')
 def bath(self,key,v):self.baths[key]=self.baths.get(key,np.zeros(4))+v
 def work(self):
  self.work_bank-=.001;self.work_sink+=.001;self.record('local_readiness_work')
 def record(self,event):
  vals=list(self.active.values())+list(self.rad.values())+list(self.baths.values())
  total=np.sum(vals,axis=0) if vals else np.zeros(4)
  energy_error=total[0]-6*s.n
  momentum_error=float(np.linalg.norm(total[1:]))
  source_baryons=sum(4 if k.startswith('alpha') else 2 if k.startswith('d') else 1 for k in self.active)
  charge=sum(2 if k.startswith('alpha') else 1 if k.startswith(('d','p')) else 0 for k in self.active)-sum(k.startswith('e') for k in self.rad)
  leptons=sum(k.startswith('e') for k in self.rad)-sum(k.startswith('nu') for k in self.rad)
  assert abs(energy_error)<3e-9,(event,energy_error)
  assert momentum_error<5e-13,(event,momentum_error)
  assert source_baryons==6 and charge==leptons==0,(event,source_baryons,charge,leptons)
  assert abs(self.work_bank+self.work_sink-.002)<1e-15 and self.work_bank>=-1e-15
  reservoir=[]
  for name,v in self.baths.items():
   mass_after=math.sqrt(invariant(v+vec(R)))
   assert mass_after>=R-5e-7,(event,name,mass_after)
   reservoir.append(dict(name=name,energy_gain_MeV=float(v[0]),momentum_MeV=v[1:].tolist(),
    invariant_mass_gain_MeV=mass_after-R))
  self.snapshots.append(dict(event=event,energy_residual_MeV=float(energy_error),momentum_residual_MeV=momentum_error,
   active={k:v.tolist() for k,v in self.active.items()},radiation={k:v.tolist() for k,v in self.rad.items()},bath=reservoir,work_bank_MeV=self.work_bank,
   work_spent_MeV=self.work_sink,baryon=source_baryons,charge=charge,lepton=leptons))
 def capture(self,i,direction,label):
  assert f'n{i}' in self.active and f'p{i}' in self.active
  self.active.pop(f'n{i}');self.active.pop(f'p{i}')
  self.active[f'd{i}']=vec(math.sqrt(s.d*s.d+s.gc*s.gc),-s.gc*direction)
  self.rad[f'g_c_{i}_{label}']=vec(s.gc,s.gc*direction)
  self.record(label+'_emission')
  self.cool(f'd{i}',f'bath_c_{i}',label)
 def cool(self,key,bath,label):
  old=self.active[key];mass={'d':s.d,'alpha':s.a,'n':s.n,'p':s.p}[key.rstrip('0123456789')]
  new=vec(mass)
  self.active[key]=new;self.bath(bath,old-new)
  self.record(label+'_cooling')
 def fusion(self):
  self.active.pop('d0');self.active.pop('d1')
  self.active['alpha01']=vec(math.sqrt(s.a*s.a+s.gf*s.gf),-s.gf*AX[2])
  self.rad['g_f']=vec(s.gf,s.gf*AX[2]);self.record('fusion_emission')
  self.cool('alpha01','bath_fusion','fusion')
 def flight(self,L):
  assert L>=0 and 'g_f' in self.rad
  self.record('photon_flight_'+str(L)+'_m')
 def breakup(self,cosine):
  assert 'd2' in self.active and 'g_f' in self.rad
  self.active.pop('d2');self.rad.pop('g_f')
  w=s.d*s.d+2*s.d*s.gf;cm=math.sqrt(w)
  enstar=(w+s.n*s.n-s.p*s.p)/(2*cm);k=math.sqrt(enstar*enstar-s.n*s.n)
  boost=s.gf/(s.d+s.gf);gamma=(s.d+s.gf)/cm
  px=k*math.sqrt(1-cosine*cosine)
  en=gamma*(enstar+boost*k*cosine)
  pn=np.array([px,0.,gamma*(k*cosine+boost*enstar)])
  ep=s.d+s.gf-en;pp=np.array([-px,0.,s.gf-pn[2]])
  self.active['n2']=vec(en,pn);self.active['p2']=vec(ep,pp)
  self.record('fusion_photon_absorbed_breakup_'+str(cosine))
  self.bath('bath_target_breakup',(self.active['n2']-vec(s.n))+(self.active['p2']-vec(s.p)))
  self.active['n2']=vec(s.n);self.active['p2']=vec(s.p)
  self.record('target_pair_cooling')
 def recapture(self,direction):self.capture(2,direction,'target_recapture')
 def beta(self):
  assert 'n2' in self.active
  self.active['p_beta2']=vec(s.p);self.active.pop('n2')
  e,nu=lepton_pair(s.n-s.p,-AX[1]);self.rad['e_beta']=e;self.rad['nu_beta']=nu
  self.record('target_neutron_beta')

def main():
 labels={'source_pairs':p9.SRC,'target_pair':p9.TARGET,'source_cell':p9.SOURCE,'target_cell':[0,0,2]}
 witnesses=[]
 for direction in AXES:
  for cosine in [-1.,0.,1.]:
   led=Ledger();led.capture(2,AX[0],'target_initial_capture')
   led.capture(0,AX[1],'source_first_capture');led.capture(1,-AX[1],'source_second_capture')
   led.work();led.work();led.fusion();led.flight(10*299792458)
   led.breakup(cosine);led.recapture(direction)
   witnesses.append(dict(kind='recapture',cosine=cosine,recapture_axis=direction.tolist(),origins=labels,events=led.snapshots))
 for cosine in [-1.,0.,1.]:
  led=Ledger();led.capture(2,AX[0],'target_initial_capture')
  led.capture(0,AX[1],'source_first_capture');led.capture(1,-AX[1],'source_second_capture')
  led.work();led.work();led.fusion();led.flight(10*299792458);led.breakup(cosine);led.beta()
  witnesses.append(dict(kind='beta',cosine=cosine,origins=labels,events=led.snapshots))
 # Controls preserve the ray and 6mn when a declared finite contact does not absorb it.
 for kind in ['missed_target','contact_failure']:
  led=Ledger();led.capture(2,AX[0],'target_initial_capture')
  led.capture(0,AX[1],'source_first_capture');led.capture(1,-AX[1],'source_second_capture')
  led.work();led.work();led.fusion();led.flight(10*299792458);led.record(kind+'_escape')
  witnesses.append(dict(kind=kind,origins=labels,events=led.snapshots))
 # Conditional local material transport lower bound. The source-to-target
 # distance is traversed by a photon only, never by the cooled deuterons.
 W=.002;M=s.d;gamma=1+W/M
 vmax=299792458*math.sqrt(1-1/(gamma*gamma))
 bound=dict(external_work_budget_MeV=W,one_deuteron_rest_MeV=M,
  maximum_inertial_speed_m_s_if_all_budget_given_as_kinetic=vmax,
  maximum_distance_in_10s_m=vmax*10,photon_path_m=10*299792458,
  fixed_time_for_photon_path_s=10,
  particle_traversal_of_photon_path_in_10s='fails v<c independent of budget')
 result=dict(version='0.10',author='Wonsik Choi',witnesses=witnesses,
  environment_initial_rest_MeV=R,particle_translation_conditional_bound=bound,
  photon_vacuum_work_MeV=0,source_local_readiness_external_work_MeV=.002,
  coupled_probability_grid='0.9 finite grid inherited, not recalibrated',
  origin_input_sha256=hashlib.sha256((P/'reference_origin_examples.json').read_bytes()).hexdigest())
 (P/'results.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(dict(witnesses=len(witnesses),events=sum(len(w['events']) for w in witnesses),
  maximum_energy_residual_MeV=max(abs(e['energy_residual_MeV']) for w in witnesses for e in w['events']),
  maximum_momentum_residual_MeV=max(e['momentum_residual_MeV'] for w in witnesses for e in w['events']),
  bound=bound)))
if __name__=='__main__':main()
