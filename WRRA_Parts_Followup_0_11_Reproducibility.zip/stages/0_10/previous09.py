"""Prime-origin-preserving finite axial routing with discrete contact attempts.

Origin slots are identifiers. Geometry and per-attempt coupling are external
configuration fields, never inferred from the prime integers themselves.
"""
from pathlib import Path
import csv,json,itertools,hashlib
import numpy as np
from scipy.special import roots_legendre
import previous08 as prior
P=Path(__file__).resolve().parent
origins=json.loads((P/'reference_origin_examples.json').read_text())
SRC=[x['source_pair'] for x in origins[:2]]; TARGET=origins[2]['source_pair']
AXES=[(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
SOURCE=(0,0,0)
def rays(target):
 delta=tuple(b-a for a,b in zip(SOURCE,target))
 matches=[j for j,axis in enumerate(AXES) if any(delta) and sum(delta[k]*axis[k] for k in range(3))>0 and all(delta[k]==axis[k]*sum(delta[l]*axis[l] for l in range(3)) for k in range(3))]
 return matches
def run(cooling,scale_m,position,q,t,attempt_dt=1.,attempts=10,nodes=64,solvers=None):
 sol,tar=solvers or prior.setup(cooling)
 aligned=len(rays(position))/len(AXES)
 distance_cells=np.linalg.norm(np.subtract(position,SOURCE));tau=distance_cells*scale_m/prior.C
 M=attempts;dt=attempt_dt;F=lambda u:0. if u<=0 else float(np.sum(sol(u)[25:27]))
 f=F(t);flight=aligned*(f-F(t-tau));escaped=(1-aligned)*f+aligned*(1-q)**M*F(t-tau-M*dt)
 contact=0.;absorbed=0.;target_prob=np.zeros(5)
 x,w=roots_legendre(nodes);jidx=prior.s.ST.index(('T','T'))
 for k in range(M):
  upper=t-tau-k*dt;lower=upper-dt
  if upper>0:
   contact+=aligned*(1-q)**(k+1)*(F(upper)-F(lower)) if lower>=0 else aligned*(1-q)**(k+1)*F(upper)
   mass=aligned*q*(1-q)**k*F(upper)
   absorbed+=mass
   if mass>0:
    u=(x+1)*upper/2;weights=w*upper/2
    flux=(100/878.3)*sol(u)[jidx,:]
    response=tar(upper-u)
    target_prob+=aligned*q*(1-q)**k*(response@(weights*flux))
 source=sol(t);rest=source[:27]@prior.s.L[:,:5]
 combined=rest+(1-absorbed)*prior.T0+target_prob@prior.TL
 combined=combined.copy();combined[2]-=prior.s.gf*absorbed
 return dict(cooling_s_inv=cooling,scale_m_per_cell=scale_m,target_cell=list(position),distance_cells=distance_cells,
  flight_time_s=tau,aligned_axes=rays(position),aligned_fraction=aligned,attempt_probability=q,attempt_dt_s=dt,
  attempt_count=M,observation_s=t,source_fusion=f,photon_flight=flight,photon_contact=contact,
  photon_escape=escaped,photon_absorbed=absorbed,photon_partition_residual=f-flight-contact-escaped-absorbed,
  target_unabsorbed_d=1-absorbed,target_hot_np=float(target_prob[0]),target_cold_np=float(target_prob[1]),
  target_beta_endpoint=float(target_prob[2]),target_recaptured_hot_d=float(target_prob[3]),
  target_recaptured_cold_d=float(target_prob[4]),target_surviving_d=float(1-absorbed+target_prob[3]+target_prob[4]),
  target_population_residual=float(1-absorbed+target_prob.sum()-1),new_capture_photons=float(target_prob[3]+target_prob[4]),
  combined_energy_residual_MeV=float(combined.sum()-6*prior.s.n),combined_photon_MeV=float(combined[2]),
  external_work_remaining_MeV=float(.002-.001*source[34]))
def main():
 rows=[]
 for cooling in [.01,.1]:
  solvers=prior.setup(cooling)
  for scale,position,q,t in itertools.product([prior.C/2,5*prior.C,50*prior.C],[(0,0,2),(1,0,2)],[0.,.1,.5,1.],[30.,180.,600.]):
   rows.append(run(cooling,scale,position,q,t,solvers=solvers))
 meta=dict(version='0.9',source_origin=SRC,target_origin=TARGET,axes=AXES,source_cell=SOURCE,
  inputs_hash_sha256=hashlib.sha256((P/'reference_0_6_results.json').read_bytes()).hexdigest(),
  geometry_status='External finite embedding; prime slots do not encode coordinates',
  coupling_status='External per-attempt probability; no derivation from prime tags',
  cases=rows)
 (P/'results.json').write_text(json.dumps(meta,indent=2)+'\n')
 with (P/'finite_contact_grid.csv').open('w') as f:
  fields=[k for k in rows[0] if k!='aligned_axes'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  w.writerows({k:json.dumps(z[k]) if isinstance(z[k],list) else z[k] for k in fields} for z in rows)
 print(json.dumps(dict(cases=len(rows),max_energy_residual=max(abs(z['combined_energy_residual_MeV']) for z in rows),max_partition_residual=max(abs(z['photon_partition_residual']) for z in rows))))
if __name__=='__main__':main()
