"""Independent 4-vector, provenance, work and inherited-population audit."""
from pathlib import Path
import json,math,hashlib
import numpy as np
P=Path(__file__).resolve().parent
r=json.loads((P/'results.json').read_text())
base=json.loads((P/'reference_0_9_results.json').read_text())
mass=json.loads((P/'reference_0_6_results.json').read_text())['inherited_masses_MeV']
M={'n':mass['neutron'],'p':mass['proton'],'d':mass['deuteron'],'alpha':mass['alpha_nucleus']}
e=mass['electron'];checks={};maximum_mass_shell=0.;events=0
def check(key,truth):
 checks[key]=bool(truth)
 if not truth:raise AssertionError(key)
def inv(v):
 z=np.asarray(v);return z[0]*z[0]-np.dot(z[1:],z[1:])
expected_origin={'source_pairs':base['source_origin'],'target_pair':base['target_origin'],
 'source_cell':base['source_cell'],'target_cell':[0,0,2]}
check('inherited_grid_kept',len(base['cases'])==144)
check('mass_source_is_inherited',abs(r['witnesses'][0]['events'][0]['active']['n0'][0]-M['n'])<1e-12)
for i,w in enumerate(r['witnesses']):
 check(f'origin_{i}',w['origins']==expected_origin)
 first=w['events'][0];check(f'initial_six_baryons_{i}',first['baryon']==6)
 absorbed=False
 for j,h in enumerate(w['events']):
  events+=1
  particles=list(h['active'].values())+list(h['radiation'].values())
  four=np.sum(np.asarray(particles),axis=0)+sum((np.array([b['energy_gain_MeV'],*b['momentum_MeV']]) for b in h['bath']),start=np.zeros(4))
  check(f'four_conservation_{i}_{j}',abs(four[0]-6*M['n'])<2e-9 and np.linalg.norm(four[1:])<2e-10)
  check(f'QBL_{i}_{j}',(h['charge'],h['baryon'],h['lepton'])==(0,6,0))
  check(f'work_{i}_{j}',abs(h['work_spent_MeV']+h['work_bank_MeV']-.002)<1e-15 and h['work_bank_MeV']>=-1e-15)
  for name,v in {**h['active'],**h['radiation']}.items():
   if name.startswith('alpha'):expected=M['alpha']**2
   elif name.startswith('nu') or name.startswith('g_'):expected=0.
   elif name.startswith('e'):expected=e**2
   else:expected=M[name[0]]**2
   err=abs(inv(v)-expected);maximum_mass_shell=max(maximum_mass_shell,err)
   check(f'shell_{i}_{j}_{name}',err<2e-8)
  for b in h['bath']:
   state=np.array([r['environment_initial_rest_MeV']+b['energy_gain_MeV'],*b['momentum_MeV']])
   check(f'bath_timelike_{i}_{j}_{b["name"]}',inv(state)>=r['environment_initial_rest_MeV']**2-1000.)
  if h['event'].startswith('fusion_photon_absorbed_breakup'):
   check(f'single_fusion_consumption_{i}',not absorbed and 'g_f' not in h['radiation'])
   absorbed=True
  if h['event'].endswith('_escape'):
   check(f'escape_keeps_photon_{i}','g_f' in h['radiation'] and not absorbed)
 if w['kind'] in ('recapture','beta'):check(f'absorption_path_{i}',absorbed)
 else:check(f'escape_path_{i}',not absorbed)
 if w['kind']=='recapture':
  end=w['events'][-1]['radiation']
  check(f'old_and_new_capture_{i}',any(k.startswith('g_c_2_target_initial') for k in end) and any(k.startswith('g_c_2_target_recapture') for k in end))
bound=r['particle_translation_conditional_bound'];c=299792458
gamma=1+bound['external_work_budget_MeV']/M['d']
check('finite_kinetic_bound',abs(bound['maximum_inertial_speed_m_s_if_all_budget_given_as_kinetic']/c-math.sqrt(1-1/gamma**2))<1e-14)
check('photon_vs_particle_path',bound['maximum_distance_in_10s_m']<bound['photon_path_m'] and bound['photon_path_m']/c==10)
check('vacuum_photon_work_declared_zero',r['photon_vacuum_work_MeV']==0)
out=dict(passed=sum(checks.values()),total=len(checks),events=events,witnesses=len(r['witnesses']),max_shell_MeV_squared=maximum_mass_shell,
 maximum_event_energy_residual_MeV=max(abs(h['energy_residual_MeV']) for w in r['witnesses'] for h in w['events']),
 maximum_event_momentum_residual_MeV=max(abs(h['momentum_residual_MeV']) for w in r['witnesses'] for h in w['events']),checks=checks)
(P/'verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='checks'}))
