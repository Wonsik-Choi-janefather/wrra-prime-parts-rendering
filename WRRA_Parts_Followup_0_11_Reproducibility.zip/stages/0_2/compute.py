"""Energy funding candidates for the fixed finite additive renderer.
All supplied rest energies are recorded inputs, not derived masses.
"""
from pathlib import Path
import math,json,csv
import numpy as np
B=Path(__file__).resolve().parent;cfg=json.loads((B/'inputs.json').read_text())
N=cfg['N'];m=cfg['recorded_rest_energies_MeV'];pe=m['proton']+m['electron'];ne=m['neutron'];Q=ne-pe
checks={}
def check(key,ok):
 checks[key]=bool(ok)
 if not ok:raise AssertionError(key)
s=np.ones(N+1,bool);s[:2]=False
for p in range(2,math.isqrt(N)+1):
 if s[p]:s[p*p::p]=False
v=np.arange(2,N+1);mask=(v%2==1)&~s[2:];n=v[mask];w=n.astype(float)**-cfg['alpha'];w/=w.sum()
assemblies=[];rows=[];samples=[];cache=[]
for K in [15,16]:
 pool=np.flatnonzero(s)[:K]
 for order,parts in [('small',pool),('large',pool[::-1])]:
  cyc=n//parts.sum();c=np.repeat(cyc[:,None],K,axis=1);r=n-cyc*parts.sum()
  while np.any(r>=2):
   for j,p in enumerate(parts):
    fits=r>=p;c[:,j]+=fits;r-=p*fits
  neutron=np.isin(parts,cfg['neutron_component_labels']);M=np.where(neutron,ne,pe)
  cost=c@M;count=c.sum(axis=1);avg=w@c;mean_count=float(w@count);mean_n=float(w@n);mean_r=float(w@r);mean_cost=float(w@cost)
  check(f'address_sum_{K}_{order}',np.all(c@parts+r==n))
  # Local linear funding preserves each address; every present prime must be funded.
  active=avg>0;local_floor=float(np.max(M[active]/parts[active]))
  address_floor=float(np.max(cost/n));critical=int(n[np.argmax(cost/n)])
  # Full ensemble pooling: available energy includes residual, not reserved locally.
  pooled_floor=mean_cost/mean_n
  # Requiring one common epsilon for all K/orders selects the maximum local floor.
  eps=local_floor;supply=eps*n;funded_parts=c@(eps*parts);part_surplus=funded_parts-cost;residue=eps*r
  check(f'linear_no_negative_part_energy_{K}_{order}',np.min(eps*parts-M)>=-1e-10)
  check(f'linear_energy_closed_{K}_{order}',np.allclose(supply,cost+part_surplus+residue,rtol=1e-12,atol=1e-6))
  # Pair rest energy is shared over proton and electron; never charged twice.
  check(f'pair_rest_not_doubled_{K}_{order}',math.isclose(pe,m['proton']+m['electron'],abs_tol=1e-12))
  check(f'charge_pair_{K}_{order}',np.all(c[:,~neutron].sum(axis=1)-c[:,~neutron].sum(axis=1)==0))
  # Global-only minimal pool has zero average surplus but individual shortfalls.
  pooled_supply=pooled_floor*n;short=np.maximum(cost-pooled_supply,0);surplus=np.maximum(pooled_supply-cost,0)
  check(f'pooled_transfer_balance_{K}_{order}',abs(float(w@short)-float(w@surplus))<1e-7)
  check(f'pooled_local_failure_detected_{K}_{order}',np.any(short>1e-9))
  # Equal motif candidate: input maximum rest energy pays each p+e or n motif.
  E0=max(pe,ne);equal_supply=E0*(count+r);equal_surplus=c@(E0-M);equal_residue=E0*r
  check(f'equal_motif_nonnegative_{K}_{order}',np.all(equal_surplus>=-1e-10))
  check(f'equal_motif_closed_{K}_{order}',np.allclose(equal_supply,cost+equal_surplus+equal_residue,rtol=1e-12,atol=1e-6))
  # Mass-aware reference mapping: known masses assigned per species, residue keeps E0*r.
  aware_supply=cost+E0*r
  cache.append({'K':K,'order':order,'cost':cost,'count':count,'residue':r,'equal_input':equal_supply,'mean_count':mean_count})
  check(f'mass_aware_closed_{K}_{order}',np.allclose(aware_supply,cost+E0*r,rtol=1e-12,atol=1e-6))
  check(f'equal_motif_pe_surplus_is_beta_Q_{K}_{order}',abs(E0-pe-Q)<1e-12)
  def energy_row(name,total,open_energy,residual,status):
   avg_total=float(w@total);avg_open=float(w@open_energy);avg_res=float(w@residual)
   rest_fraction=mean_cost/avg_total;open_fraction=avg_open/avg_total;res_fraction=avg_res/avg_total
   check(f'mean_energy_partition_{name}_{K}_{order}',abs(rest_fraction+open_fraction+res_fraction-1)<1e-10)
   rows.append({'K':K,'order':order,'candidate':name,'mean_input_MeV_per_admitted_address':avg_total,'input_MeV_per_initial_baryon_motif':avg_total/mean_count,'rest_MeV_per_initial_baryon_motif':mean_cost/mean_count,'open_MeV_per_initial_baryon_motif':avg_open/mean_count,'residue_MeV_per_initial_baryon_motif':avg_res/mean_count,'rest_fraction_of_input':rest_fraction,'open_fraction_of_input':open_fraction,'residue_fraction_of_input':res_fraction,'cosmic_rest_percent_if_input_sector_5percent':5*rest_fraction,'cosmic_open_percent_if_input_sector_5percent':5*open_fraction,'cosmic_residue_percent_if_input_sector_5percent':5*res_fraction,'input_sector_percent_if_rest_fixed_5percent':5/rest_fraction,'status':status})
  energy_row('linear_local',supply,part_surplus,residue,'local per-prime funding; epsilon at smallest feasible value; excess unresolved')
  # Pooled supply conservation is ensemble-wide, not addresswise, so no energy_row assertion.
  rows.append({'K':K,'order':order,'candidate':'linear_pooled','epsilon_MeV_per_address_unit':pooled_floor,'shortfall_address_count':int(np.sum(short>1e-9)),'shortfall_conditional_address_weight':float(w[short>1e-9].sum()),'required_mean_transfer_MeV_per_admitted_address':float(w@short),'status':'mean-funded with transfers; rejects local independent-address interpretation; no transport law supplied'})
  energy_row('equal_motif',equal_supply,equal_surplus,equal_residue,'common motif rest ceiling; surplus not automatically photons; binding absent')
  energy_row('mass_aware_reference',aware_supply,np.zeros_like(cost),E0*r,'verified masses assigned; valid calibrated closure; not mass derivation')
  assemblies.append({'K':K,'order':order,'mean_count':mean_count,'mean_address':mean_n,'epsilon_local_min_MeV_per_address_unit':local_floor,'epsilon_address_min_MeV_per_address_unit':address_floor,'address_at_maximum_cost_per_n':critical,'epsilon_pooled_min_MeV_per_address_unit':pooled_floor,'local_scope':'per-prime','address_scope':'may redistribute within one address; residual available','pooled_scope':'may redistribute between addresses','nonuniqueness':'any larger epsilon remains feasible and increases excess'})
  for j,p in enumerate(parts):samples.append({'K':K,'order':order,'prime':int(p),'motif':'n' if neutron[j] else 'p+e','rest_MeV':float(M[j]),'linear_supply_MeV':float(eps*p),'linear_excess_MeV':float(eps*p-M[j]),'equal_supply_MeV':E0,'equal_excess_MeV':float(E0-M[j])})
check('same_local_floor_all_orders',max(x['epsilon_local_min_MeV_per_address_unit'] for x in assemblies)-min(x['epsilon_local_min_MeV_per_address_unit'] for x in assemblies)<1e-12)
# Alternative count-based supplies differ by assembly. For an honest common-source
# comparison, use one finite envelope, frozen across all four renderers.
common_input=np.maximum.reduce([x['equal_input'] for x in cache]);mean_common=float(w@common_input)
common_rows=[]
for item in cache:
 residual=ne*item['residue'];excess=common_input-item['cost']-residual
 check(f"shared_source_nonnegative_{item['K']}_{item['order']}",np.all(excess>=-1e-6))
 check(f"shared_source_closure_{item['K']}_{item['order']}",np.allclose(common_input,item['cost']+residual+excess,rtol=1e-12,atol=1e-6))
 common_rows.append({'K':item['K'],'order':item['order'],'common_mean_input_MeV_per_admitted_address':mean_common,'cosmic_rest_percent_if_input_sector_5percent':5*float(w@item['cost'])/mean_common,'cosmic_open_percent_if_input_sector_5percent':5*float(w@excess)/mean_common,'cosmic_residual_percent_if_input_sector_5percent':5*float(w@residual)/mean_common,'input_MeV_per_generated_baryon_motif':mean_common/item['mean_count'],'status':'one shared envelope across four renderers; declared finite construction, not derived source Hamiltonian'})
# Pair production is not proton+electron motif production: latter includes baryon number.
check('pe_motif_baryon_not_pair_creation',cfg['proton_electron_motif_baryon_number']==1)
out={'version':'0.2','author':'Wonsik Choi','verified_inputs':cfg,'WRRA_transformation':'fixed renderer -> motif rest costs -> local/address/pooled funding inequalities -> common energy allocation -> explicit cosmic-denominator alternatives','assemblies':assemblies,'energy_candidates':rows,'shared_source_comparison':common_rows,'part_supply_table':samples,'beta_Q_MeV':Q,'checks':checks,'passed':sum(checks.values()),'total':len(checks),'decision':'equal_motif reduces excess for a specified renderer; its raw source budget is order dependent. Shared-envelope comparison fixes one input across four cases. Mass-aware reference supplies a calibrated baseline. Linear local remains feasible but produces large unassigned excess. No physical transport or release spectrum derived.','falsification_conditions':['negative funded rest margin','energy/baryon/charge closure failure','unavailable required pool transfers','a proposed physical excess branch incompatible with observed energy or radiation constraints'],'scope':'rest masses supplied; nuclear binding not included; no pair-creation Hamiltonian, no SI density or vacuum reservoir inferred from5%'}
(B/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
with (B/'part_supply.csv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=list(samples[0]));writer.writeheader();writer.writerows(samples)
print(json.dumps({'passed':out['passed'],'total':out['total'],'assemblies':assemblies,'K16_small':[x for x in rows if x['K']==16 and x['order']=='small']},ensure_ascii=False,indent=2))
