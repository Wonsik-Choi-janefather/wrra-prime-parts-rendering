WRRA prime-parts followup0.2 | Wonsik Choi only
Run python compute.py (numpy).
Finite fixed decoder energy funding candidates, local/address/pool floors, equal-motif and mass-aware reference, common input envelope. No physical production dynamics, binding or release spectra yet.
