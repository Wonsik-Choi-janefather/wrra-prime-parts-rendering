"""Scalar adaptive absorption integrals and analytic target-state audit."""
from pathlib import Path
import json,numpy as np
from scipy.integrate import quad
from scipy.linalg import expm
import compute as c
P=Path(__file__).resolve().parent;r=json.loads((P/'results.json').read_text());checks={}
def ck(name,ok):
 checks[name]=bool(ok)
 if not ok:raise AssertionError(name)
solvers={x:c.setup(x) for x in [.01,.1]}
def analytic_target(t,rate):
 t=np.asarray(t);gb=1/878.3;kc=100*gb;lam=gb+kc;diff=lam-rate
 x=np.exp(-rate*t);a=rate/diff*(x-np.exp(-lam*t))
 b=gb*rate/diff*((-np.expm1(-rate*t))/rate-(-np.expm1(-lam*t))/lam)
 h=kc*rate/diff*(t*x-(x-np.exp(-lam*t))/diff)
 d=1-x-a-b-h
 return np.array([x,a,b,h,d])
for rate,(src,tar) in solvers.items():
 q,_,_=c.s.build(rate,rate,0)
 for t in [0.,1.,30.,180.,600.]:
  initial=np.zeros(27);initial[0]=1
  ck(f'source_exponential_{rate}_{t}',max(abs(src(t)[:27]-initial@expm(q*t)))<2e-11)
  ck(f'analytic_target_{rate}_{t}',max(abs(tar(t)-analytic_target(t,rate)))<2e-11)
ck('target_initial_energy',abs(c.T0.sum()-2*c.s.n)<1e-12)
ck('target_absorbed_shells',max(abs(c.TL.sum(axis=1)-(2*c.s.n+c.s.gf)))<2e-12)
max_scalar=0.;max_resolution=0.
for i,z in enumerate(r['cases']):
 ck(f'energy_{i}',abs(z['energy_residual_MeV'])<1e-8)
 ck(f'external_work_{i}',z['external_work_MeV']>=-1e-12 and z['external_work_remaining_MeV']>=-1e-12 and abs(z['external_work_MeV']+z['external_work_remaining_MeV']-.002)<1e-15)
 ck(f'photon_partition_{i}',abs(z['photon_balance_residual'])<1e-10)
 ck(f'population_{i}',abs(z['target_population_normalization_residual'])<1e-10)
 ck(f'nonnegative_{i}',min(z[k] for k in ['photon_in_flight','photon_in_contact','photon_escaped','photon_absorbed','target_unabsorbed_deuteron_probability','target_hot_np_probability','target_cold_np_probability','target_beta_endpoint_probability','target_recaptured_hot_d_probability','target_recaptured_cold_d_probability'])>=-2e-11)
 ck(f'one_photon_one_target_{i}',z['photon_absorbed']<=z['aligned_fraction']*z['source_fusion_probability']+1e-11 and z['additional_capture_photons']<=z['photon_absorbed']+1e-11)
 if z['aligned_fraction']==0 or z['absorption_hazard_s_inv']==0 or z['flight_time_s']>=z['time_s']:
  ck(f'blocked_absorption_{i}',abs(z['photon_absorbed'])<1e-14)
 if z['aligned_fraction']==1/6 and z['time_s']==180:
  src,tar=solvers[z['cooling_s_inv']];last=max(0,180-z['flight_time_s']);split=max(0,last-z['contact_window_s'])
  def integrand(u):
   j=(100/878.3)*src(u)[c.s.ST.index(('T','T'))]
   return j*(-np.expm1(-z['absorption_hazard_s_inv']*min(z['contact_window_s'],last-u)))/6
  expected=sum(quad(integrand,lo,hi,epsabs=2e-13,epsrel=2e-12)[0] for lo,hi in [(0,split),(split,last)] if hi>lo)
  err=abs(expected-z['photon_absorbed']);max_scalar=max(max_scalar,err)
  ck(f'adaptive_absorption_{i}',err<2e-10)
  if z['flight_time_s'] in [10.,100.] and z['absorption_hazard_s_inv'] in [.01,1.] and z['contact_window_s']==10:
   high=c.integrate(z['cooling_s_inv'],z['flight_time_s'],z['absorption_hazard_s_inv'],z['contact_window_s'],z['aligned_fraction'],z['time_s'],nodes=128,solvers=solvers[z['cooling_s_inv']])
   err=max(abs(z[k]-high[k]) for k in ['photon_absorbed','target_hot_np_probability','target_cold_np_probability','target_beta_endpoint_probability','target_recaptured_hot_d_probability','target_recaptured_cold_d_probability'])
   max_resolution=max(max_resolution,err);ck(f'resolution_{i}',err<2e-10)
# Cross-absorption and finite reservoir completion witnesses.
raw=json.loads((P/'reference_0_7_results.json').read_text())
witnesses=raw['fusion_photon_deuteron_breakup']['witnesses']
for i,w in enumerate(witnesses):
 pn=np.array(w['neutron_momentum_MeV']);pp=np.array(w['proton_momentum_MeV'])
 ck(f'absorb_shell_n_{i}',abs(w['neutron_energy_MeV']**2-pn@pn-c.s.n**2)<1e-8)
 ck(f'absorb_shell_p_{i}',abs(w['proton_energy_MeV']**2-pp@pp-c.s.p**2)<1e-8)
 ck(f'absorb_energy_{i}',abs(w['neutron_energy_MeV']+w['proton_energy_MeV']-c.s.d-c.s.gf)<1e-12)
 ck(f'absorb_momentum_{i}',max(abs(pn+pp-[0,0,c.s.gf]))<1e-12)
 bath_E=1e9+c.K;bath_p=c.s.gf
 ck(f'cooling_timelike_{i}',bath_E**2-bath_p**2>1e18)
ck('capture_line_cannot_break_cold_deuteron',c.s.gc<raw['cold_photon_thresholds_MeV']['deuteron_breakup'])
audit=dict(passed=sum(checks.values()),total=len(checks),maximum_adaptive_absorption_error=max_scalar,maximum_64_128_population_difference=max_resolution,checks=checks)
(P/'verification.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({k:v for k,v in audit.items() if k!='checks'}))
