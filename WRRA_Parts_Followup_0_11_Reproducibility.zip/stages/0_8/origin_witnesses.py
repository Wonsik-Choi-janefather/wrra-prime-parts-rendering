"""Finite histories: disjoint prime-part origins and one consumed photon."""
from pathlib import Path
import json,numpy as np
import compute as c
P=Path(__file__).resolve().parent
origin=json.loads((P/'reference_origin_examples.json').read_text())
source=[z['source_pair'] for z in origin[:2]];target_origin=origin[2]['source_pair']
allslots=[j[k] for j in source+[target_origin] for k in ['n_source_slot','p_source_slot']]
assert len(set(allslots))==6
rng=np.random.default_rng(8042026);q,_,edges=c.s.build(.1,.1,0);tq=c.target_generator(.1)
out=[];checks=0
for sample in range(256):
 state=0;time=0.;events=[];fusion=None
 while True:
  choices=[z for z in edges if z[0]==state]
  if not choices:break
  total=sum(z[2] for z in choices);time+=rng.exponential(1/total)
  if time>180:break
  edge=choices[rng.choice(len(choices),p=[z[2]/total for z in choices])]
  _,dest,rate,kind=edge
  events.append(dict(time_s=time,kind='source',state=dest,event_kind=kind))
  if kind==2:fusion=time
  state=dest
 abs_time=None;alignment=False;attempt=None;target_state=None
 if fusion is not None:
  alignment=rng.random()<1/6
  if alignment:
   attempt=rng.exponential(10.)
   arrival=fusion+10
   if arrival<=180:events.append(dict(time_s=arrival,kind='arrival'))
   if attempt<10 and arrival+attempt<=180:
    abs_time=arrival+attempt;events.append(dict(time_s=abs_time,kind='absorption',state=0))
    ts=0;tt=abs_time
    while True:
     choices=[(j,tq[ts,j]) for j in range(5) if j!=ts and tq[ts,j]>0]
     if not choices:break
     total=sum(z[1] for z in choices);tt+=rng.exponential(1/total)
     if tt>180:break
     ts=choices[rng.choice(len(choices),p=[z[1]/total for z in choices])][0]
     events.append(dict(time_s=tt,kind='target',state=ts))
   elif arrival+10<=180:events.append(dict(time_s=arrival+10,kind='escape'))
 cur=0;ts=None;consumed=0
 for event in sorted(events,key=lambda z:z['time_s']):
  if event['kind']=='source':cur=event['state']
  if event['kind']=='absorption':
   assert consumed==0 and fusion is not None and event['time_s']>=fusion+10
   consumed=1;ts=0
  if event['kind']=='target':ts=event['state']
  ledger=c.s.L[cur,:5]+(c.T0 if ts is None else c.TL[ts])
  ledger=ledger.copy();ledger[2]-=consumed*c.s.gf
  assert abs(ledger.sum()-6*c.s.n)<4e-12
  ss=c.s.ST[cur];source_Z=2 if isinstance(ss,str) else sum(2 if x=='B' else 1 for x in ss)
  source_e=2+(0 if isinstance(ss,str) else ss.count('B'))
  target_Z=2 if ts==2 else 1;target_e=1+(ts==2)
  assert source_Z+target_Z-source_e-target_e==0
  event['ledger_MeV']=ledger.tolist();event['consumed_fusion_records']=consumed
  event['source_pairs']=source;event['target_pair']=target_origin
  event['baryon_number']=6;event['electric_charge']=0
  event['electron_count']=source_e+target_e;event['antineutrino_count']=source_e+target_e
  checks+=1
 out.append(dict(sample=sample,source_pairs=source,target_pair=target_origin,fusion_time_s=fusion,
   aligned=alignment,attempt_wait_s=attempt,absorption_time_s=abs_time,
   consumed_fusion_records=consumed,events=sorted(events,key=lambda z:z['time_s'])))
(P/'origin_event_witnesses.json').write_text(json.dumps(out,indent=2)+'\n')
summary=dict(histories=len(out),event_checks=checks,absorptions=sum(z['consumed_fusion_records'] for z in out),seed=8042026)
(P/'origin_verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
