from pathlib import Path
import json
P=Path(__file__).resolve().parent
r=json.loads((P/'results.json').read_text());v=json.loads((P/'verification.json').read_text());o=json.loads((P/'origin_verification.json').read_text())
def row(tau):return next(z for z in r['cases'] if z['cooling_s_inv']==.1 and z['flight_time_s']==tau and z['absorption_hazard_s_inv']==.1 and z['contact_window_s']==10 and z['aligned_fraction']==1/6 and z['time_s']==180)
a=row(10);b=row(100)
header='WRRA 부품 렌더링 후속 연구 0.8\n유한 광자 이동·교차 분해·재포획의 공동 장부\n최원식 / Wonsik Choi — 단독 저자\nORCID: 0009-0001-4263-9772 | janefather@gmail.com\n2026년 10월 4일\n소수 부품 1.0: https://doi.org/10.5281/zenodo.23128482\n'
ko=header+f'''
검증 입력 → WRRA 고유 변환 → 산출값 → 반증조건
검증 입력: 부품 0.6/0.7의 질량·수명·정지 광자선·반동·원래 소수 부품 출처를 유지한다. 광속 c=299,792,458 m/s는 고정 보정 입력이다. 새 질량·수명·관측 핵 풍부도를 재적합하지 않는다.
WRRA 고유 변환: 출처가 분리된 원천 네 핵자와 표적 두 핵자 → 유한 준비 전이 → 융합 광자의 유한 거리 이동 → 유한 상호작용 창에서 광자 소비 → 중수소 분해·핵자 냉각·베타/재포획 경쟁 → 같은 여섯 바리온 장부다.
산출값: 576개 조건에서 광자와 표적 인구를 계산했다. 기준 180초 흡수 확률 {100*a['photon_absorbed']:.6f}%, 재포획을 포함한 중수소 잔존 {100*a['target_surviving_deuteron_probability']:.6f}%. 모든 조건에서 에너지 및 광자 장부를 검사했다.
반증조건: 출처 중복 사용·광자 중복 흡수·빛 도착 전 흡수·음의 확률·에너지/전하/바리온/렙톤 실패, 또는 고정한 준비·접촉율의 측정 정합성 실패다.
판정: 0.7에서 운동학 허용성만 확인한 융합 광자→중수소 분해를 실제 시간별 인구와 방출 장부에 연결했다. 이는 선언된 유한 전달·접촉 규칙 아래의 WRRA 조건부 계산이다. 접촉율·흡수율·냉각력이 부품 정수 분해만으로 미시적으로 유도됐다는 판정은 하지 않는다.

1. 계승 원천과 고정 준비
source07.py는 0.7의 27상태 원천 전이를 계승한다. 이번에는 뜨거운 상태의 형식적 반환율을 0으로 고정해, 이미 이동시킨 같은 광자를 원천이 다시 소비하지 않게 했다. 냉각·전달 완료율은 0.01 또는 0.1 초^-1이고 포획·융합율은 100/878.3 초^-1이다.
표적은 다른 부품 출처의 냉각된 중수소 한 개다. 원천/표적의 원래 슬롯은 중복되지 않는다. 원천 quartet 0의 (0,129234),(1,129235), 표적의 (129232,258466)을 쓴다. 원천 n/p 소수표지는 5/2, 표적은 47/2다. 슬롯은 공간 좌표가 아니다.
표적을 먼저 만든 포획 광자와 냉각 증가분을 초기 장부에 포함한다. 표적 초기 d+전자 정지에너지+기존 Q_beta+포획 광자+포획 반동 저장=2mn이다. 원천 4mn과 합쳐6mn이며, 초기 중수소를 에너지 비용 없이 새로 만든 것으로 넣지 않는다.
분모는 ‘이미 두 np쌍을 가진 원천 quartet 하나+미리 준비된 표적 d 하나’다. 주소 평균·공동풀·우주 헬륨 구성비로 바꾸지 않는다. 원천 alpha는 이 단방향 접속에서 다시 분해하지 않는다.
검증 질량의 보정과 같은 수치 재현은 정당한 현실 정합 및 설명 성과다. 독창성은 부품 출처·유한 준비·광자 소비·표적 인구·동일 장부 연결에 있다. 기존 이론의 동일 숫자가 이 계산의 조건부 예측 귀속을 없애지 않는다. 외부 QCD·핵력·미분 단면적을 실행하지 않았다.

2. 유한 공간 이동과 접촉 선택
진공 이동시간 tau=L/c를 계산한다. tau=0,1,10,100초, 즉 L=0,299792458,2997924580,29979245800m다. tau=0은 독립된 출처가 접속되는 같은 위치 경계 시험이다.
표적 방향으로 접속되는 비중 eta=0,1/6,1을 명시한다. 1/6은 0.6의 여섯 등가 축 중 표적축 한 개를 선택하는 준비다. 1은 모든 광자를 그 방향에 배정하는 별도 준비이며 등방 방사에서 자동으로 나온 비율이 아니다. 실제 표적 면적에 따른 입체각·역제곱 희석을 도출한 값이 아니다.
도착 후 상호작용 창 w=1 또는10초를 사용한다. 이 창 안에서 흡수 hazard kappa=0,0.01,0.1,1 초^-1를 선언하고, 창 끝까지 흡수되지 않으면 탈출시킨다. 창은 유한 펄스/접촉 응답 규칙이며 광자가 정지하거나 c가 변한다는 뜻이 아니다. 창 내부의 광선 궤적·표적 단면적은 별도로 도출하지 않았다.
시간은30,180,600초다. 2×4×4×2×3×3=576개 조건이다. 모든 사건에 유한 관측시간과 유한 접촉창을 쓰며 무한한 실제 공간·시간을 전제하지 않는다.

3. 유한 시간 적분과 광자 네 장부
원천 융합 유량 J(u)=k_f P_TT(u)다. u에서 생성된 정렬 광자는 u+tau에 도착한다. 창 안의 흡수 대기시간 v에 대해 밀도 kappa exp(-kappa v)를 쓰고 0≤v≤min(w,t-u-tau)만 적분한다.
P_abs(t)=eta ∫_0^max(0,t-tau) J(u)[1-exp(-kappa min(w,t-u-tau))]du.
각 흡수시점 u+tau+v 이후 표적 진화를 계산해 다섯 상태의 인구를 적분한다. 창 모서리 t-tau-w에서 구간을 나눠 양의64절점 Gauss–Legendre 적분을 사용했다.
원천에서 생성한 융합 광자 기대수=이동 중+접촉 중+탈출+흡수다. 비정렬 광자도 탈출 항에 남는다. 이동/접촉/탈출 광자는 에너지를 유지하며 흡수된 광자만 방사 장부에서 한 번 제거한다.
표적이 재포획될 때 생기는 광자는 새 기록이다. 원래 융합 광자가 돌아온 것으로 세지 않는다. 새 포획선은 냉각 표적 분해 문턱 아래이므로 같은 선택에서 다음 분해를 일으키지 않는다. 원천 융합은 최대 한 번, 표적 흡수도 최대 한 번인 유한 모듈이다.

4. 분해·냉각·재포획의 실제 인구 연결
냉각된 d와 융합 광자 23.770682374953 MeV를 입력으로 d+gamma→n+p를 계산한다. 정지 표적 분해 문턱2.225885590884 MeV를 넘으며, 최종 핵자 운동에너지 합은 {r['target_hot_kinetic_MeV']:.12f} MeV다.
0.7의 세 각도 운동학 증인을 계승해 두 질량 shell·에너지·운동량을 재검사했다. 각도는 운동학 증인이며 측정 미분 확률의 유도는 아니다.
표적 상태는 X=뜨거운 np, A=냉각 np, B=베타 endpoint, H=재포획된 뜨거운 d, D=재포획된 냉각 d다. X→A에 냉각 완료율, A→B에1/878.3 초^-1, A→H에100/878.3 초^-1, H→D에 냉각 완료율을 둔다.
흡수 전에는 표적이 초기 d로 남는다. X를 즉시 냉각해 처음부터 포획시키지 않는다. 초기 준비와 재포획을 구별하고, 결합된 d에 자유중성자 수명을 넣지 않는다.
흡수 핵자의 총 운동량은 들어온 광자 운동량과 같다. X→A에서 운동에너지 K와 그 총운동량을 환경으로 옮긴다. 환경 초기 정지에너지10^9 MeV를 별도 배경으로 두면 최종4-운동량이 timelike이고 환경 정지에너지 증가를 허용함을 확인했다. 실제 냉각력·접촉 과정의 연속시간 운동량 변화는 풀지 않았다.

5. 같은 여섯 바리온 장부
활성 정지+기존/새 베타 비정지+남은 모든 광자+활성 핵 반동+환경 증가분=6mn.
흡수에서 기존 d 질량은 n+p로 바뀌고, 광자23.770682374953 MeV가 제거되며, 남는 운동에너지 K가 뜨거운 핵자에 들어간다. K는 냉각 때 저장고로 이동한다. 재포획에서 핵 질량 감소는 새 포획선과 새 반동에 들어간다.
초기 표적 포획선·저장고를 다시 새 방출로 세지 않는다. 흡수 광자와 핵자 운동에너지를 동시에 남겨 이중 계상하지 않는다. 모든 사건에서 B=6,Q=0,L=0이며 전자/반중성미자 기록은 보존된다.
0.7 원천 전달 작업의0.001 MeV/완료 비용은 외부0.002 MeV 예산에서 차감해 별도로 유지한다. 이 값을 WRRA 원천6mn에 추가하지 않는다. 광자 이동의 에너지 변화는 이 정지 진공 시험에서0으로 선택했다. 적색편이·중력·산란 손실을 도출한 것은 아니다.

6. 기준 산출값 —180초
냉각/원천 전달0.1 초^-1, kappa0.1 초^-1, 창10초, 정렬 비중1/6:
비행10초: 원천 융합 확률 {100*a['source_fusion_probability']:.6f}%, 광자 흡수 {100*a['photon_absorbed']:.6f}%, 표적 중수소 잔존 {100*a['target_surviving_deuteron_probability']:.6f}%.
표적 베타 endpoint {100*a['target_beta_endpoint_probability']:.6f}%, 새 재포획 광자 {a['additional_capture_photons']:.9f}개/모듈. 총 남은 광자 에너지 {a['photon_MeV']:.9f} MeV/모듈이다.
비행100초: 흡수 {100*b['photon_absorbed']:.6f}%, 중수소 잔존 {100*b['target_surviving_deuteron_probability']:.6f}%, 새 재포획 광자 {b['additional_capture_photons']:.9f}개다.
늦게 도착한 경우180초까지 냉각·재포획할 시간이 줄어 중수소 잔존량이 낮아진다. 광자 흡수 확률이 곧 최종 중수소 소실률은 아니다. 이것은 선언한 준비를 고정한 뒤의 조건부 WRRA 산출이며 우주 중수소 풍부도의 측정 일치를 확정하지 않는다.

7. 검사·출처 이력·재현
수치/장부 검사 {v['passed']}/{v['total']}개 통과. 별도 적응형1차원 흡수 적분과 최대 차이 {v['maximum_adaptive_absorption_error']:.3e}; 선택 조건64/128절점 표적 인구 차이 {v['maximum_64_128_population_difference']:.3e}다.
원천 DOP853 진화를 행렬 지수와 대조했고, 표적 DOP853를 별도 해석적 연쇄해와 대조했다. 같은 선언 규칙의 수학/구현 검사이며 독립 물리 실험의 수가 아니다.
{ o['histories']}개 유한 이력의 {o['event_checks']}개 사건을 별도로 실행했다. 실제 흡수 {o['absorptions']}개를 포함하며, 모든 사건의 원래 출처·광자 소비 횟수·6mn·전하·전자/반중성미자 기록을 검사했다. 몬테카를로 표본을 정밀 확률표의 근거로 쓰지 않는다.
실행: OPENBLAS_NUM_THREADS=1 python compute.py
검사: OPENBLAS_NUM_THREADS=1 python verify.py
출처 이력: OPENBLAS_NUM_THREADS=1 python origin_witnesses.py
원고: python generate_report.py
Python·numpy·scipy 필요. 코드·입력 스냅샷·576조건 CSV·상세결과·감사·출처이력·한영원고·해시를 보존한다. 새 DOI 또는 GitHub/Zenodo 등록 완료는 배정하지 않는다.

8. 0.8 완료 범위와 다음 경계
완료: 유한 진공 이동시간, 유한 접촉창, 조건부 광자 흡수, 교차 분해, 핵자 냉각, 베타/재포획 경쟁, 추가 방사와 출처/에너지 장부의 실제 연결.
남은 경계: 부품 구조로부터 접촉·흡수율/냉각력을 유도하는 것, 표적 입체각·면적·실제 공간 위치 분포, 다중 원천/표적의 반복 광자 피드백, 미시 핵 스핀 진폭, 열평형, 중력/팽창 접속이다. 기존 상류·하류 통합모형과 임의로 혼합하지 않는다.
'''
en=f'''WRRA Parts Rendering Followup 0.8
Finite photon flight, cross-breakup and recapture in one ledger
Wonsik Choi / 최원식 — sole author
ORCID: 0009-0001-4263-9772 | janefather@gmail.com
2026-10-04
Prime Parts 1.0: https://doi.org/10.5281/zenodo.23128482

Verified inputs → WRRA transformation → outputs → falsification
Inputs: retain the 0.6/0.7 masses, lifetime, line/recoil and prime-part origins. Fixed c=299792458 m/s is a calibration input, not a prediction. No abundance or mass refit.
Transformation: disjoint source quartet and target pair → finite preparation → fusion-photon flight → finite interaction window → breakup, cooling and beta/recapture competition → the same six-baryon ledger.
Outputs: 576 conditions. Reference absorption at 180 s {100*a['photon_absorbed']:.6f}%; final surviving deuteron {100*a['target_surviving_deuteron_probability']:.6f}% after recapture.
Falsification: duplicate source/record consumption, pre-arrival absorption, negative populations, energy/Q/B/L failures, or observation mismatch under identical frozen preparation/hazards.
Verdict: the previously kinematically open cross-channel is now coupled to time-dependent populations and radiation accounting under declared finite transport/encounter rules. Absorption hazards, cooling forces and microscopic amplitudes are not derived from integer factorization.

1. Preparation and origin
The inherited 27-state source generator uses zero formal hot-return rate, ensuring that a transported fusion photon is not reused by the source. Source cooling/transfer is 0.01 or 0.1 s^-1; capture/fusion hazards are 100/878.3 s^-1.
A disjoint cold deuteron target is initially prepared. Source quartet-0 slots (0,129234),(1,129235) carry prime tags5/2; target slots (129232,258466) carry47/2. All six slots are distinct; they are origin labels, not spatial coordinates.
The target's earlier capture photon and bath recoil, spectator electron/antineutrino and initial Q_beta are explicitly retained: target initial energy is2mn. Combined with4mn source energy, the module starts at6mn. A prepared target is not free added matter.
The denominator is one eligible source quartet plus one prepared target deuteron, not a weighted address or cosmic abundance. Source alpha is not broken by this one-way coupling.
Verified calibration, reproduction and the own-origin transport/record/population linkage remain legitimate explanatory results. No external QCD, nuclear Hamiltonian or measured differential cross section is executed.

2. Flight and finite contact
Flight delay tau=L/c uses tau=0,1,10,100s. Distances are0,299792458,2997924580,29979245800m. Zero delay is a colocated distinct-origin boundary case.
Aligned fraction eta=0,1/6,1 is an explicit preparation. One-sixth selects one of six inherited equivalent axes; unity is a separate directed preparation, not automatic isotropic acceptance. Target solid angle and inverse-square dilution are not derived.
Upon arrival, a finite interaction window w=1 or10s uses hazard kappa=0,0.01,0.1,1s^-1. Unabsorbed records escape at the window end. This is an imposed pulse/contact response, not a stopped photon or variable light speed. In-cell ray trajectories and microscopic target area are not solved.
Observation times30,180,600s yield576 conditions. All integrals and actual histories have finite time/windows; no realized infinite domain is required.

3. Photon partition and target propagation
Source fusion flux J(u)=kf P_TT(u). A directed record emitted at u arrives at u+tau. Within0≤v≤min(w,t-u-tau), the absorption density is kappa exp(-kappa v).
P_abs(t)=eta integral[0,max(0,t-tau)] J(u)(1-exp(-kappa min(w,t-u-tau)))du.
Target populations propagate from each absorption time u+tau+v. Positive64-node Gauss–Legendre rules split at the finite-window kink.
Emitted fusion records=in flight+in contact+escaped+absorbed. Unaligned records are escaped. Only absorbed photons are removed from energy accounting. Recapture creates a new capture record; it does not return the consumed fusion photon.
The module permits at most one source fusion and one target absorption. The recapture line is below the cold-deuteron breakup threshold. Repeated multi-source feedback is not included.

4. Actual cross-breakup and target states
A cold d absorbs the23.770682374953MeV fusion photon, exceeding its2.225885590884MeV threshold. Product kinetic energy is {r['target_hot_kinetic_MeV']:.12f}MeV.
The three inherited angular witnesses satisfy both mass shells and energy/momentum. They are kinematic witnesses, not a measured differential distribution.
Target states after absorption: X=hot np; A=cold np; B=beta endpoint; H=recaptured hot d; D=recaptured cold d. X→A and H→D use the declared cooling hazard; A→B uses1/878.3s^-1; A→H uses100/878.3s^-1.
Before absorption the target remains its initially prepared d. A bound deuteron does not receive a free-neutron decay lifetime. Finite cooling precedes recapture.
At cooling completion, the breakup kinetic energy and total incoming photon momentum transfer to the bath. A separate initial bath rest energy10^9MeV makes the completion witness timelike with increasing bath invariant mass. Continuous forces and bath trajectories are not derived.

5. Shared energy and work
Active rest+initial/new beta nonrest+all retained photons+active nuclear recoil+bath gain=6mn. Absorption removes exactly one fusion photon, increases d rest mass to n+p, and places the excess in hot nuclear motion. Cooling transfers that excess; recapture produces a new line/recoil pair.
Initial target capture radiation/bath gain are never reclassified as new release. B=6,Q=L=0 and electron/antineutrino records remain conserved.
The inherited source transfer-work cost0.001MeV per completion is separately debited from the external0.002MeV budget. It is not added to6mn. Vacuum propagation has zero photon-energy change in this selected static test; redshift, gravity and scattering losses are not derived.

6. Reference outputs per module at180s
Source cooling/transfer0.1s^-1, kappa0.1s^-1, window10s, aligned fraction1/6:
Flight10s: source fusion {100*a['source_fusion_probability']:.6f}%; absorption {100*a['photon_absorbed']:.6f}%; surviving deuteron {100*a['target_surviving_deuteron_probability']:.6f}%.
Target beta endpoint {100*a['target_beta_endpoint_probability']:.6f}%; new recapture photons {a['additional_capture_photons']:.9f}; total retained photon energy {a['photon_MeV']:.9f}MeV/module.
Flight100s: absorption {100*b['photon_absorbed']:.6f}%; surviving deuteron {100*b['target_surviving_deuteron_probability']:.6f}%; new recapture photons {b['additional_capture_photons']:.9f}.
Late arrival leaves less time for cooling/recapture. Absorption probability is not final deuteron-loss probability. These are WRRA conditional outputs after freezing the declared preparation, not a fit to cosmic deuterium abundance.

7. Verification and release
{v['passed']}/{v['total']} implementation/mathematical checks passed. Independent adaptive scalar absorption integrals differ by at most {v['maximum_adaptive_absorption_error']:.3e}; selected64/128-node population comparisons differ by {v['maximum_64_128_population_difference']:.3e}.
Source ODE evolution is compared with matrix exponentials; target ODE with an independently written analytic chain solution. These check the same effective rules, not independent physical experiments.
{o['histories']} finite histories, {o['event_checks']} event checks and {o['absorptions']} actual absorptions retain disjoint origins, unique photon consumption,6mn, charge and electron/antineutrino counts. Monte Carlo samples are not used as the precise probability table.
Run with OPENBLAS_NUM_THREADS=1: python compute.py; python verify.py; python origin_witnesses.py. Then python generate_report.py. Dependencies: Python,numpy,scipy. The package retains inherited snapshots, code,576-case CSV, detailed outputs,audits,histories,bilingual text and hashes. No new DOI or completed GitHub/Zenodo publication is assigned.

8. Closed scope and remaining boundaries
Closed for this declared module: finite vacuum flight, finite interaction window, conditional absorption, cross-breakup, cooling, beta/recapture competition, extra radiation and shared origin/energy accounting.
Remaining: deriving encounter/absorption/cooling laws from part structure; target area/solid angle and spatial distributions; repeated multi-source/multi-target radiation feedback; microscopic spin amplitudes; thermal equilibrium; gravity/expansion. The separate upstream/downstream synthesis is not mixed into this parts study.
'''
(P/'WRRA_Parts_Followup_0_8_KO.txt').write_text(ko)
(P/'WRRA_Parts_Followup_0_8_EN.txt').write_text(en)
(P/'inputs.json').write_text(json.dumps(dict(stage='0.8',speed_m_s=299792458,source_cooling_transfer_s_inv=[.01,.1],source_hot_return_s_inv=0,flight_times_s=[0,1,10,100],contact_windows_s=[1,10],absorption_hazards_s_inv=[0,.01,.1,1],alignment_fractions=[0,1/6,1],observation_times_s=[30,180,600],quadrature_nodes=64,scope='one eligible quartet and one disjoint initially prepared cold deuteron; one-way photon coupling',microphysics_status='hazards and preparation are declared choices; no microscopic amplitude or measured cross section inferred'),indent=2)+'\n')
(P/'requirements.txt').write_text('numpy\nscipy\n')
