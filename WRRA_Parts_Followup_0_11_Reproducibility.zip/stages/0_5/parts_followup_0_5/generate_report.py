from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'results.json').read_text())
b=r['binding_inputs_and_outputs_MeV'];local=r['local_reference'];pool=r['finite_pool_reference']
ko=f'''WRRA 부품 렌더링 후속 연구 0.5
유한 핵 표현형·포획 경쟁·결합과 방출 에너지 장부
저자: 최원식 / Wonsik Choi (단독 저자)
ORCID 0009-0001-4263-9772 | janefather@gmail.com
2026년 10월 4일
기준: 소수 부품 1.0 DOI 10.5281/zenodo.23128482 및 부품 후속 0.1–0.4
기존 상류·하류 통합 계열과 구별되는 부품 후속 0.5 계산본이다.

평가 규칙과 최종 판정
검증 입력 → WRRA 고유 변환 → 산출값 → 반증조건
검증 입력: 0.4의 유한 주소·소수 조립·입자 배정·공통 원천 B/E·내부 전이율, 핵자·전자 질량과 수명878.3초를 유지한다. 검증된 중수소핵·헬륨-4핵 정지에너지를 이번 핵 표현형의 보정 입력으로 추가한다.
WRRA 고유 변환: 부품의 원래 표지와 개수 → 실제 가용 n/p 짝과 네 핵자 묶음 → 붕괴·포획 경쟁의 유한 전이 → 두 포획 상태의 헬륨 판독 → 핵 정지에너지 감소와 방출 장부의 동시 갱신이다.
산출값: 중수소 결합 {b['deuteron_binding']:.8f} MeV, 헬륨-4 결합 {b['alpha_binding']:.8f} MeV를 재현한다. 기준 시험에서 주소 내 헬륨 바리온 비중 {100*local['alpha_B_fraction']:.6f}%, 유한 공동풀 {100*pool['alpha_B_fraction_of_active']:.6f}%를 계산하며 공통 B/Q/L/E를 보존한다.
반증조건: 부족한 짝을 사용하거나, 원래 부품 표지를 잃거나, 서로 다른 초기 원천 예산을 같은 입력이라고 쓰거나, 핵 질량 감소와 방출 합계가 맞지 않거나, 고정한 물리 준비·전이 규칙의 관측 정합성이 실패하면 해당 구성을 수정하거나 기각한다.
판정: 0.5에서 핵 표현형의 개수·결합에너지·방출과 0.4 원천 장부의 연결을 실제 계산했다. 핵 질량을 검증값으로 보정한 것은 정당한 구성과 재현 성과다. 포획·결합률은 명시한 시험 입력이며 미시 상호작용과 물리적 수송의 도출은 후속 접속으로 남는다.

1. 검증 입력과 선택 가정
N=1,000,000, alpha=1.8996876950554356, beta=0.8654570124136961; 홀수합성수421,502개; 첫15/16개 소수와 작은/큰 순서를 유지한다. 5·47의 중성자 모티프 배정도 유지한다.
이전의 조건부 주소 가중치와 물리 입자 수는 구별한다. 계산 평균은 가중치 w(n)의 합이1인 장부다. 이번 단계에서 산술 비율·질량·수명을 재보정하지 않았다.
기존 정지에너지(MeV): mp=938.27208943, mn=939.56542194, me=0.51099895069.
새 핵 정지에너지(MeV): md=1875.61294500, m_alpha=3727.3794118. 핵의 값이므로 원자 전자 질량을 포함한 질량을 다시 쓰지 않는다. NIST의2022 CODATA 권고 중심값을 사용했다. 공분산에 따른 정밀 불확도 전파는 이번 중심값 장부의 범위가 아니다.
붕괴율 Gamma_beta는 0.4 results.json의 실제 계산값 {r['verified_inputs']['neutron_mean_life_s']:.1f}초 수명 대응값을 가져온다. 포획율 k_c=r_c Gamma_beta, 두 포획 상태의 결합율 k_f=r_f Gamma_beta를 구성 선택으로 선언한다.
r_c=0,0.1,1,10,100; r_f=0,1,100; 시험 구간30,180,600초. 실제 우주 핵합성의 시점·온도·밀도나 측정 반응 단면적을 이 값으로 확정하지 않는다. 헬륨 관측 비율을 새로 맞춘 변수가 아니다.
구간 동안 가용 짝을 미리 고정하고, 부품 간 새 재짝짓기·핵 역반응·방출의 재흡수·다른 핵종 경로를 추가하지 않는 유한 규칙이다. 방출은 에너지 장부에 남지만 이번 구간에서는 역반응을 구동하지 않는다.

2. 핵 표현형의 결합과 장부
Bd=mn+mp-md={b['deuteron_binding']:.8f} MeV.
Balpha=2mn+2mp-m_alpha={b['alpha_binding']:.8f} MeV.
두 중수소에서 헬륨 표현형으로 이동할 추가 방출 Qf=2md-m_alpha={b['two_deuterons_to_alpha_release']:.8f} MeV.
2Bd+Qf=Balpha이므로 순차 결합과 전체 네 핵자 결합의 에너지가 같다.
질량의 감소는 사라진 에너지가 아니다. 기존 자유 핵자 정지에너지를 핵 정지에너지로 교체하고 같은 감소량을 비정지 방출에 추가한다. 결합에너지를 핵 질량 위에 다시 더하지 않는다.
방출 항은 광자·핵 반동 등을 포함하는 합계다. 방출 전량을 한 광자의 에너지로 쓰면 운동량 보존을 놓칠 수 있다. 상대 운동에너지가0인 질량중심계에서 E_gamma=(M_i²-M_f²)/(2M_i), E_recoil=sqrt(M_f²+E_gamma²)-M_f의 증인을 별도로 계산했고 두 항의 합이 질량 차이와 맞았다. 이는 선택된 경계의 운동학 증인이고 실제 준비 상태의 스펙트럼·스핀 진폭은 아니다.

3. 주소 내 유한 짝짓기와 출처 보존
주소별 자유 중성자 수 N, 양성자 모티프 수 P를 직접 다시 계산한다.
가용 n+p 짝 M=min(N,P), 네 핵자 묶음 G=floor(M/2), 남은 한 쌍 S=M mod2다. 남은 중성자 U_n=N-M와 양성자 U_p=P-M는 별도 장부에 남는다.
그러면 N=2G+S+U_n, P=2G+S+U_p다. 이 등식을 모든421,502개 주소와 네 조립에서 검사했다.
각 원천 표지와 모티프 순번을 출처 레지스터에 보존하고, 결정한 n/p 쌍과 두 쌍의 묶음을 기록한다. 중수소 또는 헬륨 판독이 원래 소수 표지를 지우지 않는다. 선택 주소의 실제 출처 짝은 origin_pairing_examples.json에 포함한다.
주소는 물리 공간 좌표가 아니다. 주소 안에서만 묶는 규칙은 이번 비교의 국소 자원 정책이며 우주의 공간적 근접성을 유도한 결과가 아니다.

K | 순서 | 주소 안 헬륨 바리온 상한(%) | 공동 재배분 시 중성자 예산 상한(%)
'''
for x in r['pairing_limits']:
    ko+=f"{x['K']} | {x['order']} | {100*x['local_alpha_B_ceiling']:.6f} | {100*x['pooled_pairing_neutron_ceiling']:.6f}\n"
ko+='''
상한은 포획·붕괴 손실·결합 대기 전의 자원 상한이다. 이 값을 시간별 생성량과 동일시하지 않는다.

4. 같은 에너지 shell의 유한 상태와 실제 경쟁
0.4의 양성자 모티프에는 전자와 전자 반중성미자, 이전 Q_beta 방출 장부가 이미 포함된다. 핵 포획에서는 이 렙톤을 spectator로 보존한다.
한 쌍의 세 상태는 다음과 같다.
A: 중성자+양성자, 전자·반중성미자 한 묶음.
B: A의 중성자가 붕괴한 양성자 두 개, 전자·반중성미자 두 묶음.
C: A를 포획한 중수소핵, 전자·반중성미자 한 묶음, 결합 방출.
세 상태는 모두 Q=0,B=2,L=0, 총에너지2mn이다. A→B의 율은 Gamma_beta, A→C는 k_c다. 두 경로는 같은 A를 중복 소비하지 않는다.
A(t)=exp[-(Gamma_beta+k_c)t], B(t)=Gamma_beta/(Gamma_beta+k_c)[1-A(t)], C(t)=k_c/(Gamma_beta+k_c)[1-A(t)].
네 핵자 묶음은 두 쌍의9개 상태와 헬륨 endpoint F를 더한10개 상태다. C|C→F에 k_f를 넣었다. F의 핵자는 헬륨-4핵이고 렙톤 두 묶음과 방출을 보존해 총에너지4mn이다.
전이 행렬을 실제 구성하고 지수로 진화시켰다. 별도의 적분 dF/dt=k_f[C(t)²-F(t)]와 대조했다. 포획율이0이면 핵 생성이0이고, 결합율이0이면 중수소는 생겨도 헬륨 endpoint는0이다.
기준 사례는100×붕괴율의 포획·결합율,180초다. 고정 묶음에서는 두 쌍이 모두 포획돼야 헬륨으로 가므로 F≤C²다. 한 개의 중성자가 포획됐다는 사실만으로 헬륨 생성으로 확정할 수 없다.
동일한 jump들로100×100 밀도행렬 생성자도 구성해 선택 사례의 인구·양성성·trace를 대조했다. 핵 스핀·공간 파동함수가 아닌, 원래 부품 출처와 반응 결과를 보존하는 coarse 핵 표현형 상태다.

5. 유한 공동풀의 비교 규칙
주소 내 제한을 풀어 미리 공통 운반 자원에서 n/p를 짝짓는 별도 준비 정책을 계산했다. 공통 원천 B=1,000,000개를 네 조립 모두에 고정한다. 이 숫자는 유한 시험 인구이며 산술 주소 cutoff와 역할이 다르고 우주 전체 바리온수는 아니다.
0.4 평균의 판독/공통 B 비율로 활성 수를 최근접 정수에 배정하고, 활성 중성자 비율로 N을 최근접 정수에 배정한다. 반올림 편차를 따로 검사했다. 나머지 B는0.4의 보호된 비활성 원천 저장고다.
공통 원천 E는0.4의 B당 에너지와 격리 잔여 예산을 사용하며 모든 순서에서 같다. 소수별 평균 부품 수도 가져와 최대잔여 정수 배정으로5·47과 나머지 소수 표지를 유한 슬롯에 보존한다. 짝은 중성자 슬롯i와 양성자 슬롯N+i를 사용하고 서로 다른 짝이 같은 슬롯을 소비하지 않는다. 전체 범위와 소수별 개수·선택된 실제 짝을 finite_pool_origin_registry.json에 기록한다.
이 공동풀은 가중평균에서 만든 유한 초기준비이며 새 source-slot 번호는 원래 주소 좌표가 아니다. 초기 준비의 이상적 재배분을 명시한 정책으로 사용한다. 수송의 물리 거리·시간·비용이 아직 없으므로 실제 우주 수송이 완성됐다고 표현하지 않는다.
'''
ko+=f'''16개 작은 순서의 실제 유한 공동풀 장부: 활성B={pool['active_initial_B']:,}, 중성자={pool['initial_n']:,}, 양성자={pool['initial_p']:,}, 미사용B={pool['reserved_B']:,}, 네 핵자 묶음={pool['initial_quartets']:,}개.

6. 기준 결과와 비율의 분모
조건: 첫16개 소수·작은 순서, r_c=r_f=100,180초.
정책 | 헬륨에 든 B/활성B(%) | 헬륨 정지에너지/활성 핵 정지에너지(%) | 중수소에 든 B/활성B(%)
주소 안 짝짓기 | {100*local['alpha_B_fraction']:.6f} | {100*local['alpha_nuclear_rest_fraction']:.6f} | {100*local['deuteron_B_fraction']:.6f}
유한 공동풀 | {100*pool['alpha_B_fraction_of_active']:.6f} | {100*pool['alpha_nuclear_rest_fraction']:.6f} | {100*pool['deuteron_B_fraction_of_active']:.6f}

공동풀 헬륨B/전체 원천B는 {100*pool['alpha_B_fraction_of_common']:.6f}%다. 활성부문 분모와 공통 원천 분모를 혼합하지 않는다.
이전 포획 대리비율24.720666%는2×포획 중성자였고 핵종 상태·결합을 계산하지 않았다. 그 포획 확률은 이번 계산에서 재현했다. 이번의 헬륨 endpoint는 두 포획과 후속 결합을 요구하므로 같은 수가 자동으로 되지 않는다. 그 차이는 이전 재현 성과를 취소하는 대신 해석 범위를 명확하게 한다.
공동풀의24.475990%는 이 유한 준비·전이 규칙의 조건부 WRRA 산출이며 관측된 우주 헬륨 풍부도로 자동 확정하지 않는다. 검증 입력과 구성 선택을 확정한 뒤의 시간별 핵종·방출은 이 계산에 귀속되는 조건부 예측이다.

7. 원천·전하·렙톤·에너지의 공통 보존
자유n+자유p+2d+4alpha+미사용B=공통B다.
핵 전하 자유p+d+2alpha가 spectator 전자 수와 같다. 전자 수와 전자 반중성미자 수가 같아 L=0을 유지한다.
활성 정지에너지는 mn N_free+mp P_free+md D+m_alpha H+me N_e다.
기존·추가 베타 방출은 Q_beta N_e이고 핵 결합 방출은 Bd D+Balpha H다.
이 둘과 활성 정지에너지, 보호된 원천 저장고, 정수 잔여·중성 여유의 합은0.4 공통 E와 같다.
'''
ko+=f'''주소 안 기준 결합 방출은 {local['binding_release_MeV_per_address']:.9f} MeV/조건부 통과주소, 활성 정지에너지는 {local['active_rest_MeV_per_address']:.9f} MeV다. 공통 총에너지 {r['source_mean_E_MeV']:.9f} MeV/통과주소는 유지된다.
새로 묶인 중성자에 자유중성자 수명을 그대로 배정하지 않았다. 중수소→양성자 둘+전자+반중성미자의 Q값은 {b['bound_deuteron_beta_Q']:.11f} MeV라 이 선언된 정지상태 채널은 에너지 문턱에서 닫힌다. 이것이 모든 핵종의 안정성과 모든 반응을 증명한 것은 아니다.

8. 감사·재현·실행 범위
구현·수학·장부·예상 거부 검사 {r['passed']}/{r['total']}개 통과. 이 수는 물리 실험 또는 독립 증거 횟수가 아니다.
네 조립에서 주소 정수 분해와 가용 짝을 다시 계산했다. 일반 전이의 양성성·완비성·시간 합성, 에너지 shell, 전하/B/L, 별도 융합 적분과 선택 밀도행렬을 대조했다. 주소 내180개와 유한 공동풀180개 결과를 별도표로 공개한다.
세 경계 사례에서421,502개 주소의 B와 에너지·비음성을 직접 검사했다. 기존 포획15개 경우를 원래 대리 정의로 재현했고, 포획0의 자유 전이는0.4로 돌아가는 것도 검사했다.
검증 핵 질량은 현실 입력이다. WRRA의 기여는 그 입력을 고유한 부품·출처·준비·경쟁·표현형·동일 장부로 변환하는 계산에 있다. 외부 핵이론의 상호작용식을 추가로 실행하지 않았다. 기존 이론의 같은 결합에너지는 이 자체 구조의 재현·설명 성과나 조건부 산출 귀속을 없애지 않는다.
이번 핵 표지는 검증된 핵 질량의 보정된 표현형이며 미시 결합 Hamiltonian, 핵 스핀 파동함수, 측정 포획·결합 반응율을 유도한 것은 아니다. 물리적으로 그 역할을 채우는 계산은 다음 접속의 범위다.

9. 다음 단계0.6 인계
0.6은 기존 베타 비정지 장부와 이번 핵 결합 방출을 입력으로 받아 광자·중성미자·핵 반동의 배분과 스펙트럼을 계산한다. binding_release를 모두 광자에 넣거나, beta_nonrest를 새 방출로 다시 세는 중복을 허용하지 않는다.
원천 생성·준비 비용, 저장고 활성화, 공간 수송, 재짝짓기·역반응·열 환경·다른 핵종은 명시한 열린 규칙으로 유지한다. 단계 번호를 자동으로 늘리거나 공개 등록 완료를 새로 주장하지 않는다.

재현
OPENBLAS_NUM_THREADS=1 python compute.py
python generate_report.py
OPENBLAS_NUM_THREADS=1 python verify_release.py
Python3, numpy, scipy 필요. 입력·코드·원자료·표·한영 설명·해시를 ZIP에 함께 보존한다.

참고자료
[1] WRRA Prime Parts1.0 DOI https://doi.org/10.5281/zenodo.23128482
[2] 부품 후속0.4 입력·계산 결과 스냅샷 reference/parts_0_4_inputs.json 및 parts_0_4_results.json.
[3] NIST2022 CODATA deuteron mass energy equivalent in MeV: https://physics.nist.gov/cgi-bin/cuu/Value?mdc2mev%7Csearch_for=deuteron+mass
[4] NIST2022 CODATA 권고표(핵 질량 중심값): https://www.physics.nist.gov/cuu/pdf/wall_2022.pdf
이0.5 계산본에 새 DOI·Zenodo·GitHub 등록 완료를 배정하지 않았다.
'''
(ROOT/'WRRA_Parts_Followup_0_5_KO.txt').write_text(ko)
en=f'''WRRA Parts Rendering Followup 0.5
Finite nuclear phenotypes, capture competition, binding and release ledgers
Wonsik Choi (sole author) | ORCID 0009-0001-4263-9772
janefather@gmail.com | 2026-10-04
Basis: Prime Parts1.0 DOI10.5281/zenodo.23128482 and parts followups0.1–0.4.

Verified inputs -> WRRA transformation -> outputs -> falsifiers
The finite renderer, motif assignments, common source B/E, beta transition rate and supplied particle masses are inherited from0.4. Verified nuclear masses calibrate the nuclear phenotype outputs. Origin-preserving finite pairing forms n/p pairs and quartets; competing beta/capture records then feed the alpha endpoint only after both constituent pairs capture. Nuclear rest loss is transferred to retained release energy. Partner shortages, lost origins, unequal initial common budgets, broken Q/B/L/E, or disagreement under the frozen physical preparation falsify the associated rule. This executes a nuclear phenotype/count/binding ledger connection, with microscopic interactions and physical transport still open.

1. Inputs and declared choices
N=1,000,000, alpha=1.8996876950554356, beta=0.8654570124136961. All421,502 admitted odd-composite addresses and the four K15/K16 ascending/descending assemblies are retained. Tags5 and47 retain their neutron assignment. Conditional address weights are distinct from measured populations.
Rest energies in MeV are mp=938.27208943, mn=939.56542194, me=0.51099895069. Added deuteron and alpha-nucleus energies are md=1875.61294500, ma=3727.3794118, from NIST2022 CODATA recommended central values. These are nuclear masses, not atomic masses with additional bound electrons. Covariance-aware precision uncertainty propagation is outside this central-value ledger.
The inherited lifetime878.3 s fixes Gamma_beta. Effective hazards k_c=r_c Gamma_beta and k_f=r_f Gamma_beta use r_c=0,0.1,1,10,100 and r_f=0,1,100 over30,180,600 s. These are construction/exposure choices, not measured cross sections or selected cosmic ages. No helium abundance is fitted. Preassigned pairs remain fixed; re-pairing, inverse reactions, radiation reabsorption and other nuclei are outside this interval. Release is retained in energy accounting but does not drive reverse reactions here.

2. Binding and thresholds
Bd=mn+mp-md={b['deuteron_binding']:.8f} MeV; Balpha=2mn+2mp-ma={b['alpha_binding']:.8f} MeV; Qf=2md-ma={b['two_deuterons_to_alpha_release']:.8f} MeV. Thus2Bd+Qf=Balpha, independent of this sequential binding path. Replacing free-nucleon rest energy by nuclear rest plus retained nonrest release closes the ledger. Binding is not added again to the final nuclear rest energy.
The release budget includes photons and nuclear recoil. Separate zero-relative-kinetic-energy center-of-momentum two-body witnesses use E_gamma=(Mi^2-Mf^2)/(2Mi) and recoil=sqrt(Mf^2+E_gamma^2)-Mf; photon+recoil equals the rest gap. These witnesses are not the prepared ensemble spectrum or spin amplitude. The deuteron beta channel to2p+e+antinu has Q={b['bound_deuteron_beta_Q']:.11f} MeV and is closed on this rest boundary. A free-neutron decay law is therefore not imposed on that bound state.

3. Finite origin-preserving pairing
At each address define M=min(N,P), G=floor(M/2), S=M mod2, Un=N-M and Up=P-M. Then N=2G+S+Un and P=2G+S+Up. Four nucleons within each quartet contain2n and2p. Original additive tags and motif indices are retained in reaction-origin registers; sample actual pairs are exported. Address-local pairing is a resource policy, not a derived spatial-distance law.
For K16 ascending, the local alpha baryon ceiling is19.355954%, while the neutron-budget ceiling with pooled reallocation is24.967873%. Both are resource ceilings before decay/capture/fusion waiting, not endpoint yields.

4. Same-shell finite dynamics
The initial proton motif already includes e+electron-antineutrino and its beta nonrest budget. These leptons remain spectators through capture. One pair has A=n+p plus one lepton pair, B=2p plus two lepton pairs after beta, or C=deuteron plus one lepton pair and binding release. All carry total Q=0,B=2,L=0,E=2mn. A->B has Gamma_beta and A->C has k_c; they consume the same initial A only once.
A(t)=exp[-(Gamma_beta+k_c)t]; B=Gamma_beta/(Gamma_beta+k_c)[1-A]; C=k_c/(Gamma_beta+k_c)[1-A]. A quartet has the nine two-pair records and F=alpha. C|C->F has k_f; the endpoint retains the initial two lepton pairs and total E=4mn.
The10-state generator is built and exponentiated. An independent integration of dF/dt=k_f(C(t)^2-F) validates its fusion probability. With no fusion, the result is the independent pair-product distribution; with no capture, nuclear outputs vanish. F<=C^2 because both fixed pairs must capture. A selected100-by-100 Lindblad density-matrix generator verifies population agreement, positivity and trace, including a coherent record test. These are coarse nuclear phenotype/reaction records, not microscopic nuclear spin wavefunctions.

5. Explicit finite common-pool inventory
A separate ideal preparation policy pools n/p origins before pairing. The same source inventory B=1,000,000 is used across orders, independently of the arithmetic cutoff role. It is a finite computational inventory, not cosmic B. Inherited mean active/source B fixes the nearest-integer active count; inherited n/active B fixes its nearest-integer neutron count. Rounding errors are bounded. Mean prime counts are also projected by largest-remainder allocation, preserving neutron tags5/47 and all proton-prime tags. Pair i uses neutron source slot i and proton slot N+i, without duplicate partner slots. Blocks and actual sample pairs are recorded in finite_pool_origin_registry.json. New slot identities belong to this mean-derived finite preparation and are not original address coordinates. The remainder is the protected inactive source reserve of0.4, and the common energy uses the same rest-shell and quarantined residual allowance. Transport distance, timing and cost have not been derived.
For K16 ascending: activeB={pool['active_initial_B']}, n={pool['initial_n']}, p={pool['initial_p']}, reserveB={pool['reserved_B']}, fixed quartets={pool['initial_quartets']}. Both policies retain original origins; the joint pool permits origins from different addresses to be paired at the preparation boundary.

6. Reference results and denominators
At r_c=r_f=100 and180 s:
Local alpha B/active B={100*local['alpha_B_fraction']:.6f}%; local alpha nuclear rest/active nuclear rest={100*local['alpha_nuclear_rest_fraction']:.6f}%; deuteron B/active B={100*local['deuteron_B_fraction']:.6f}%.
Finite-pool alpha B/active B={100*pool['alpha_B_fraction_of_active']:.6f}%; alpha nuclear rest/active nuclear rest={100*pool['alpha_nuclear_rest_fraction']:.6f}%; deuteron B/active B={100*pool['deuteron_B_fraction_of_active']:.6f}%.
Finite-pool alpha B/common source B={100*pool['alpha_B_fraction_of_common']:.6f}%. Active/source denominators and baryon/rest-energy fractions are not interchanged.
The old24.720666% helium proxy was2*captured neutrons, without a nuclear endpoint or binding dynamics. Its15 capture cases are reproduced under their original definitions. The new alpha endpoint needs two successful captures and a subsequent fusion, so that proxy is not automatically the alpha yield. These are conditional WRRA outputs after verified masses and construction rules are frozen; they are not automatically present-universe abundances.

7. Conserved source and energy
Free n+free p+2d+4alpha+inactive reserve equals the common B. Free p+d+2alpha equals the spectator electron count, and electron/antineutrino counts agree, preserving Q=L=0. Active rest energy is mn Nfree+mp Pfree+md D+ma H+me Ne. Beta nonrest is Qbeta Ne; binding release is Bd D+Balpha H. Their sum with source reserve and quarantined residual/buffer energy equals the same0.4 source E.
The local reference binding release is {local['binding_release_MeV_per_address']:.9f} MeV per weighted admitted address; total source energy remains {r['source_mean_E_MeV']:.9f} MeV per admitted address. No binding term disappears or is counted twice.

8. Verification, verdict and handoff
{r['passed']}/{r['total']} implementation/mathematical/closure/rejection checks pass, not physical experiments or independent evidence counts. There are180 local and180 finite-pool cases. Three vector cases check all421,502 addresses, and the zero-capture boundary recovers0.4 survival. Fresh reproduction checks are recorded separately.
Verified nuclear masses are legitimate calibration inputs. WRRA's calculation resides in the finite parts/origin/preparation/competition/phenotype/common-ledger transformation. Equal numbers from another theory do not remove this internal reproduction or conditional-output attribution. No external microscopic nuclear interaction equation is newly executed. Nuclear wavefunctions, binding Hamiltonians and measured capture/fusion responses remain to be connected.
0.6 receives beta_nonrest and binding_release for photon/neutrino/recoil allocation and spectra. It must not assign all binding release to photons or recount the inherited beta budget. Source preparation, reserve activation, spatial transport, re-pairing, inverse/thermal feedback and other nuclei remain explicit open rules. No new DOI or publication status is assigned to this calculation draft.

Reproduction: OPENBLAS_NUM_THREADS=1 python compute.py; python generate_report.py; python verify_release.py. Dependencies: Python3,numpy,scipy.
References: https://doi.org/10.5281/zenodo.23128482; reference/parts_0_4_results.json; https://physics.nist.gov/cgi-bin/cuu/Value?mdc2mev%7Csearch_for=deuteron+mass; https://www.physics.nist.gov/cuu/pdf/wall_2022.pdf.
'''
(ROOT/'WRRA_Parts_Followup_0_5_EN.txt').write_text(en)
print('Korean and English 0.5 reports generated.')
