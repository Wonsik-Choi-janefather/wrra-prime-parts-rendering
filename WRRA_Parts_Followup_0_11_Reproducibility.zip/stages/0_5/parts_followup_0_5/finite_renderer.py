import math
import numpy as np

def render_all(cfg):
    N=cfg['N'];sieve=np.ones(N+1,bool);sieve[:2]=False
    for prime in range(2,math.isqrt(N)+1):
        if sieve[prime]:sieve[prime*prime::prime]=False
    integers=np.arange(2,N+1)
    addresses=integers[(integers%2==1)&~sieve[2:]]
    w=addresses.astype(float)**-cfg['alpha'];w/=w.sum()
    assemblies=[]
    for K in [15,16]:
        pool=np.flatnonzero(sieve)[:K]
        for order,parts in [('small',pool),('large',pool[::-1])]:
            cycles=addresses//parts.sum()
            counts=np.repeat(cycles[:,None],K,axis=1)
            residue=addresses-cycles*parts.sum()
            while np.any(residue>=2):
                for j,prime in enumerate(parts):
                    fits=residue>=prime;counts[:,j]+=fits;residue-=prime*fits
            neutron=np.isin(parts,cfg['neutron_component_labels'])
            n=counts[:,neutron].sum(axis=1);p=counts[:,~neutron].sum(axis=1)
            pairs=np.minimum(n,p);quartets=pairs//2;single=pairs%2
            assemblies.append({'K':K,'order':order,'parts':parts,'counts':counts,'residue':residue,'n':n,'p':p,'B':n+p,'quartets':quartets,'single_pairs':single,'unpaired_n':n-pairs,'unpaired_p':p-pairs})
    return addresses,w,assemblies
