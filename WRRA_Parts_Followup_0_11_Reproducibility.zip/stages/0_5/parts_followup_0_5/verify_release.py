"""Independent ledger checks and reconstruction in a fresh temporary folder."""
from pathlib import Path
import hashlib,json,math,os,shutil,subprocess,sys,tempfile
import numpy as np
from scipy.integrate import solve_ivp
ROOT=Path(__file__).resolve().parent
checks={}
def check(name,ok):
    checks[name]=bool(ok)
    if not ok:raise AssertionError(name)
def compare(a,b,path=''):
    if isinstance(a,dict):
        check('keys'+path,set(a)==set(b))
        for k in a:compare(a[k],b[k],path+'/'+k)
    elif isinstance(a,list):
        check('length'+path,len(a)==len(b))
        for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+'/'+str(i))
    elif isinstance(a,(int,float)) and not isinstance(a,bool):
        check('number'+path,math.isclose(a,b,rel_tol=2e-11,abs_tol=1e-8))
    else:check('literal'+path,a==b)
r=json.loads((ROOT/'results.json').read_text());cfg=r['verified_inputs']
for name,wanted in json.loads((ROOT/'source_manifest.json').read_text()).items():
    check('source_hash_'+name,hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==wanted)
local=r['local_reference'];pool=r['finite_pool_reference']
check('local_alpha_below_resource_ceiling',local['alpha_B_fraction']<next(x for x in r['pairing_limits'] if x['K']==16 and x['order']=='small')['local_alpha_B_ceiling'])
check('different_denominators_explicit',pool['alpha_B_fraction_of_common']<pool['alpha_B_fraction_of_active'] and pool['alpha_nuclear_rest_fraction']<pool['alpha_B_fraction_of_active'])
check('finite_pool_actual_common_budget',pool['initial_n']+pool['initial_p']+pool['reserved_B']==pool['common_source_B'])
check('quantities_positive',local['binding_release_MeV_per_address']>0 and pool['binding_release_MeV_per_active_B']>0)

# Independent scalar ODE for pair occupation and delayed alpha endpoint.
beta=1/cfg['neutron_mean_life_s'];kc=100*beta;kf=100*beta
def rhs(t,y):
    A,B,C,F=y
    return [-(beta+kc)*A,beta*A,kc*A,kf*(C*C-F)]
ode=solve_ivp(rhs,[0,180],[1,0,0,0],method='DOP853',rtol=1e-12,atol=1e-14)
A,B,C,F=ode.y[:,-1]
q=pool['initial_quartets'];Bactive=pool['active_initial_B']
check('independent_ODE_alpha_agrees',abs(4*q*F/Bactive-pool['alpha_B_fraction_of_active'])<1e-11)
check('independent_ODE_d_agrees',abs(2*(2*q*C-2*q*F)/Bactive-pool['deuteron_B_fraction_of_active'])<1e-11)
check('independent_ODE_beta_agrees',abs(2*q*B/Bactive-pool['beta_events_per_active_B'])<1e-11)

# Verify actual origin registers, rather than just a claim that tags persist.
registries=json.loads((ROOT/'finite_pool_origin_registry.json').read_text())
for entry in registries:
    label=str(entry['K'])+'_'+entry['order'];blocks=entry['blocks'];cursor=0
    for block in blocks:
        check('origin_contiguous_'+label+'_'+str(cursor),block['source_slot_start']==cursor and block['source_slot_stop_exclusive']-cursor==block['count'])
        cursor=block['source_slot_stop_exclusive']
    check('all_source_slots_covered_'+label,cursor==cfg['finite_pool_source_B'])
    for pair in entry['sample_pairs']:
        nblock=next(b for b in blocks if b['source_slot_start']<=pair['n_source_slot']<b['source_slot_stop_exclusive'])
        pblock=next(b for b in blocks if b['source_slot_start']<=pair['p_source_slot']<b['source_slot_stop_exclusive'])
        check('pair_tags_match_'+label+'_'+str(pair['pair_index']),nblock['species']=='n' and pblock['species']=='p' and nblock['additive_prime_tag']==pair['n_prime_tag'] and pblock['additive_prime_tag']==pair['p_prime_tag'])

with tempfile.TemporaryDirectory(prefix='wrra_parts_05_') as tmp:
    fresh=Path(tmp)/'release'
    shutil.copytree(ROOT,fresh,ignore=shutil.ignore_patterns('__pycache__','*.pyc','verification.json','SHA256SUMS'))
    outputs=['results.json','run.log','source_manifest.json','local_nuclear_grid.csv','finite_pool_nuclear_grid.csv','reaction_state_probabilities.csv','pairing_limits.csv','origin_pairing_examples.json','finite_pool_origin_registry.json','baseline_capture_comparison.json','WRRA_Parts_Followup_0_5_KO.txt','WRRA_Parts_Followup_0_5_EN.txt']
    for name in outputs:(fresh/name).unlink(missing_ok=True)
    env=os.environ.copy();env['OPENBLAS_NUM_THREADS']='1'
    p=subprocess.run([sys.executable,'compute.py'],cwd=fresh,env=env,capture_output=True,text=True)
    if p.returncode:print(p.stderr)
    check('fresh_compute',p.returncode==0)
    compare(r,json.loads((fresh/'results.json').read_text()),'/results')
    p=subprocess.run([sys.executable,'generate_report.py'],cwd=fresh,env=env,capture_output=True,text=True)
    check('fresh_reports',p.returncode==0)
    for name in outputs:
        if name not in ['run.log','results.json']:
            check('same_runtime_byte_replay_'+name,(fresh/name).read_bytes()==(ROOT/name).read_bytes())
out={'all_passed':all(checks.values()),'audit_assertions':len(checks),'compute_checks_separate':r['total'],'independent_check':'DOP853 scalar ODE vs finite-state matrix; source hashes and explicit prime-tag origin registry; isolated clean reproduction','scope':'implementation/reproduction audits; not additional independent physical experiments','checks':checks}
(ROOT/'verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({key:value for key,value in out.items() if key!='checks'},indent=2))
