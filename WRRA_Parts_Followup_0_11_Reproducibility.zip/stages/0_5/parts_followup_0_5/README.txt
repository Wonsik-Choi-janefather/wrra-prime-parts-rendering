WRRA Parts Rendering Followup0.5 | Wonsik Choi | 2026-10-04

Run in this directory:
  OPENBLAS_NUM_THREADS=1 python compute.py
  python generate_report.py
  OPENBLAS_NUM_THREADS=1 python verify_release.py

Python3,numpy,scipy required. Producing runtime: numpy2.3.5,scipy1.17.0.
All code is local; no account, network or giant dense address matrix required.
The only large finite arrays are the inherited four additive inventories.

Nuclear masses and beta lifetime are calibrated inputs. Pairing, finite initial
pool redistribution and effective capture/fusion hazards are declared choices.
The nuclear endpoints are coarse phenotypes, not nuclear wavefunction solutions.
Release is retained in accounting without reverse-radiation feedback in0.5.
Physical transport work/time, microscopic reactions and radiation spectra remain
explicit tasks. Reports distinguish baryon and rest-energy denominators.

results.json records the main calculation checks. verification.json records
isolated reconstruction and source audit; its count is not extra physical evidence.
CSV files contain180 local and180 finite-pool cases, reaction-state probabilities,
and finite pairing ceilings. Origin examples retain actual prime tags/motif indices.
SHA256SUMS and source_manifest.json preserve code/results/input provenance.
No new Zenodo/GitHub publication or DOI is claimed for this calculation draft.
