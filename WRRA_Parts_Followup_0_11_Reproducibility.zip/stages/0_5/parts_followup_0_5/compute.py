"""Finite WRRA nuclear phenotype ledger and capture competition.

Nuclear masses are calibration inputs. Pairing, source pooling and effective
capture/fusion hazards are declared construction choices, not cross sections.
"""
from pathlib import Path
import csv, hashlib, itertools, json, math
import numpy as np
from scipy.linalg import expm
from scipy.integrate import quad
from finite_renderer import render_all

ROOT=Path(__file__).resolve().parent
cfg=json.loads((ROOT/'inputs.json').read_text())
ref=json.loads((ROOT/'reference/parts_0_4_results.json').read_text())
old=json.loads((ROOT/'reference/capture_baseline.json').read_text())
m=cfg['recorded_rest_energies_MeV'];nuc=cfg['nuclear_rest_energies_MeV']
mp,mn,me=m['proton'],m['neutron'],m['electron']
md,ma=nuc['deuteron'],nuc['alpha_nucleus']
beta=ref['rate_per_s'];tau=cfg['neutron_mean_life_s']
Q=mn-mp-me;Bd=mn+mp-md;Ba=2*(mn+mp)-ma;Qf=2*md-ma
checks={}
def check(name,ok):
    checks[name]=bool(ok)
    if not ok:raise AssertionError(name)
def dump(name,obj):
    (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def csvout(name,rows):
    with (ROOT/name).open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
check('inherited_beta_rate',abs(beta-1/tau)<1e-14)
check('positive_binding_inputs',min(Bd,Ba,Qf)>0)
check('binding_path_independent',abs(2*Bd+Qf-Ba)<1e-9)
bound_d_beta_Q=md-2*mp-me
check('bound_deuteron_beta_channel_closed',bound_d_beta_Q<0 and abs(bound_d_beta_Q-(Q-Bd))<1e-10)
kinematic_witnesses=[]
for name,initial,final in [('np_capture_zero_CM',mn+mp,md),('two_deuterons_to_alpha_zero_CM',2*md,ma)]:
    photon=(initial*initial-final*final)/(2*initial)
    recoil=math.sqrt(final*final+photon*photon)-final
    check('two_body_energy_momentum_'+name,photon>0 and abs(final+recoil+photon-initial)<1e-9)
    kinematic_witnesses.append({'channel':name,'photon_MeV':photon,'nucleus_recoil_MeV':recoil,'total_nonrest_MeV':initial-final,'scope':'zero-relative-kinetic-energy center-of-momentum witness; not the actual prepared ensemble spectrum or spin amplitude'})

# Species entries carry [electric Q/e, B, L]. Free electrons remain spectators;
# captured nuclei are not claimed to be neutral atoms with atomic binding solved.
quantum={'n':np.array([0,1,0]),'p':np.array([1,1,0]),'e':np.array([-1,0,1]),'antinu':np.array([0,0,-1]),'d':np.array([1,2,0]),'alpha':np.array([2,4,0]),'release':np.array([0,0,0])}
def qsum(items):return sum(count*quantum[name] for name,count in items.items())
channels=[('beta',{'n':1},{'p':1,'e':1,'antinu':1},Q),('capture',{'n':1,'p':1},{'d':1,'release':1},Bd),('fusion',{'d':2},{'alpha':1,'release':1},Qf)]
for name,left,right,gap in channels:
    check('quantum_stoichiometry_'+name,np.array_equal(qsum(left),qsum(right)))
    check('funded_positive_gap_'+name,gap>0)

# Pair A=n+p with the initial e+antinu spectator; B=beta -> two protons;
# C=captured deuteron. Both capture and decay can only consume A once.
pair_names=['A_np','B_beta','C_deuteron']
pair_n=np.array([1.,0.,0.]);pair_p=np.array([1.,2.,0.]);pair_d=np.array([0.,0.,1.])
pair_beta=np.array([0.,1.,0.])
pair_rest=mn*pair_n+mp*pair_p+md*pair_d+me*(1+pair_beta)
pair_release=Q*(1+pair_beta)+Bd*pair_d
check('pair_energy_shell',np.max(abs(pair_rest+pair_release-2*mn))<1e-9)
def pair_solution(t,kc):
    if t<0 or kc<0:raise ValueError('nonnegative exposure and hazard required')
    hazard=beta+kc;departed=-math.expm1(-hazard*t)
    return np.array([math.exp(-hazard*t),beta/hazard*departed,kc/hazard*departed])

states=list(itertools.product(range(3),repeat=2))
state_names=[pair_names[a]+'|'+pair_names[b] for a,b in states]+['F_alpha']
def quartet_generator(kc,kf):
    if kc<0 or kf<0:raise ValueError('nonnegative hazards required')
    G=np.zeros((10,10));edges=[]
    for col,(a,b) in enumerate(states):
        for slot in [0,1]:
            if (a,b)[slot]!=0:continue
            for dest,rate in [(1,beta),(2,kc)]:
                target=list((a,b));target[slot]=dest;row=states.index(tuple(target))
                G[row,col]+=rate;G[col,col]-=rate
                if rate:edges.append((row,col,rate))
    G[9,8]+=kf;G[8,8]-=kf
    if kf:edges.append((9,8,kf))
    return G,edges

# The fusion endpoint retains the two original spectator lepton pairs.
quartet_n=np.array([pair_n[a]+pair_n[b] for a,b in states]+[0.])
quartet_p=np.array([pair_p[a]+pair_p[b] for a,b in states]+[0.])
quartet_d=np.array([pair_d[a]+pair_d[b] for a,b in states]+[0.])
quartet_a=np.array([0.]*9+[1.])
quartet_beta=np.array([pair_beta[a]+pair_beta[b] for a,b in states]+[0.])
quartet_e=2+quartet_beta
quartet_rest=mn*quartet_n+mp*quartet_p+md*quartet_d+ma*quartet_a+me*quartet_e
quartet_release=Q*quartet_e+Bd*quartet_d+Ba*quartet_a
check('quartet_energy_shell',np.max(abs(quartet_rest+quartet_release-4*mn))<1e-9)
check('quartet_B_stoichiometry',np.max(abs(quartet_n+quartet_p+2*quartet_d+4*quartet_a-4))<1e-12)
check('quartet_e_balances_nuclear_charge',np.max(abs(quartet_p+quartet_d+2*quartet_a-quartet_e))<1e-12)

probabilities={};state_rows=[]
for cr in cfg['capture_decay_rate_ratios']:
    kc=cr*beta
    for fr in cfg['fusion_decay_rate_ratios']:
        kf=fr*beta;G,edges=quartet_generator(kc,kf);name=f'{cr}_{fr}'
        check('generator_column_balance_'+name,np.max(abs(G.sum(axis=0)))<1e-12)
        off=G-np.diag(np.diag(G));check('generator_positive_edges_'+name,off.min()>=0)
        check('generator_conserves_total_shell_'+name,np.max(abs((quartet_rest+quartet_release)@G))<1e-9)
        check('rest_loss_is_release_gain_'+name,np.max(abs(quartet_rest@G+quartet_release@G))<1e-9)
        for t in cfg['exposure_times_s']:
            P=expm(G*t);z=P[:,0];pair=pair_solution(t,kc)
            key=f'{cr}_{fr}_{t}'
            check('stochastic_positive_'+key,P.min()>-1e-12 and np.max(abs(P.sum(axis=0)-1))<1e-12)
            check('pair_capture_and_beta_partition_'+key,abs(pair.sum()-1)<1e-12)
            check('free_neutron_equals_two_pair_survivals_'+key,abs(quartet_n@z-2*pair[0])<1e-12)
            check('beta_events_equal_two_pair_beta_probabilities_'+key,abs(quartet_beta@z-2*pair[1])<1e-12)
            check('captured_n_survives_fusion_'+key,abs(quartet_d@z+2*(quartet_a@z)-2*pair[2])<1e-12)
            check('alpha_requires_two_captures_'+key,z[9]<=pair[2]**2+1e-12)
            # Independent integration of dF/dt=kf(C(t)^2-F).
            if kf:
                integral=quad(lambda s:kf*math.exp(-kf*(t-s))*pair_solution(s,kc)[2]**2,0,t,epsabs=1e-13,epsrel=1e-11)[0]
                check('fusion_integral_agrees_'+key,abs(integral-z[9])<1e-11)
            else:
                check('zero_fusion_is_independent_pair_product_'+key,np.max(abs(z[:9]-np.outer(pair,pair).reshape(9)))<1e-12 and z[9]==0)
            probabilities[(cr,fr,t)]=(pair,z)
            state_rows.append({'capture_ratio':cr,'fusion_ratio':fr,'time_s':t,'pair_survival':pair[0],'pair_beta':pair[1],'pair_capture':pair[2],'quartet_alpha_probability':z[9],'quartet_remaining_deuterons':float(quartet_d@z),'two_capture_upper_bound':pair[2]**2})
        check('semigroup_'+name,np.max(abs(expm(G*90)@expm(G*90)-expm(G*180)))<1e-12)

# A selected quartet also evolves as a full Lindblad density matrix. This is
# a coarse orthogonal reaction record, not a nuclear spin wavefunction.
G,edges=quartet_generator(100*beta,100*beta)
I=np.eye(10);Lgen=np.zeros((100,100),complex)
for row,col,rate in edges:
    J=np.zeros((10,10));J[row,col]=math.sqrt(rate);JJ=J.T@J
    Lgen+=np.kron(J,J)-.5*(np.kron(I,JJ)+np.kron(JJ.T,I))
rho=np.zeros((10,10),complex);rho[0,0]=1
evolved=(expm(Lgen*180)@rho.reshape(100,order='F')).reshape(10,10,order='F')
check('density_matrix_matches_population_generator',np.max(abs(np.diag(evolved)-expm(G*180)[:,0]))<1e-12)
check('density_matrix_positive_and_trace_one',np.linalg.eigvalsh(evolved).min()>-1e-12 and abs(np.trace(evolved)-1)<1e-12)
vec=np.zeros(10,complex);vec[0]=vec[8]=1/math.sqrt(2);coherent=np.outer(vec,vec.conj())
coherent_out=(expm(Lgen*30)@coherent.reshape(100,order='F')).reshape(10,10,order='F')
check('coherent_record_channel_positive',np.linalg.eigvalsh(coherent_out).min()>-1e-12 and abs(np.trace(coherent_out)-1)<1e-12)
check('coherent_record_shell_preserved',abs(np.trace(coherent_out)*(4*mn)-4*mn)<1e-9)

addresses,w,assemblies=render_all(cfg)
check('same_421502_addresses',len(addresses)==421502)
Bcommon=np.maximum.reduce([a['B'] for a in assemblies])
rcommon=np.maximum.reduce([a['residue'] for a in assemblies])
mean_source_B=float(w@Bcommon);mean_source_E=float(w@(mn*(Bcommon+rcommon)))
mean_residual_allowance=float(w@rcommon)

def population(n0,p0,q,s,un,up,cr,fr,t):
    pair,z=probabilities[(cr,fr,t)];survival=math.exp(-beta*t)
    free_n=q*(quartet_n@z)+s*pair[0]+un*survival
    free_p=q*(quartet_p@z)+s*(pair_p@pair)+up+un*(1-survival)
    d=q*(quartet_d@z)+s*pair[2];alpha=q*z[9]
    beta_events=q*(quartet_beta@z)+s*pair[1]+un*(1-survival)
    electrons=p0+beta_events
    beta_release=electrons*Q
    binding=d*Bd+alpha*Ba
    nuclear_rest=mn*free_n+mp*free_p+md*d+ma*alpha
    rest=nuclear_rest+electrons*me
    return {'free_n':free_n,'free_p':free_p,'deuterons':d,'alphas':alpha,'beta_events':beta_events,'electrons':electrons,'antineutrinos':electrons,'beta_nonrest':beta_release,'binding_release':binding,'nuclear_rest':nuclear_rest,'active_rest':rest}

rows=[];pool_rows=[];limits=[];samples=[];pool_origins=[]
def finite_tag_allocation(total,tags,expected):
    weights=np.asarray(expected,float);weights/=weights.sum()
    exact=total*weights;counts=np.floor(exact).astype(int)
    missing=total-int(counts.sum())
    priority=np.argsort(-(exact-counts),kind='stable')
    counts[priority[:missing]]+=1
    return [(int(tag),int(count)) for tag,count in zip(tags,counts)]
for a in assemblies:
    K,order=a['K'],a['order'];label=f'{K}_{order}'
    n0,p0=a['n'],a['p'];q,s,un,up=a['quartets'],a['single_pairs'],a['unpaired_n'],a['unpaired_p']
    check('address_conservation_'+label,np.array_equal(a['counts']@a['parts']+a['residue'],addresses))
    check('finite_partition_n_'+label,np.array_equal(2*q+s+un,n0))
    check('finite_partition_p_'+label,np.array_equal(2*q+s+up,p0))
    reserve=Bcommon-a['B'];resE=mn*a['residue'];buffer=mn*(rcommon-a['residue']);reserveE=mn*reserve
    source=next(row for row in ref['source_comparison'] if row['K']==K and row['order']==order)
    means={name:float(w@a[name]) for name in ['n','p','B','quartets','single_pairs','unpaired_n','unpaired_p']}
    check('inherited_active_B_'+label,abs(means['B']-source['mean_active_B'])<1e-10)
    check('inherited_n_fraction_'+label,abs(means['n']/means['B']-source['initial_neutron_fraction_of_active'])<1e-12)
    check('inherited_common_E_'+label,abs(mean_source_E-source['common_supply_MeV_per_address'])<1e-8)
    mean_reserveE=float(w@reserveE);mean_resE=float(w@resE);mean_buffer=float(w@buffer)
    limits.append({'K':K,'order':order,'neutron_fraction':means['n']/means['B'],'local_alpha_B_ceiling':4*means['quartets']/means['B'],'pooled_pairing_neutron_ceiling':2*means['n']/means['B'],'unpaired_n_fraction':means['unpaired_n']/means['B'],'local_single_pair_fraction':2*means['single_pairs']/means['B']})
    # Explicit finite common source inventory; nearest-integer projection of
    # inherited mean allocation. Its size is a computational choice, not cosmic B.
    SB=cfg['finite_pool_source_B'];AB=int(round(SB*means['B']/mean_source_B))
    Npool=int(round(AB*means['n']/means['B']));Ppool=AB-Npool
    matched=min(Npool,Ppool);Qpool=matched//2;Spool=matched%2
    Rpool=SB-AB;pool_total_E=mn*SB+mn*mean_residual_allowance*(SB/mean_source_B)
    pool_quarantine=mn*mean_residual_allowance*(SB/mean_source_B)
    check('finite_pool_initial_B_'+label,Npool+Ppool+Rpool==SB)
    check('finite_pool_integer_rounding_bound_'+label,abs(Npool/AB-means['n']/means['B'])<=.5/AB+1e-14)
    mean_parts=w@a['counts'];is_n=np.isin(a['parts'],cfg['neutron_component_labels'])
    n_tags=finite_tag_allocation(Npool,a['parts'][is_n],mean_parts[is_n])
    p_tags=finite_tag_allocation(Ppool,a['parts'][~is_n],mean_parts[~is_n])
    blocks=[];cursor=0
    for species,alloc in [('n',n_tags),('p',p_tags),('protected_source',[(None,Rpool)])]:
        for tag,count in alloc:
            blocks.append({'species':species,'additive_prime_tag':tag,'source_slot_start':cursor,'source_slot_stop_exclusive':cursor+count,'count':count})
            cursor+=count
    check('finite_pool_origin_slots_complete_'+label,cursor==SB)
    check('finite_pool_neutron_prime_tags_'+label,sum(count for tag,count in n_tags)==Npool and all(tag in cfg['neutron_component_labels'] for tag,count in n_tags))
    check('finite_pool_proton_prime_tags_'+label,sum(count for tag,count in p_tags)==Ppool and all(tag not in cfg['neutron_component_labels'] for tag,count in p_tags))
    def tag_for_slot(slot):
        return next(block['additive_prime_tag'] for block in blocks if block['source_slot_start']<=slot<block['source_slot_stop_exclusive'])
    pair_indices=sorted(set([0,min(1,matched-1),max(0,matched-2),matched-1])) if matched else []
    examples=[{'pair_index':i,'n_source_slot':i,'n_prime_tag':tag_for_slot(i),'p_source_slot':Npool+i,'p_prime_tag':tag_for_slot(Npool+i),'quartet_index':i//2 if i<2*Qpool else None} for i in pair_indices]
    check('finite_pool_no_duplicate_partner_slots_'+label,matched<=Npool and matched<=Ppool and Npool>=matched)
    pool_origins.append({'K':K,'order':order,'blocks':blocks,'pair_rule':'pair i uses n source slot i and p source slot Npool+i; consecutive pairs form quartet; tags retained as orthogonal reaction origins','sample_pairs':examples,'initialization':'finite mean-allocation projection with largest-remainder tag counts; source-slot identities are new preparation indices, not original address coordinates'})
    for cr,fr,t in probabilities:
        name=label+f'_{cr}_{fr}_{t}'
        out=population(means['n'],means['p'],means['quartets'],means['single_pairs'],means['unpaired_n'],means['unpaired_p'],cr,fr,t)
        B=out['free_n']+out['free_p']+2*out['deuterons']+4*out['alphas']
        Qcharge=out['free_p']+out['deuterons']+2*out['alphas']-out['electrons']
        total=out['active_rest']+out['beta_nonrest']+out['binding_release']+mean_reserveE+mean_resE+mean_buffer
        check('local_B_'+name,abs(B-means['B'])<1e-10)
        check('local_Q_L_'+name,abs(Qcharge)<1e-10 and out['electrons']==out['antineutrinos'])
        check('local_energy_'+name,abs(total-mean_source_E)<1e-8)
        if cr==0:
            check('zero_capture_recovers_04_survival_'+name,abs(out['free_n']-means['n']*math.exp(-beta*t))<1e-10)
        row={'K':K,'order':order,'capture_ratio':cr,'fusion_ratio':fr,'time_s':t,'free_n_B_fraction':out['free_n']/means['B'],'deuteron_B_fraction':2*out['deuterons']/means['B'],'alpha_B_fraction':4*out['alphas']/means['B'],'alpha_nuclear_rest_fraction':ma*out['alphas']/out['nuclear_rest'],'beta_events_per_active_B':out['beta_events']/means['B'],'beta_nonrest_MeV_per_address':out['beta_nonrest'],'binding_release_MeV_per_address':out['binding_release'],'active_rest_MeV_per_address':out['active_rest'],'reserve_E_MeV_per_address':mean_reserveE,'source_E_MeV_per_address':mean_source_E,'energy_closure_residual_MeV':total-mean_source_E}
        rows.append(row)
        po=population(Npool,Ppool,Qpool,Spool,Npool-matched,Ppool-matched,cr,fr,t)
        pool_B=po['free_n']+po['free_p']+2*po['deuterons']+4*po['alphas']+Rpool
        pool_charge=po['free_p']+po['deuterons']+2*po['alphas']-po['electrons']
        pool_energy=po['active_rest']+po['beta_nonrest']+po['binding_release']+mn*Rpool+pool_quarantine
        check('finite_pool_B_'+name,abs(pool_B-SB)<1e-7)
        check('finite_pool_Q_L_'+name,abs(pool_charge)<1e-7 and po['electrons']==po['antineutrinos'])
        check('finite_pool_energy_'+name,abs(pool_energy-pool_total_E)<1e-4)
        pool_rows.append({'K':K,'order':order,'capture_ratio':cr,'fusion_ratio':fr,'time_s':t,'common_source_B':SB,'active_initial_B':AB,'initial_n':Npool,'initial_p':Ppool,'reserved_B':Rpool,'initial_quartets':Qpool,'initial_single_pairs':Spool,'alpha_B_fraction_of_active':4*po['alphas']/AB,'alpha_B_fraction_of_common':4*po['alphas']/SB,'alpha_nuclear_rest_fraction':ma*po['alphas']/po['nuclear_rest'],'deuteron_B_fraction_of_active':2*po['deuterons']/AB,'beta_events_per_active_B':po['beta_events']/AB,'binding_release_MeV_per_active_B':po['binding_release']/AB,'common_source_E_MeV':pool_total_E,'energy_closure_residual_MeV':pool_energy-pool_total_E,'scope':'ideal initial finite-pool redistribution; transport cost/time/spatial law not derived'})
    # Full vector checks for all addresses at zero-capture and the reference case.
    for cr,fr,t in [(0,0,180),(100,100,180),(100,0,600)]:
        out=population(n0,p0,q,s,un,up,cr,fr,t);tag=label+f'_{cr}_{fr}_{t}'
        B=out['free_n']+out['free_p']+2*out['deuterons']+4*out['alphas']+reserve
        E=out['active_rest']+out['beta_nonrest']+out['binding_release']+reserveE+resE+buffer
        check('all_addresses_B_'+tag,np.allclose(B,Bcommon,rtol=2e-14,atol=1e-9))
        check('all_addresses_energy_'+tag,np.allclose(E,mn*(Bcommon+rcommon),rtol=3e-14,atol=1e-7))
        check('all_addresses_nonnegative_populations_'+tag,min(np.min(out[x]) for x in ['free_n','free_p','deuterons','alphas','beta_events'])>=-1e-9)
    # Expose deterministic origin pairing for selected finite addresses.
    for address in [9,25,49,95,105,945]:
        pos=int(np.searchsorted(addresses,address));tags_n=[];tags_p=[]
        for prime,count in zip(a['parts'],a['counts'][pos]):
            (tags_n if prime in cfg['neutron_component_labels'] else tags_p).extend([(int(prime),int(i)) for i in range(count)])
        pairs=list(zip(tags_n,tags_p))
        check('origin_pair_count_'+label+'_'+str(address),len(pairs)==min(int(n0[pos]),int(p0[pos])))
        samples.append({'K':K,'order':order,'address':address,'n_origin_tags':tags_n,'p_origin_tags':tags_p,'fixed_pairs':pairs,'quartet_pair_indices':[[2*i,2*i+1] for i in range(len(pairs)//2)],'residue':int(a['residue'][pos]),'status':'all original tags retained in reaction record; nuclei do not overwrite prime labels'})

# Reproduce the old sink counts on its own declared unlimited-partner boundary.
old_checks=[]
for row in old['results']:
    cr,t=row['capture_decay_rate_ratio'],row['window_s'];z=pair_solution(t,cr*beta)
    f=old['input_neutron_fraction'];delta=abs(f*z[2]-row['captured_neutron_fraction'])
    check('old_capture_probability_'+str(cr)+'_'+str(t),delta<1e-12)
    old_checks.append({'capture_ratio':cr,'time_s':t,'old_helium_proxy':row['helium4_mass_proxy'],'reproduced_capture_neutron_fraction':f*z[2],'scope':'old 2*captured proxy is preserved as proxy; it is not alpha endpoint probability'})

def require_binding_margin(available,cost):
    if available<cost:raise ValueError('negative binding-channel energy margin')
try:require_binding_margin(mp+mn,mp+mn+1);rejected=False
except ValueError:rejected=True
check('unfunded_binding_channel_rejected',rejected)
try:quartet_generator(-1,0);rejected=False
except ValueError:rejected=True
check('negative_hazard_rejected',rejected)
check('fusion_disabled_keeps_alpha_zero',all(row['alpha_B_fraction']==0 for row in rows if row['fusion_ratio']==0))
check('capture_disabled_keeps_nuclei_zero',all(row['alpha_B_fraction']==0 and row['deuteron_B_fraction']==0 for row in rows if row['capture_ratio']==0))

csvout('local_nuclear_grid.csv',rows);csvout('finite_pool_nuclear_grid.csv',pool_rows)
csvout('reaction_state_probabilities.csv',state_rows);csvout('pairing_limits.csv',limits)
dump('origin_pairing_examples.json',samples)
dump('finite_pool_origin_registry.json',pool_origins)
dump('baseline_capture_comparison.json',old_checks)
files=[ROOT/'inputs.json',*sorted((ROOT/'reference').glob('*.json'))]
dump('source_manifest.json',{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files})
reference_case=cfg['reference_case']
def select(rows):
    return next(row for row in rows if all(row[k]==v for k,v in reference_case.items()))
out={'version':'0.5','date':'2026-10-04','author':'Wonsik Choi','verified_inputs':cfg,'binding_inputs_and_outputs_MeV':{'beta_Q':Q,'deuteron_binding':Bd,'alpha_binding':Ba,'two_deuterons_to_alpha_release':Qf,'bound_deuteron_beta_Q':bound_d_beta_Q},'kinematic_witnesses':kinematic_witnesses,'state_names':state_names,'transformation':'finite additive inventory -> partner-limited origin-preserving pair/quartet preparation -> competing beta/capture jump states -> alpha phenotype from two captured states -> binding rest-energy replacement and retained release ledger','local_reference':select(rows),'finite_pool_reference':select(pool_rows),'pairing_limits':limits,'source_mean_B':mean_source_B,'source_mean_E_MeV':mean_source_E,'reaction_cases':len(rows),'finite_pool_cases':len(pool_rows),'checks':checks,'passed':sum(checks.values()),'total':len(checks),'calibration_status':'nuclear masses and beta lifetime are verified inputs; capture/fusion hazards, pairing and ideal redistribution are construction choices; no observed helium fraction fitted','falsifiers':['negative partner inventory or energy margin','origin records lost','initial common B/E differs across orders','Q/B/L/rest-plus-release fails closure','fixed physical prepared channel disagrees with predicted endpoint populations','free-neutron beta rate incorrectly used for a negative-Q bound-state channel'],'open_tasks':['nuclear wavefunction/binding Hamiltonian and microscopic capture/fusion response','physical transport cost/time and population preparation','re-pairing, inverse reactions, other nuclear channels and thermal environment','photon/neutrino/recoil allocation and spectra in 0.6','source generation and reserve activation']}
dump('results.json',out)
print(json.dumps({key:out[key] for key in ['passed','total','binding_inputs_and_outputs_MeV','local_reference','finite_pool_reference']},indent=2))
