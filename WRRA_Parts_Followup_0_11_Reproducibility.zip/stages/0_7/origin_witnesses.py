"""Finite event histories retaining inherited source slots and active records."""
from pathlib import Path
import json, numpy as np
import compute as c
ROOT=Path(__file__).resolve().parent
origin=json.loads((ROOT/'reference_origin_examples.json').read_text())[:2]
slots=[x['source_pair'] for x in origin]
rng=np.random.default_rng(7042026);q,_,edges=c.build(.01,.01,.1)
out=[]
for sample in range(32):
    state=0;t=0.;history=[];records={};counter=0
    while True:
        choices=[z for z in edges if z[0]==state]
        if not choices:break
        total=sum(z[2] for z in choices);t+=rng.exponential(1/total)
        if t>180:break
        edge=choices[rng.choice(len(choices),p=[z[2]/total for z in choices])]
        _,dest,rate,kind=edge;s=c.ST[state];d=c.ST[dest];counter+=1
        if kind in [1,5]:
            pair=next(k for k in range(2) if s[k]!=d[k]);key=f'capture_{pair}'
        elif kind in [2,6]:key='fusion'
        else:key=None
        if kind in [1,2]:
            assert key not in records
            records[key]=dict(event_id=counter,source_pairs=slots if kind==2 else [slots[pair]],photon_MeV=c.gf if kind==2 else c.gc)
        if kind in [5,6]:
            assert key in records
            consumed=records.pop(key)
        entry=dict(time_s=t,from_state=state,to_state=dest,kind=kind,active_record_ids={k:v['event_id'] for k,v in records.items()},source_pairs=slots)
        history.append(entry);state=dest
        ledger=c.state_ledger(c.ST[state])
        assert abs(sum(z['photon_MeV'] for z in records.values())-ledger[2])<1e-12
    out.append(dict(sample=sample,final_state=state,source_pairs=slots,active_radiation_records=records,events=history))
(ROOT/'origin_event_witnesses.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(histories=len(out),events=sum(len(z['events']) for z in out))))
