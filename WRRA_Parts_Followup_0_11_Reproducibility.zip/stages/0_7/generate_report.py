from pathlib import Path
import json
P=Path(__file__).resolve().parent
r=json.loads((P/'results.json').read_text());v=json.loads((P/'verification.json').read_text())
def get(c,rev=0):return next(z for z in r['cases'] if z['cooling_s_inv']==c and z['transfer_s_inv']==c and z['hot_return_s_inv']==rev and z['time_s']==180)
a,b,h=get(.01),get(.1),get(.01,.1)
header='WRRA Parts Rendering Followup 0.7\nFinite preparation gates and radiation-return boundaries\nWonsik Choi / 최원식 — sole author\nORCID: 0009-0001-4263-9772 | janefather@gmail.com\n2026-10-04\nPrime Parts 1.0: https://doi.org/10.5281/zenodo.23128482\n'
ko=f'''WRRA 부품 렌더링 후속 연구 0.7
유한 준비 지연·방사 기록 반환·역반응 문턱
최원식 / Wonsik Choi — 단독 저자
ORCID: 0009-0001-4263-9772 | janefather@gmail.com
2026년 10월 4일
기준 소수 부품 1.0: https://doi.org/10.5281/zenodo.23128482

검증 입력 → WRRA 고유 변환 → 산출값 → 반증조건
검증 입력: 부품 후속 0.6의 핵자·전자·중수소핵·헬륨핵 질량, 두 광자선과 반동, 수명 878.3초, 원래 부품 출처를 유지한다. 새로운 관측값을 재적합하지 않는다.
WRRA 고유 변환: 출처가 고정된 네 핵자 묶음 → 27개 유한 준비 상태 → 냉각/전달 완료 문턱 → 핵 표현형과 방사 기록의 생성·반환 → 같은 에너지 장부다.
산출값: 225개 조건의 인구·순방출·보관 반동·냉각 증가분을 계산했다. 180초에서 느린 준비의 헬륨 endpoint 확률 {100*a['helium_probability']:.6f}%, 빠른 준비 {100*b['helium_probability']:.6f}%. 자체 포획·융합 광자의 냉각 후 동일 채널 역반응은 문턱에서 닫히지만 융합 광자에 의한 중수소 분해는 운동학적으로 열린다.
반증조건: 고정 준비와 율에서 인구·방출의 관측 불일치, 원천 출처나 방사 기록의 중복 소비, 상태/외부 작업 예산 보존 실패, 문턱 또는 질량 shell 실패다.
판정: 유한 준비 지연과 방사 반환의 유효 실행 규칙 및 교차 역반응의 운동학 경계를 계산했다. 실제 냉각 힘·공간 수송·광자 충돌율을 도출한 단계는 아니다. 구성 선택을 고정한 뒤의 시간별 인구와 장부는 이 WRRA 구성의 조건부 예측이다.

1. 계승 및 범위
0.6 독립 감사 verify_release.py를 재실행해 5,002개 감사 통과와 새 폴더의 14개 결과 재현을 확인했다. 0.6 원고의 7,717개 생산 검사와 독립 감사 5,002개는 서로 다른 검사 집합이다.
이번 계산은 가용 n/p 두 쌍이 이미 준비된 단일 네 핵자 묶음의 조건부 모듈이다. 주소 평균·전체 공동풀·우주 헬륨 풍부도 계산으로 자동 확장하지 않는다. 입력은 reference_0_6_results.json에 보존하고 SHA256을 results.json에 기록한다.
검증 질량을 이용한 광자선·문턱의 재현은 정당한 보정 및 설명 성과다. 숫자의 기지성은 부품 출처·준비·반응·장부 연결 성과를 취소하지 않는다. 약한 상호작용 미분율·핵력 Hamiltonian·QCD를 실행하지 않았다.

2. 27개 상태와 선언한 유효율
한 쌍은 A=np, B=중성자 베타 전환 endpoint, H=광자와 반동을 가진 d, R=냉각 완료 d, T=다음 반응에 전달 준비가 완료된 d다. 두 쌍의 25개 상태에 FH=반동을 가진 alpha, FT=냉각 완료 alpha를 더한다.
A→B: 1/878.3 초^-1. A→H와 T|T→FH: 100/878.3 초^-1.
H→R 및 FH→FT의 냉각 완료율은 0, 0.01, 0.1, 1, 10 초^-1. R→T의 전달 준비 완료율도 같은 격자를 사용한다. 각 완료시간은 선언된 지수 대기시간이다. 전달 문턱은 주소 간 실제 거리나 입자의 속도가 아니다.
H→A와 FH→T|T의 상관된 기록 반환율은 0, 0.01, 0.1 초^-1의 민감도 선택이다. 30·180·600초에서 계산해 5×5×3×3=225개 조건이다.
반동 상태는 냉각이 완료될 때까지 운동에너지를 유지한다. 냉각 완료에서 그 에너지를 저장고 증가분으로 옮기고, T|T만 정지 입력 융합에 들어간다. 베타/초기 양성자 모티프의 별도 준비는 0.6의 선택을 계승한다. 모든 입자의 유한 냉각을 이번에 해결했다고 표현하지 않는다.

3. 방사 반환과 출처
뜨거운 상태의 반환은 원래 핵 반동과 동일 방사 기록이 함께 접근 가능한 경우의 형식적 역운동학 규칙이다. 광자 방향 전환 장치·접촉·실제 재흡수 진폭을 유도한 것은 아니다. 따라서 반환율을 측정 광자 단면적이라고 부르지 않는다.
포획 반환은 해당 쌍의 광자 기록 하나를 소비하고 A를 복구한다. 융합 반환은 융합 광자와 alpha 반동을 소비해 T|T를 복구하며 앞선 두 포획 광자는 남긴다. 냉각 후에는 이 반환 edge가 없다.
총 포획 횟수와 남아 있는 포획 광자 수는 다르다. 남아 있는 수=총 생성−반환 소비다. 융합도 같다. 반환 후 새 사건은 새 event_id를 받는다.
0.6의 실제 K15 작은 순서, quartet 0의 source slots 0·129234와 1·129235, 소수표지 5·2를 계승한 32개 유한 이력, 총 888개 전이 기록을 실행했다. 매 전이에서 남은 방사 기록 에너지를 상태 장부와 대조했다. 표지는 공간 좌표가 아니다. 전체 풀의 공간 운동을 실행한 증인은 아니다.

4. 동일 에너지 및 외부 작업 장부
초기 두 양성자 모티프에는 전자·반중성미자 두 묶음과 2Q_beta 예산이 이미 있다. 그래서 전체 초기 원천은 4mn이다. 새 베타 전환만 전자 정지질량 및 추가 Q_beta를 갱신한다.
각 상태에서 활성 정지에너지+기존/새 베타 비정지 예산+남은 광자+활성 핵 반동+냉각 저장 증가분=4mn이다. B=4, Q=0, L=0을 유지한다. 같은 반동을 핵과 저장고에 동시에 더하지 않는다.
전달 준비 작업은 완료 사건당 외부 예산 0.001 MeV를 작업 저장 항으로 옮기는 선언된 회계 비용을 추가한다. 이는 WRRA 원천의 새 에너지가 아니다. 외부 초기 예산 0.002 MeV에서 차감하며 각 이력에서 전달 완료는 최대 두 번이다. 실제 거리·마찰·추진 비용을 이 값으로 계산했다는 뜻이 아니다.
0.7의 새 상태 진화는 에너지·인구의 유효 모형이다. 실제 냉각 중 운동량의 시간 변화·환경 힘은 풀지 않았으며 0.6의 사건 운동학과 혼동하지 않는다.

5. 핵 역반응의 운동학 경계
정지 표적 M_f가 광자 하나를 흡수해 정지질량 합 M_i를 만드는 문턱은 E_th=(M_i²−M_f²)/(2M_f)다. 방출선 E_line=(M_i²−M_f²)/(2M_i)와 분모가 다르다.
중수소 분해 문턱 {r['cold_photon_thresholds_MeV']['deuteron_breakup']:.12f} MeV; 포획선 2.223248711921 MeV. 부족분 {r['own_line_deficits_MeV']['capture']:.12f} MeV.
alpha→d+d 문턱 {r['cold_photon_thresholds_MeV']['alpha_to_two_deuterons']:.12f} MeV; 융합선 23.770682374953 MeV. 부족분 {r['own_line_deficits_MeV']['fusion']:.12f} MeV.
따라서 냉각 후 각 자체선의 동일 채널 1광자 역반응은 닫힌다. 모든 광자에 대해 역반응이 닫힌다는 결론은 아니다.
융합 광자 23.770682374953 MeV는 중수소 분해 문턱을 넘는다. d+gamma_f→n+p의 질량 shell·에너지·운동량을 만족하는 세 각도 증인을 실제 계산했다. 최종 전체 운동에너지는 {r['fusion_photon_deuteron_breakup']['lab_excess_MeV']:.12f} MeV다. 선택 각도는 운동학 증인이며 미분 확률 분포가 아니다.
이 교차 흡수는 27상태 인구 방정식에는 아직 연결하지 않았다. 실제 광자 운반·접촉율이 없기 때문이다. 따라서 아래 인구는 교차 흡수 없는 명시된 준비 조건의 결과다. 교차 흡수의 운동학 허용성은 구현됐지만 우주 복사 배경·열평형·광자 피드백이 통합 완료됐다는 판정은 하지 않는다.

6. 기준 결과 — 가용 네 핵자 묶음당, 180초
냉각율=전달 완료율, 반환율 0:
0.01 초^-1: alpha 전체 확률 {100*a['helium_probability']:.6f}%, 냉각 alpha {100*a['cold_helium_probability']:.6f}%, 남은 광자 {a['photon_MeV']:.9f} MeV.
0.1 초^-1: alpha 전체 확률 {100*b['helium_probability']:.6f}%, 냉각 alpha {100*b['cold_helium_probability']:.6f}%, 남은 광자 {b['photon_MeV']:.9f} MeV.
같은 0.01 초^-1 준비에서 반환율 0.1 초^-1: alpha 전체 확률 {100*h['helium_probability']:.6f}%, 총 포획 {h['gross_capture_events']:.9f}, 반환 {h['capture_return_events']:.9f}, 남은 포획 광자 {h['retained_capture_photons']:.9f}개/묶음이다.
이 비율의 분모는 초기 가용 네 핵자 묶음이며 전체 활성 바리온 분모가 아니다. 이전 24.475990% 공동풀 헬륨 바리온 비율과 직접 비교하거나 교체하지 않는다.
냉각/전달 문턱을 빠르게 하면 0.5의 해당 묶음 이상적 endpoint {v['fast_gate_limit'][0]['ideal_0_5']:.12f}로 접근한다. 1,000 초^-1에서 차이는 {v['fast_gate_limit'][-1]['difference']:.3e}다. 기존 성공을 버리지 않고 유한 지연을 추가한 확장이다.

7. 검증 및 재현
행렬 지수 결과를 별도 DOP853 ODE 적분과 비교했다. 최대 차이 {v['max_ode_difference']:.3e}, 검사 {v['passed']}/{v['total']}개 통과. 두 수치 방법은 동일한 선언 전이 생성자를 사용하며 독립 물리 검증은 아니다.
냉각 또는 전달율 0에서 융합 차단, 확률·정규화, 상태 에너지, 순생성/반환 방사 기록, 저장고 증가분, 외부 예산, 정지 표적 문턱, 교차 반응 질량 shell·에너지·운동량을 검사했다.
OPENBLAS_NUM_THREADS=1 python compute.py
OPENBLAS_NUM_THREADS=1 python verify.py
OPENBLAS_NUM_THREADS=1 python origin_witnesses.py
python generate_report.py
의존성: Python, numpy, scipy. 입력 스냅샷·코드·결과·감사·출처 이력·한영 원고·해시를 묶었다. 새 DOI나 Zenodo/GitHub 등록 완료는 주장하지 않는다.

8. 다음에 닫을 실제 접속
공간 위치와 광자 운반/접촉율을 먼저 선언하고, 열려 있는 융합 광자→중수소 분해를 같은 출처·반동·에너지 장부의 인구 방정식으로 연결해야 한다. 그때 산출된 흡수·재짝짓기·핵 인구를 다시 검증한다. 현 단계에는 실제 거리 기반 수송, 냉각력, 핵 스핀 진폭, 측정 반응율, 열평형을 완료했다고 넣지 않는다.
'''
en=header+f'''
Verified inputs → WRRA transformation → outputs → falsification
Inputs: inherit the 0.6 mass, lifetime, line/recoil and origin records; no new empirical fit.
Transformation: fixed-origin quartet → 27 preparation states → finite completion gates → nuclear endpoints and retained radiation records → a single energy ledger.
Outputs: 225 conditions; at 180 s the slow/fast gate alpha probabilities are {100*a['helium_probability']:.6f}% and {100*b['helium_probability']:.6f}% per initially available quartet. Own-line cold-target reverse channels are below threshold, while fusion photons can break deuterons kinematically.
Falsification: loss of probability, origin, record identity, energy, external work budget or mass shell; mismatch with observations under the same frozen preparation and effective rates.
Verdict: a conditional finite preparation and record-return extension, plus cross-channel kinematic boundaries. Spatial transport, cooling forces and absorption hazards have not been derived.

1. Inheritance and scope
The 0.6 independent audit was rerun: 5,002 checks passed and 14 fresh-replay outputs matched. This is distinct from its reported 7,717 production checks. The inherited result snapshot and its SHA256 are retained.
The module starts with two already available np pairs. Its probability denominator is one eligible quartet, not a weighted address, the full finite pool or cosmic abundance. It does not replace the 0.5 24.475990% pool helium baryon result.
Known mass calibration and resulting line reproduction remain legitimate construction and explanatory achievements. New conditional populations belong to this frozen WRRA implementation. No weak differential kernel, QCD or microscopic nuclear Hamiltonian is executed.

2. State definitions and assumptions
Pair states: A=np; B=beta endpoint; H=deuteron plus its photon and active recoil; R=cooled deuteron; T=cooled deuteron admitted to the next reaction. Their 25 products plus hot/cold alpha endpoints FH/FT form 27 states.
A→B has rate 1/878.3 s^-1. Capture A→H and fusion T|T→FH have rate 100/878.3 s^-1. Cooling H→R, FH→FT and transfer-admission R→T each use 0,0.01,0.1,1,10 s^-1. These are effective exponential completion hazards, not measured forces or spatial velocities.
Hot correlated record return H→A and FH→T|T uses 0,0.01,0.1 s^-1. Times are 30,180,600 s, yielding 225 conditions. The remaining beta preparation is inherited from 0.6; finite cooling of every particle is not claimed.
The return edge is a formal inverse preparation with access to the original correlated recoil/photon record. No optical redirection, encounter mechanism or empirical inverse amplitude is derived. It is not ordinary absorption of an outgoing photon at a measured cross section.
Capture return consumes only its matching record. Fusion return consumes the fusion record but retains the preceding two capture photons. Gross production minus matching return equals retained photons. There is no hot-return edge after cooling.
Thirty-two event histories with 888 transitions retain the actual inherited K15 small-order quartet-0 source slots (0,129234) and (1,129235), each tagged by primes 5 and 2. Record identities and their summed energy are checked after every event. Source slots are not spatial coordinates.

3. Energy and work
Initial proton motifs already contain two spectator electron/antineutrino records and 2Q_beta. Initial source energy is 4mn. State rest energy + initial/new beta nonrest budget + retained photons + active nuclear recoil + cooling bath gain equals 4mn. B=4, Q=L=0; recoil is moved, not counted twice.
Transfer-admission costs a declared 0.001 MeV per completion, debited from a separate 0.002 MeV external work budget. At most two completions occur in any history. This accounting token is not a distance-dependent propulsion calculation and is not new WRRA source energy.
The new dynamics closes populations and energy. Continuous momentum transfer and actual bath forces are not solved; 0.6 event kinematics are inherited separately.

4. Cold-target reverse boundaries and open cross-channel
For stationary target mass Mf and product rest-mass sum Mi, the one-photon threshold is (Mi²−Mf²)/(2Mf). The emitted rest-input line uses denominator 2Mi instead.
Deuteron breakup threshold: {r['cold_photon_thresholds_MeV']['deuteron_breakup']:.12f} MeV; own capture line 2.223248711921 MeV, deficit {r['own_line_deficits_MeV']['capture']:.12f} MeV.
Alpha→d+d threshold: {r['cold_photon_thresholds_MeV']['alpha_to_two_deuterons']:.12f} MeV; own fusion line 23.770682374953 MeV, deficit {r['own_line_deficits_MeV']['fusion']:.12f} MeV.
These close only the corresponding cold-target own-line channels. The fusion photon exceeds the deuteron breakup threshold. Three explicit d+gamma_f→n+p angular witnesses satisfy energy, momentum and both mass shells; total final lab kinetic energy is {r['fusion_photon_deuteron_breakup']['lab_excess_MeV']:.12f} MeV. Angles are witnesses, not a derived probability law.
Cross-channel absorption is not coupled into the 27-state generator: transport/encounter hazards are missing. All tabulated populations explicitly exclude this cross-absorption. Kinematic permissibility is implemented; radiation feedback, thermal balance and spatial propagation are not integrated.

5. Representative outputs, per eligible quartet at 180 s
With zero hot-return rate and equal cooling/transfer hazards:
0.01 s^-1: alpha {100*a['helium_probability']:.6f}%, cooled alpha {100*a['cold_helium_probability']:.6f}%, retained photon energy {a['photon_MeV']:.9f} MeV.
0.1 s^-1: alpha {100*b['helium_probability']:.6f}%, cooled alpha {100*b['cold_helium_probability']:.6f}%, retained photon energy {b['photon_MeV']:.9f} MeV.
At 0.01 s^-1 preparation and 0.1 s^-1 hot-return: alpha {100*h['helium_probability']:.6f}%; gross captures {h['gross_capture_events']:.9f}, returns {h['capture_return_events']:.9f}, retained capture photons {h['retained_capture_photons']:.9f}.
Fast gates approach the independently integrated 0.5 quartet endpoint {v['fast_gate_limit'][0]['ideal_0_5']:.12f}; at 1,000 s^-1 the difference is {v['fast_gate_limit'][-1]['difference']:.3e}. Finite-delay extension therefore retains the earlier ideal limit.

6. Validation and reproduction
{v['passed']}/{v['total']} checks passed. Matrix exponentials were compared with DOP853 ODE integration, maximum difference {v['max_ode_difference']:.3e}. They share the declared generator; this is independent numerical integration, not independent empirical validation.
Checks cover blocked fusion, probabilities, state energy, net radiation records, cooling rewards, external budget, own-line thresholds and cross-channel mass shells/energy/momentum. Origin histories are a separate finite witness check.
Run with OPENBLAS_NUM_THREADS=1: python compute.py; python verify.py; python origin_witnesses.py. Then python generate_report.py. Requirements: Python, numpy, scipy.
The package retains snapshots, code, grid, results, audits, histories, bilingual text and hashes. No new DOI or completed GitHub/Zenodo publication is assigned.
Next closure: declare spatial photon transport and encounter rules, then couple allowed fusion-photon deuteron breakup into the same origin/recoil/energy population ledger. Cooling forces, measured amplitudes, spatial transport and thermal equilibrium remain unclosed.
'''
(P/'WRRA_Parts_Followup_0_7_KO.txt').write_text(ko)
(P/'WRRA_Parts_Followup_0_7_EN.txt').write_text(en)
(P/'inputs.json').write_text(json.dumps(dict(stage='0.7',source='reference_0_6_results.json',cooling_rates_s_inv=[0,.01,.1,1,10],transfer_admission_rates_s_inv=[0,.01,.1,1,10],formal_hot_return_rates_s_inv=[0,.01,.1],times_s=[30,180,600],external_work_per_admission_MeV=.001,external_work_budget_MeV=.002,scope='single eligible quartet, cross-absorption excluded from population generator'),indent=2)+'\n')
(P/'requirements.txt').write_text('numpy\nscipy\n')
