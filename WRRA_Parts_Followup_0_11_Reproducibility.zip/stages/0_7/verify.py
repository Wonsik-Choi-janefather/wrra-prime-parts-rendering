"""Independent ODE integration of saved finite generators and scalar audits."""
from pathlib import Path
import json, numpy as np
from scipy.integrate import solve_ivp, quad
import compute as c
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'results.json').read_text()); checks={}; errors=[]
def check(name,condition):
    checks[name]=bool(condition)
    if not condition:raise AssertionError(name)
check('all_state_energy_shells',max(abs(c.energy-4*c.n))<2e-12)
for i,z in enumerate(r['cases']):
    q,rw,edges=c.build(z['cooling_s_inv'],z['transfer_s_inv'],z['hot_return_s_inv'])
    check(f'generator_{i}',max(abs(q.sum(axis=1)))<1e-14 and np.min(q-np.diag(np.diag(q)))>=0)
    y0=np.zeros(35);y0[0]=1
    def rhs(t,y):return np.r_[y[:27]@q,y[:27]@rw]
    sol=solve_ivp(rhs,[0,z['time_s']],y0,method='DOP853',rtol=2e-11,atol=2e-13)
    delta=max(abs(sol.y[:,-1]-np.r_[z['population'],z['counts']]));errors.append(delta)
    check(f'ode_{i}',sol.success and delta<2e-8)
    check(f'probability_energy_{i}',z['min_probability']>=-2e-12 and z['normalization_error']<2e-11 and abs(z['energy_residual_MeV'])<1e-7)
    check(f'net_capture_records_{i}',abs(z['gross_capture_events']-z['capture_return_events']-z['retained_capture_photons'])<2e-10)
    check(f'net_fusion_records_{i}',abs(z['gross_fusion_events']-z['fusion_return_events']-z['retained_fusion_photons'])<2e-10)
    check(f'cooling_reward_{i}',abs(c.tc*z['counts'][3]+c.tf*z['counts'][4]-z['cooling_bath_gain_MeV'])<2e-10)
    check(f'work_budget_{i}',0<=z['external_work_MeV']<=.002+1e-12)
    if z['cooling_s_inv']==0 or z['transfer_s_inv']==0:
        check(f'blocked_fusion_{i}',abs(z['helium_probability'])<1e-14)
gb=1/878.3;kc=kf=100*gb;lam=gb+kc
def ideal(t):return quad(lambda u:kf*np.exp(-kf*(t-u))*(kc/lam*(1-np.exp(-lam*u)))**2,0,t,epsabs=1e-12)[0]
limits=[]
for rate in [10,100,1000]:
    z=c.run(rate,rate,0,180); limits.append(dict(gate_rate=rate,helium=z['helium_probability'],ideal_0_5=ideal(180),difference=ideal(180)-z['helium_probability']))
check('fast_gate_limit',0<limits[-1]['difference']<limits[0]['difference'] and limits[-1]['difference']<1e-6)
check('cold_capture_own_photon_closed',r['own_line_deficits_MeV']['capture']>0)
check('cold_fusion_own_photon_closed',r['own_line_deficits_MeV']['fusion']>0)
cross=r['fusion_photon_deuteron_breakup']
check('cross_channel_is_open',cross['allowed'])
for i,w in enumerate(cross['witnesses']):
    pn=np.array(w['neutron_momentum_MeV']);pp=np.array(w['proton_momentum_MeV'])
    check(f'cross_shell_n_{i}',abs(w['neutron_energy_MeV']**2-pn@pn-c.n**2)<1e-8)
    check(f'cross_shell_p_{i}',abs(w['proton_energy_MeV']**2-pp@pp-c.p**2)<1e-8)
    check(f'cross_momentum_{i}',np.max(abs(pn+pp-np.array([0,0,c.gf])))<1e-12)
    check(f'cross_energy_{i}',abs(w['neutron_energy_MeV']+w['proton_energy_MeV']-c.d-c.gf)<1e-12)
# Independent invariant reconstruction for stationary targets.
for mi,mf,g in [(c.n+c.p,c.d,c.gc),(2*c.d,c.a,c.gf)]:
    check('stationary_threshold_'+str(mf),mf*mf+2*mf*g<mi*mi)
(ROOT/'verification.json').write_text(json.dumps(dict(passed=sum(checks.values()),total=len(checks),max_ode_difference=max(errors),fast_gate_limit=limits,checks=checks),indent=2)+'\n')
print(json.dumps(dict(passed=sum(checks.values()),total=len(checks),max_ode_difference=max(errors),fast_gate_limit=limits)))
