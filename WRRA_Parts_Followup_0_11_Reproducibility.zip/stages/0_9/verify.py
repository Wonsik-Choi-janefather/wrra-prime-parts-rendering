"""Independent finite-attempt absorption audit and identifiability witnesses."""
from pathlib import Path
import json,math
import numpy as np
from scipy.integrate import quad
from scipy.linalg import expm
import compute as c
P=Path(__file__).resolve().parent;r=json.loads((P/'results.json').read_text());checks={}
def check(key,condition):
 checks[key]=bool(condition)
 if not condition:raise AssertionError(key)
orig=r['source_origin']+[r['target_origin']]
slots=[x[key] for x in orig for key in ['n_source_slot','p_source_slot']]
check('six_distinct_original_slots',len(set(slots))==6)
check('prime_tags_inherited',[(x['n_prime_tag'],x['p_prime_tag']) for x in orig]==[(5,2),(5,2),(47,2)])
check('no_axis_oblique',c.rays((1,0,2))==[])
check('one_axis_collinear',c.rays((0,0,2))==[4])
cache={x:c.prior.setup(x) for x in [.01,.1]}
max_integral=0.;max_resolution=0.
for i,z in enumerate(r['cases']):
 check(f'energy_{i}',abs(z['combined_energy_residual_MeV'])<2e-9)
 check(f'photon_partition_{i}',abs(z['photon_partition_residual'])<2e-11)
 check(f'target_probability_{i}',abs(z['target_population_residual'])<2e-11)
 check(f'nonnegative_{i}',min(z[x] for x in ['photon_flight','photon_contact','photon_escape','photon_absorbed','target_hot_np','target_cold_np','target_beta_endpoint','target_recaptured_hot_d','target_recaptured_cold_d'])>=-2e-11)
 check(f'one_photon_{i}',z['photon_absorbed']<=z['aligned_fraction']*z['source_fusion']+2e-11)
 check(f'external_budget_{i}',z['external_work_remaining_MeV']>=-2e-11)
 if z['aligned_fraction']==0 or z['attempt_probability']==0 or z['flight_time_s']>=z['observation_s']:
  check(f'blocked_{i}',abs(z['photon_absorbed'])<1e-15)
 if z['aligned_fraction'] and z['attempt_probability'] and z['observation_s']==180:
  src,_=cache[z['cooling_s_inv']]
  def flux(t):return (100/878.3)*src(t)[c.prior.s.ST.index(('T','T'))]
  expected=sum(z['aligned_fraction']*z['attempt_probability']*(1-z['attempt_probability'])**k*
    quad(flux,0,180-z['flight_time_s']-k,epsabs=2e-13,epsrel=2e-12)[0]
    for k in range(10) if 180-z['flight_time_s']-k>0)
  err=abs(expected-z['photon_absorbed']);max_integral=max(max_integral,err)
  check(f'adaptive_finite_sum_{i}',err<2e-10)
  if z['scale_m_per_cell']==5*c.prior.C and z['attempt_probability']==.1 and z['target_cell']==[0,0,2]:
   high=c.run(z['cooling_s_inv'],z['scale_m_per_cell'],tuple(z['target_cell']),.1,180,nodes=128,solvers=cache[z['cooling_s_inv']])
   err=max(abs(z[key]-high[key]) for key in ['photon_absorbed','target_hot_np','target_cold_np','target_beta_endpoint','target_recaptured_hot_d','target_recaptured_cold_d'])
   max_resolution=max(max_resolution,err)
   check(f'64_vs_128_{i}',err<2e-10)

def candidate(cooling,position,q):
 return next(z for z in r['cases'] if z['cooling_s_inv']==cooling and z['target_cell']==list(position)
  and z['attempt_probability']==q and z['scale_m_per_cell']==5*c.prior.C and z['observation_s']==180)
same_origin_geometry=[candidate(.1,(0,0,2),.1),candidate(.1,(1,0,2),.1)]
same_origin_coupling=[candidate(.1,(0,0,2),.1),candidate(.1,(0,0,2),.5)]
check('same_origins_different_geometry',same_origin_geometry[0]['photon_absorbed']>0 and same_origin_geometry[1]['photon_absorbed']==0)
check('same_origins_different_coupling',same_origin_coupling[0]['photon_absorbed']<same_origin_coupling[1]['photon_absorbed'])
# All six axes carry equal 0.6 label weight. Their realization probability is 1/6.
check('finite_orientation_normalization',sum(1/6 for _ in c.AXES)==1)
out=dict(passed=sum(checks.values()),total=len(checks),max_adaptive_integral_error=max_integral,
 max_64_128_population_error=max_resolution,
 identifiability_witnesses={'same_origins_geometry_absorption':[x['photon_absorbed'] for x in same_origin_geometry],
 'same_origins_coupling_absorption':[x['photon_absorbed'] for x in same_origin_coupling]},checks=checks)
(P/'verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='checks'}))
