from pathlib import Path
import json,math
P=Path(__file__).resolve().parent;r=json.loads((P/'results.json').read_text());v=json.loads((P/'verification.json').read_text())
def x(q,pos=(0,0,2)):
 return next(z for z in r['cases'] if z['cooling_s_inv']==.1 and z['scale_m_per_cell']==5*299792458 and z['target_cell']==list(pos) and z['attempt_probability']==q and z['observation_s']==180)
a=x(.1);b=x(.5);off=x(.1,(1,0,2));zero=x(0)
ko=f'''WRRA 부품 렌더링 후속 연구 0.9
원래 소수 표지를 보존한 유한 광선 경로와 접촉 확률의 식별성
최원식 / Wonsik Choi — 단독 저자
ORCID 0009-0001-4263-9772 | janefather@gmail.com
2026년 10월 4일
소수 부품 1.0: https://doi.org/10.5281/zenodo.23128482

검증 입력 → WRRA 고유 변환 → 산출값 → 반증조건
검증 입력: 0.6~0.8 핵 질량, 수명, 광자·반동 에너지, 출처 레지스터, 여섯 방사 방향, 고정 c를 계승했다. 동일 원천 소수표지와 표적 소수표지를 모든 비교에서 유지했다.
WRRA 고유 변환: 출처가 분리된 네 핵자 원천과 중수소 표적 → 유한 위치 배치·6축 광선 경로 → 일정 시간 간격의 유한 접촉 시험 → 각 기록의 방출·이동·접촉·탈출·흡수 → 표적 분해/재포획/베타 장부다.
산출값: 144개 조건에서 광자·6바리온 장부를 계산했다. 기준 축 위 표적에서 흡수 {100*a['photon_absorbed']:.6f}%, 표적 중수소 잔존 {100*a['target_surviving_d']:.6f}%/모듈이다. 같은 출처라도 표적 위치 또는 접촉 확률을 바꾸면 흡수가 달라지는 두 명시적 증인을 산출했다.
반증조건: 같은 고정 배치/접촉 규칙에서 출처·6축 정규화·빛 도착시간·광자 단일 소비·6mn·B/Q/L/외부 예산이 실패하거나 해당 규칙의 측정값이 불일치하면 수정/기각한다.
판정: 0.9의 유한 경로·접촉 실행 모듈은 완료됐다. 소수 출처 숫자만으로 실제 공간 배치나 미시 흡수율을 유일하게 계산한다는 강한 명제는 현재 자료에서 성립하지 않는다. 같은 출처에서 서로 다른 결과를 직접 계산해 부족한 입력을 특정했다. 한 가지 배치와 접촉 확률을 검증 입력으로 확정한 뒤의 값은 이 WRRA 구조의 조건부 예측이다.

1. 계승 구조와 역할이 다른 표지
원천 두 np쌍은 기존 K15 작은 순서의 실제 슬롯 (0,129234),(1,129235), 표적은 분리된 (129232,258466)이다. 원천 소수표지는 각 쌍5/2, 표적은47/2다. 여섯 원천 슬롯은 겹치지 않고 동결된다. 원천 상태 27개, 흡수 이후 표적 상태5개, 물리 에너지 및 출처 레지스터는0.8에서 계승한다.
소수 부품 번호는 물리 공간의 측정 좌표가 아니다. 따라서 슬롯 간 정수 거리129232를 실제 공간 거리로 대입하지 않는다. 최초 위치를 정의하는 유한 배치 M과 공간 한 칸의 길이 ell을 별도 입력으로 공개했다.
원천은 격자(0,0,0), 표적 후보는 (0,0,2) 또는 (1,0,2)다. 여섯 방향 ±x,±y,±z는0.6 방사 표지의 동등 가중1/6을 그대로 사용한다. 경로가 표적을 지나는 방향만 접속한다. 축상 표적은 +z 한 방향이 접속되어 정렬 비중1/6이고, 비축 표적은 이 축 광선 선택에서 접속 경로가 없다. 광선 폭, 표적 반지름, 실제 위치 분포를 모델에서 유도한 것은 아니다.

2. 유한 길이와 접촉 규칙
한 칸 길이는 c/2,5c,50c미터로 선언했다. 축상 표적은 두 칸 떨어져 있어 비행시간1,10,100초다. c=299,792,458m/s는 고정 입력이고 예측 대상이 아니다. 비축 표적의 Euclidean 거리도 표시하지만 방향이 연결되지 않으면 흡수는0이다.
광선이 표적 접촉영역에 들어오면 Δt=1초 간격으로 최대10회 시도한다. 매 시도의 흡수 확률 q=0,0.1,0.5,1을 선택하고 실패확률을 곱해 기록한다. k번째 시도(0≤k<10)의 무조건부 흡수 가중치는 q(1−q)^k. 10회 모두 실패할 확률은(1−q)^10이다.
q는 부품 소수표지로부터 유도한 단면적이 아니다. 같은 출처의 유한 응답을 정의하는 자유 구성 입력이다. 검증값을 반영하여 q와 공간 배치를 고정하는 모형 구성은 정당하지만, 고정 전에 산출한 수가 관측을 독립적으로 예측했다고 처리하지 않는다.

3. 실제 확률·핵종·에너지 계산
원천 융합 유량 J(u)=k_f P_TT(u)를0.7/0.8 생성자로 계산한다. 비행 tau 후 k번째 접촉은 u+tau+kΔt에서 일어나므로 관측시점 t의 흡수는
P_abs(t)=eta Σ_(k=0)^9 q(1−q)^k ∫_0^max(0,t−tau−kΔt) J(u)du.
매 흡수 시점 이후에는0.8 표적 전이 X(뜨거운 np)→A(냉각 np)→B(베타), A→H(재포획 뜨거운 d)→D(냉각 d)를 진화시킨다. 적분의 종료시간과 시도 횟수는 모두 유한하다. 64점 양의 Gauss–Legendre 절점을 사용해 각 조건의 표적인구를 계산했다.
광자 상태는 비행 중, 접촉 중, 탈출, 흡수의 네 장부로 구분한다. 방향이 맞지 않는 광자도 탈출 장부에 남는다. 흡수한 원래 융합 광자만 하나 지우고 표적 재포획 광자는 새 사건으로 더한다. 질량 증가·광자 감소·핵자 운동에너지·냉각 저장·새 결합 방출을 한6mn 장부에 넣었다.
이번 기하/접촉 비교는 원천 냉각/전달율0.01,0.1초^-1, 길이3개, 위치2개, 접촉확률4개, 시점30/180/600초로144개 조건이다. q=0과 축 밖 배치는 의도된 차단 사례다.0.8의 연속 hazard와 역할은 같지만 유한 접촉 시각/확률은 다른 선언 규칙이다. 두 수치를 같은 입력이라 표시하지 않는다.

4. 기준 결과 및 식별성 증인 — 냉각/전달0.1초^-1, ell=5c미터,180초
원천·표적 원래 소수표지는 모든 사례에서 같다.
축상(0,0,2), q=0: 흡수 {100*zero['photon_absorbed']:.6f}%.
축상(0,0,2), q=0.1: 흡수 {100*a['photon_absorbed']:.6f}%, 중수소 최종 잔존 {100*a['target_surviving_d']:.6f}%, 새 포획 광자 {a['new_capture_photons']:.9f}개/모듈.
축상(0,0,2), q=0.5: 흡수 {100*b['photon_absorbed']:.6f}%, 중수소 잔존 {100*b['target_surviving_d']:.6f}%.
비축(1,0,2), q=0.1: 흡수 {100*off['photon_absorbed']:.6f}%.
따라서 동일한 소수 원천·핵 질량·수명·방사 축만으로 흡수율을 하나로 확정할 수 없다. 0.1→0.5의 q 변경은 고정 배치에서도 흡수를 {100*a['photon_absorbed']:.6f}→{100*b['photon_absorbed']:.6f}%로 바꾼다. 배치 변경은 q를 고정해도 {100*a['photon_absorbed']:.6f}→0%로 바꾼다. 이는 수학적으로 부족한 규칙의 위치를 보이는 직접 증인이다.

5. 보존과 감사
여섯 방향 확률은 합1이며 한 원천 광자/한 표적 흡수 한계를 지킨다. 모든 조건에서 광자 합=원천 생성, 초기 원천·표적의 활성 정지+베타 예산+광자+핵 반동+환경 증가분=6mn이다. 원천 이동 작업 비용은 별도 외부0.002MeV에서 유지한다. B=6,Q=L=0 및 출처의 고정 표지는0.8과 같이 적용한다.
{v['passed']}/{v['total']}개 수학·장부 검사 통과. 별도로 적응형 적분으로 유한 접촉 합계를 계산해 최대 차이 {v['max_adaptive_integral_error']:.3e}. 선택64/128절점 인구 차이 {v['max_64_128_population_error']:.3e}. 같은 출처의 위치·q 반례를 자동 검사한다. 검사 수는 독립 물리 실험 횟수가 아니다.

6. 단계별 결론과 다음 연결
0.9에서 ‘표지와 원래 사건 기록을 유지한 유한 광선/접촉 계산’과 ‘미정 물리 입력의 정확한 식별’을 마무리했다. 부품 자체가 좌표·단면적·핵 냉각력을 이미 산출했다고 선언하지 않는다.
다음 0.10에는 실제 위치·응답 메커니즘 또는 측정된 공간/흡수 입력을 채택하는 명시적 규칙을 세우고, 냉각·수송의 환경 운동량과 외부 작업 장부를 같은 경로에 연결해야 한다. 동일 가정을 바꿔 수치를 맞추는 후행 보정은 새 구성으로 기록하며, 확정 뒤 미측정 출력의 조건부 예측을 분리한다. 기존 상류·하류 통합 계열과 임의로 섞지 않는다.

재현: OPENBLAS_NUM_THREADS=1 python compute.py; OPENBLAS_NUM_THREADS=1 python verify.py; python generate_report.py. Python, numpy, scipy. 코드·원래 결과 스냅샷·144조건 CSV·한영 설명·감사·해시를 함께 담았다. 이번 0.9에 새 DOI나 GitHub/Zenodo 게시 완료는 배정하지 않았다.
'''
en=f'''WRRA Parts Rendering Followup 0.9
Origin-preserving finite photon routing and identifiability of contact response
Wonsik Choi / 최원식 — sole author
ORCID 0009-0001-4263-9772 | janefather@gmail.com
2026-10-04
Prime Parts 1.0: https://doi.org/10.5281/zenodo.23128482

Verified inputs → WRRA transformation → outputs → falsification
Inputs: inherit the0.6–0.8 masses, lifetime, photon/recoil lines, prime-origin registry, six directions, and fixed calibrated c. Freeze all origins across comparisons.
Transformation: disjoint source quartet and target pair → finite external placement and six axial rays → finite discrete contact attempts → explicit flight/contact/escape/absorption records → breakup, cooling, recapture and beta populations in the same six-baryon energy ledger.
Outputs:144 scenarios. With target on-axis and q=0.1, absorption {100*a['photon_absorbed']:.6f}% and surviving target deuteron {100*a['target_surviving_d']:.6f}% per module at180s. Same inherited origins but different placements or per-attempt couplings give different results.
Falsification: fixed-configuration failure of origin preservation, six-direction normalization, finite flight, unique photon consumption, 6mn/B/Q/L/external budget or observation agreement.
Verdict: a finite origin-preserving routing and response implementation is complete. The stronger assertion that prime-origin integers alone identify physical positions and microscopic absorption probability is underdetermined by the inherited inputs. After a configuration is fixed with validated inputs, its untouched outputs are conditional WRRA predictions.

1. Inherited origins and their roles
The inherited K15 small-order source quartet uses slot pairs(0,129234),(1,129235), each tagged5/2; the disjoint target uses(129232,258466), tagged47/2. All six slots stay unchanged. Source27-state and target5-state ledgers are inherited.
A slot identifier is not a measured position. Hence the arithmetic gap between source slots is never used as a metric distance. Spatial embedding M and length per cell ell are explicit inputs, not consequences of the prime labels.
Source cell=(0,0,0), target candidates=(0,0,2) and(1,0,2). Six equiprobable inherited axial orientations are ±x,±y,±z. One axial ray connects to the on-axis target (alignment1/6); none connects to the off-axis target under this declared zero-width axial rule. Beam width, real target radius and spatial distribution remain uncalculated.

2. Finite propagation and contact
Cell length ell is c/2,5c,50c meters; the on-axis target is two cells away, giving flight times1,10,100s. Fixed c=299792458m/s is a calibration input, not a model prediction. The off-axis Euclidean distance is also recorded, even when no axial ray reaches the target.
At arrival, at most ten contact attempts occur at1s intervals. The prescribed per-attempt absorption probability is q=0,0.1,0.5,1. Attempt k=0..9 has unconditional weight q(1−q)^k and ten failures have probability(1−q)^10. This is a finite response rule, not a cross section derived from prime factorization.
Fitting or fixing q and the embedding with verified information is legitimate model construction. Results calculated after they are frozen are conditional predictions of that construction; no pre-calibration numerical prediction is claimed.

3. Computation and ledger
Source fusion flux J(u)=kf P_TT(u) comes from the inherited finite generator. The photon emitted at u reaches a target after tau and has the kth opportunity at u+tau+kΔt. Therefore
P_abs(t)=eta Σ[k=0..9] q(1−q)^k ∫[0,max(0,t−tau−kΔt)]J(u)du.
From each absorption time, propagate target X hot np→A cooled np, A→B beta or A→H recaptured hot d→D cooled d. All windows, observations and integrations are finite. Positive64-node quadrature resolves the populations.
A photon record is either in flight, in contact, escaped or absorbed. Misaligned photons remain escaped records. Only an absorbed fusion photon is removed once; target recapture emits a new photon. The same6mn energy ledger includes rest-mass change, kinetic energy, cooling storage, recoil and new binding release.
Two source cooling/transfer choices(.01,.1/s), three lengths, two positions, four q values and three times(30,180,600s) give144 cases. Zero coupling and off-axis placements are intentional blocked controls. This discrete rule has a distinct clock from the continuous response in0.8; their numbers must not be equated without a defined conversion.

4. Identifiability witnesses: fixed source origins, cooling/transfer0.1/s, ell=5c m,180s
On-axis, q=0: absorbed {100*zero['photon_absorbed']:.6f}%.
On-axis, q=.1: absorbed {100*a['photon_absorbed']:.6f}%; surviving deuteron {100*a['target_surviving_d']:.6f}%; new recapture photons {a['new_capture_photons']:.9f}/module.
On-axis, q=.5: absorbed {100*b['photon_absorbed']:.6f}%; surviving deuteron {100*b['target_surviving_d']:.6f}%.
Off-axis, q=.1: absorbed {100*off['photon_absorbed']:.6f}%.
The same masses, lifetime, original labels and angular channel set thus do not select one absorption value. Changing q on fixed geometry moves absorption {100*a['photon_absorbed']:.6f}→{100*b['photon_absorbed']:.6f}%; changing geometry with q fixed moves it {100*a['photon_absorbed']:.6f}→0%. This is a constructive non-identifiability witness, not a numerical failure of the inherited model.

5. Audit and interpretation
The six directions normalize to one. Photon production partitions into flight, contact, escape and one-time absorption; energy sums to6mn including source/target and bath. The separate external0.002MeV source transport-work budget is preserved. B=6,Q=L=0 and frozen original parts apply as in0.8.
{v['passed']}/{v['total']} mathematical/ledger checks passed. Adaptive independent scalar finite-attempt integration differs at most {v['max_adaptive_integral_error']:.3e}; selected64/128-node population differences are {v['max_64_128_population_error']:.3e}. Explicit fixed-origin geometry/coupling alternatives are checked automatically. These are not counts of independent physical experiments.

6. Closure and next connection
Closed: finite origin-preserving axial routing, discrete contact calculation, target populations and the exact identification of missing physical inputs. Position, absorption cross section and cooling force are not automatically outputs of integer origin tags.
Next,0.10 can specify an actual placement/response mechanism or adopt validated spatial and absorption inputs, then connect cooling and propagation momentum/work to that path. Retuning a frozen input to a later measurement is recorded as a revised configuration. No upstream/downstream synthesis is silently mixed into this parts program.
Reproduction: OPENBLAS_NUM_THREADS=1 python compute.py; OPENBLAS_NUM_THREADS=1 python verify.py; python generate_report.py. Python,numpy,scipy. Inputs, inherited snapshots,144-case CSV, code, checks, bilingual report and hashes are retained. No new DOI or completed GitHub/Zenodo publication is asserted.
'''
(P/'WRRA_Parts_Followup_0_9_KO.txt').write_text(ko)
(P/'WRRA_Parts_Followup_0_9_EN.txt').write_text(en)
(P/'inputs.json').write_text(json.dumps(dict(stage='0.9',c_m_s=299792458,source_cell=[0,0,0],target_cells=[[0,0,2],[1,0,2]],directions=r['axes'],cell_lengths_m=[299792458/2,5*299792458,50*299792458],source_cooling_transfer_s_inv=[.01,.1],per_attempt_absorption_probability=[0,.1,.5,1],attempt_interval_s=1,maximum_attempts=10,observation_times_s=[30,180,600],quadrature_nodes=64,origin_source=r['source_origin'],origin_target=r['target_origin'],configuration_status='placement and absorption coupling externally supplied; labels alone underdetermine both'),indent=2)+'\n')
(P/'requirements.txt').write_text('numpy\nscipy\n')
