WRRA Parts Followup 0.3 — Wonsik Choi only
Run: python3 compute.py
Dependencies: numpy, scipy. Finite N=1,000,000.
Outputs: results.json, spin_color_results.json, decoder_comparison.csv.
The reference module is copied from the reviewed prime-parts 1.0 fold-current study. Only spin_flavor() is invoked; decay rates are outside 0.3 scope.
This is a calibrated conditional decoder, not a particle-production dynamics model.
