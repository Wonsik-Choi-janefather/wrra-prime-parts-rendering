from pathlib import Path
import json,math,csv,importlib.util
import numpy as np
B=Path(__file__).resolve().parent
cfg=json.loads((B/'inputs.json').read_text()); N=cfg['N']; m=cfg['recorded_rest_energies_MeV']; Q=m['neutron']-m['proton']-m['electron']
checks={}
def check(k,v):
 checks[k]=bool(v)
 if not v:raise AssertionError(k)
# Q/e, 3B, L, number of fermions modulo 2. All colorless here.
states={'n':(0,3,0,1),'p':(1,3,0,1),'e':(-1,0,1,1),'anti_nu_e':(0,0,-1,1),'positron':(1,0,-1,1),'nu_e':(0,0,1,1),'photon':(0,0,0,0)}
def total(names):
 a=np.sum([states[x] for x in names],axis=0);a[3]%=2;return a
source=np.array(states['n']);channels=[]
for label,names,allowed in [('n',['n'],True),('p+e',['p','e'],False),('p+e+anti_nu_e',['p','e','anti_nu_e'],True)]:
 t=total(names); valid=bool(np.array_equal(t,source));check('decoder_'+label,valid==allowed)
 channels.append({'channel':label,'Q_3B_L_fermion_parity':t.tolist(),'compatible_with_n_like_source':valid})
check('zero_B_source_cannot_supply_one_baryon',source[1]!=0)
check('single_equal_motif_cannot_add_e_pair',0<Q<2*m['electron'])
check('two_equal_pe_motifs_can_pool_pair_threshold',2*Q>2*m['electron'])
# Abstract spin witness p_up tensor (e_up anti_down - e_down anti_up)/sqrt2.
sigma=[np.array([[0,1],[1,0]]),np.array([[0,-1j],[1j,0]]),np.diag([1,-1])]
J=[]
for op in sigma:
 J.append(sum(np.kron(np.kron(op/2 if i==0 else np.eye(2),op/2 if i==1 else np.eye(2)),op/2 if i==2 else np.eye(2)) for i in range(3)))
psi=np.zeros(8,complex);psi[1]=1/np.sqrt(2);psi[2]=-1/np.sqrt(2)
check('three_fermion_spin_half_witness',np.linalg.norm(sum(j@j for j in J)@psi-.75*psi)<1e-12)
check('spin_witness_normalized',abs(np.vdot(psi,psi)-1)<1e-12)
spec=importlib.util.spec_from_file_location('fold',B/'reference/fold_compute.py');fold=importlib.util.module_from_spec(spec);spec.loader.exec_module(fold)
sf=fold.spin_flavor()
for k,v in sf['checks'].items():check('reference_'+k,v)
(B/'spin_color_results.json').write_text(json.dumps(sf,indent=2)+'\n')
s=np.ones(N+1,bool);s[:2]=False
for p in range(2,math.isqrt(N)+1):
 if s[p]:s[p*p::p]=False
v=np.arange(2,N+1);n=v[(v%2==1)&~s[2:]];w=n.astype(float)**-cfg['alpha'];w/=w.sum();rows=[]
for K in [15,16]:
 pool=np.flatnonzero(s)[:K]
 for order,parts in [('small',pool),('large',pool[::-1])]:
  cyc=n//parts.sum();c=np.repeat(cyc[:,None],K,axis=1);r=n-cyc*parts.sum()
  while np.any(r>=2):
   for j,p in enumerate(parts):
    f=r>=p;c[:,j]+=f;r-=p*f
  neu=np.isin(parts,cfg['neutron_component_labels']);cn=c[:,neu].sum(axis=1);cp=c[:,~neu].sum(axis=1);ct=cn+cp
  check(f'address_{K}_{order}',np.all(c@parts+r==n))
  check(f'lepton_closed_{K}_{order}',np.all(cp-cp==0))
  check(f'baryon_closed_{K}_{order}',np.all(cn+cp==ct))
  # Equal motif candidate only. Residue is quarantined and cannot fund these bounds.
  rest=cn*m['neutron']+cp*(m['proton']+m['electron']);excess=cp*Q
  check(f'energy_{K}_{order}',np.allclose(ct*m['neutron'],rest+excess,rtol=1e-12,atol=1e-7))
  bound=np.floor((excess+1e-10)/(2*m['electron'])).astype(int)
  check(f'pair_bound_funded_{K}_{order}',np.all(bound*2*m['electron']<=excess+1e-8))
  rows.append({'K':K,'order':order,'mean_baryon_motifs':float(w@ct),'neutron_fraction':float(w@cn/(w@ct)),'proton_electron_antineutrino_fraction':float(w@cp/(w@ct)),'required_antineutrinos_per_baryon_motif':float(w@cp/(w@ct)),'open_MeV_per_baryon_motif':float(w@excess/(w@ct)),'address_pooled_e_pair_kinematic_upper_bound_per_baryon':float(w@bound/(w@ct)),'address_weight_with_pair_threshold':float(w[bound>0].sum()),'scope':'massless anti-neutrino approximation; zero recoil lower bound; upper bound, not yield; residue excluded'})
check('e_pair_conserved',np.array_equal(total(['e','positron']),np.zeros(4,int)))
check('nu_pair_conserved',np.array_equal(total(['nu_e','anti_nu_e']),np.zeros(4,int)))
check('photon_pair_conserved',np.array_equal(total(['photon','photon']),np.zeros(4,int)))
available=m['neutron']-m['electron']
nu_energy=(available**2-m['proton']**2)/(2*available)
proton_energy=math.sqrt(m['proton']**2+nu_energy**2)
check('beta_endpoint_energy_momentum_witness',abs(proton_energy+m['electron']+nu_energy-m['neutron'])<1e-10 and nu_energy>0)
out={'beta_endpoint_witness':{'electron_at_rest_MeV':m['electron'],'antineutrino_energy_MeV':nu_energy,'proton_recoil_kinetic_MeV':proton_energy-m['proton'],'momentum':'p_proton=-p_antineutrino; electron momentum zero; endpoint witness not spectrum'},'version':'0.3','author':'Wonsik Choi','verified_inputs':cfg,'transformation':'finite additive renderer -> supplied n-like source per motif -> simultaneous Q/B/L/fermion-parity decoder -> finite spin/color witness -> equal-motif surplus thresholds','channels':channels,'assemblies':rows,'Q_MeV':Q,'e_pair_threshold_MeV':2*m['electron'],'checks':checks,'passed':sum(checks.values()),'total':len(checks),'limitations':['Source B=1 and L=0 is a declared assumption, not derived from integers.','Color/spin ansatz supplied, not QCD solution.','Spin witness is abstract SU(2); massless neutrino helicity and differential amplitudes not solved.','No decay rate, neutrino absolute mass, radiation spectrum, or particle yield derived.','Different orders require different source motif counts; energy envelope alone does not fix source baryon ledger.','Charge cancellation does not require equal counts for arbitrary unequal charge magnitudes.'], 'falsification_conditions':['If motif source has L=1, mandatory antineutrino conclusion is inapplicable; rerun decoder.','A B=0 source without compensating antibaryons cannot realize this B=1 motif.','Negative energy margin or failed color/spin/charge/B/L closure rejects a proposed branch.','Predicted yields or spectra must satisfy observations once dynamics is supplied.']}
(B/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
with (B/'decoder_comparison.csv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
print(json.dumps({'passed':out['passed'],'total':out['total'],'assemblies':rows},indent=2))
