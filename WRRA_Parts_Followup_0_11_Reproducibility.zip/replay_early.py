"""Run stages 0.1–0.5 in isolated copied directories, retaining raw snapshots."""
from pathlib import Path
import tempfile,shutil,subprocess,os,json,math,hashlib
ROOT=Path(__file__).resolve().parent
def compare(a,b,path='root'):
 if isinstance(a,dict) and isinstance(b,dict):
  if set(a)!=set(b):return path+'.keys'
  for k in a:
   e=compare(a[k],b[k],path+'.'+str(k))
   if e:return e
 elif isinstance(a,list) and isinstance(b,list):
  if len(a)!=len(b):return path+'.length'
  for i,(x,y) in enumerate(zip(a,b)):
   e=compare(x,y,path+'.'+str(i))
   if e:return e
 elif isinstance(a,(int,float)) and not isinstance(a,bool) and isinstance(b,(int,float)) and not isinstance(b,bool):
  if not math.isclose(a,b,rel_tol=2e-10,abs_tol=2e-9):return path
 elif a!=b:return path
 return None
def main():
 stages=[];env=dict(os.environ,OPENBLAS_NUM_THREADS='1')
 for i in range(1,6):
  source=ROOT/'stages'/f'0_{i}'
  if i>=3:source=source/f'parts_followup_0_{i}'
  with tempfile.TemporaryDirectory() as tmp:
   dest=Path(tmp)/source.name;shutil.copytree(source,dest)
   before=json.loads((source/'results.json').read_text())
   attempt=subprocess.run(['python3','compute.py'],cwd=dest,env=env,capture_output=True,text=True,timeout=150)
   row=dict(stage=f'0.{i}',returncode=attempt.returncode,published_result_sha256=hashlib.sha256((source/'results.json').read_bytes()).hexdigest(),
    stdout_tail=attempt.stdout[-300:],stderr_tail=attempt.stderr[-500:])
   if attempt.returncode==0 and (dest/'results.json').exists():
    after=json.loads((dest/'results.json').read_text());row['first_difference']=compare(before,after)
    row['replayed_result_sha256']=hashlib.sha256((dest/'results.json').read_bytes()).hexdigest()
   else:row['first_difference']='run_failed'
   verifier=dest/'verify_release.py'
   if verifier.exists() and attempt.returncode==0:
    v=subprocess.run(['python3','verify_release.py'],cwd=dest,env=env,capture_output=True,text=True,timeout=150)
    row['verify_returncode']=v.returncode;row['verify_tail']=(v.stdout+v.stderr)[-500:]
   stages.append(row)
   print(json.dumps({k:v for k,v in row.items() if k not in ['stdout_tail','stderr_tail','verify_tail']}),flush=True)
 (ROOT/'early_replay.json').write_text(json.dumps(stages,indent=2)+'\n')
 if any(z['returncode']!=0 or z['first_difference'] is not None or z.get('verify_returncode',0)!=0 for z in stages):
  raise SystemExit(1)
if __name__=='__main__':main()
