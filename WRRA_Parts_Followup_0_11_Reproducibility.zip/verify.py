"""Independent integer/Decimal reconciliation and replay/denominator checks."""
from pathlib import Path
from decimal import Decimal,getcontext
import json,csv,math
P=Path(__file__).resolve().parent;S=P/'source_snapshots';getcontext().prec=45
result=json.loads((P/'results.json').read_text());early=json.loads((P/'early_replay.json').read_text());late=json.loads((P/'late_replay.json').read_text())
R={i:json.loads((S/f'0_{i}_results.json').read_text()) for i in range(1,11)}
checks={}
def check(name,ok):
 checks[name]=bool(ok)
 if not ok:raise AssertionError(name)
check('all_ten_source_stages',len(early)==5 and len(late)==5)
for entry in early+late:
 label=entry['stage'];check('replay_'+label,entry['first_difference'] is None and all(z==0 for k,z in entry.items() if k.endswith('_returncode')))
check('source_snapshot_count',len(result['source_manifest'])==13)
check('stage03_leptons',next(z for z in R[3]['channels'] if z['channel']=='p+e')['compatible_with_n_like_source'] is False and next(z for z in R[3]['channels'] if z['channel']=='p+e+anti_nu_e')['compatible_with_n_like_source'] is True)
check('early_research_check_counts',[R[i]['passed'] for i in range(1,7)]==[83,66,45,209,1654,7717])
with (S/'0_5_finite_pool_grid.csv').open() as f:
 pool=next(z for z in csv.DictReader(f) if (z['K'],z['order'],z['capture_ratio'],z['fusion_ratio'],z['time_s'])==('15','small','100','100','180'))
with (S/'0_6_release_grid.csv').open() as f:
 release=next(z for z in csv.DictReader(f) if (z['mode'],z['K'],z['order'],z['capture_ratio'],z['fusion_ratio'],z['time_s'],z['eta'])==('finite_pool','15','small','100.0','100.0','180.0','0.0'))
D=lambda s:Decimal(str(s));B=D(pool['active_initial_B']);C=D(release['capture_events']);F=D(release['fusion_events']);beta=D(release['new_beta_events'])
links=result['numeric_links']
check('macro_alpha_from_fusion_decimal',abs(4*F/B-D(pool['alpha_B_fraction_of_active']))<D('1e-13'))
check('macro_deuteron_from_remaining_capture_decimal',abs(2*(C-2*F)/B-D(pool['deuteron_B_fraction_of_active']))<D('1e-13'))
check('macro_beta_from_events_decimal',abs(beta/B-D(pool['beta_events_per_active_B']))<D('1e-13'))
check('macro_zero_energy_decimal',abs(D(release['active_rest_MeV'])+D(release['protected_storage_MeV'])+D(release['resolved_release_MeV'])-D(release['common_source_MeV']))<D('.0005'))
check('macro_filter_is_address_weight',D(str(R[1]['filter_weight']))==D('0.05000000000000001'))
check('macro_pool_denominator',links['K15_finite_pool_source_B']==1000000 and links['K15_pool_initial_active_B']==999219)
check('macro_source_energy',abs(D(links['K15_pool_common_source_MeV'])-D(release['common_source_MeV']))<D('1e-7'))
check('micro_conservation_6mn',abs(D(links['selected_six_baryon_source_MeV'])-6*D(R[6]['inherited_masses_MeV']['neutron']))<D('1e-11'))
check('branch_probability_only',D(links['selected_ray_180s_absorption_probability'])<D('0.17') and D(links['selected_ray_180s_surviving_deuteron_probability'])<1)
check('distinct_macro_micro_units',result['integration_gate']['full_pool_spatial_feedback'].startswith('open') and all('per_six_baryon' not in x for x in result['numeric_links']))
check('conditional_model_not_universal_1_0',result['integration_gate']['unconditional_parts_1_0'].startswith('not certified'))
check('all_written_integration_checks',result['passed']==result['total'] and all(result['checks'].values()))
summary=dict(passed=sum(checks.values()),total=len(checks),replayed_stages=10,cross_stage_checks=result['passed'],
 macro_scope='K15-small, 1,000,000 B finite pool',micro_scope='single disjoint six-baryon conditional module',checks=checks)
(P/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='checks'}))
