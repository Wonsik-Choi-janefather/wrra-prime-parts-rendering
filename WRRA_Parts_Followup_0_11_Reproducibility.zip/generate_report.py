from pathlib import Path
import json
P=Path(__file__).resolve().parent;r=json.loads((P/'results.json').read_text());v=json.loads((P/'verification.json').read_text())
n=r['numeric_links'];g=r['integration_gate']
ko=f'''WRRA 소수 부품 렌더링 후속 연구 0.11 — 공통 장부 통합 검증
부품 출처·원천·입자·핵 결합·방사·유한 경로의 연결과 1.0 판정 범위
저자: 최원식 / Wonsik Choi (단독)
ORCID 0009-0001-4263-9772 | janefather@gmail.com
2026년 10월 4일
기준: WRRA Prime Parts 1.0, https://doi.org/10.5281/zenodo.23128482

검증 입력 → WRRA 고유 변환 → 산출값 → 반증조건
검증 입력: 0.1~0.10의 원 계산 자료를 각 독립 폴더에서 다시 실행한다. 산술 N=1,000,000과 가중지수, 소수5·47 배정, 검증 질량·중성자 수명, K15 작은 우선 준비와 각 단계의 명시적 접촉·냉각·공간 선택을 원형대로 유지한다. 알려진 상수의 보정 사용은 정당한 모형 구성이다.
WRRA 고유 변환: 유한 주소/부품 → Q/B/L과 공통 원천 → 원래 소수표지 보존 내부 전이 → 핵 경쟁·결합 → 반동을 보존한 방사 장부 → 선택한 분리된 출처의 광자 경로·접촉·재포획 → 사건 수준 4운동량. 분모가 다른 단계는 명시적 변환 없이 합산하지 않는다.
산출값: 열 단계의 저장 수치 결과가 각각 재실행과 일치했다. 같은 K15 작은 우선 공동풀에서0.4~0.6의 공통 에너지·핵 사건·방사 합계가 연결된다. 별도6바리온 모듈에서는0.7~0.10의 운동학·선택 광자 흡수·재포획·운동량 보존을 연결했다. 이번 0.11 교차 장부 {r['passed']}/{r['total']}개와 독립 재계산 감사 {v['passed']}/{v['total']}개가 통과했다.
반증조건: 원래 표지/원천 중복 소비, 같은 종류·단위·분모의 불일치, 원천 에너지/핵종 인구/방사 합계의 틀림, 광자·환경·외부 작업의 중복 계상, 고정 준비 아래 출력과 측정의 불일치다. 선언한 q나 공간 배치를 뒤늦게 변경하면 새 구성과 재검증으로 기록한다.
판정: 실제 계산한 두 층의 조건부 연결은 WRRA의 독자적 구조·설명 및 확정 입력 뒤의 조건부 산출이다. 이미 알려진 물리량을 보정하고 재현했다는 사실은 이 성과를 없애지 않는다. 선택6바리온 모듈을 공동풀 전체의 공간 반응으로 곧바로 확대하는 변환은 아직 실행하지 않았다. 따라서 0.11 통합본은 완료했지만 그 미실행 연결을 ‘부품1.0 전체 통합 완료’라고 표기하지 않는다.

1. 연구 계보와 공통 검증 입력
0.1은 주소 비율·모티프 개수·선형 부하·에너지의 단위와 분모를 지정했다. 0.2는 검증 질량을 비용으로 쓴 여러 원천 공급 후보를 계산했다. 0.3은 L=0 원천에서 n과 p+e+반중성미자 판독을 Q/B/L과 스핀 필요조건으로 구별했다. 0.4는 네 조립에 같은 B/E 외피, 미사용 저장고, 표지 보존 내부 전류 및 검증 수명으로 보정한 전이를 실제 행렬에 넣었다.
0.2의 에너지 전용 공급 후보와0.4의 공통 B/E 외피는 다른 구성이다. 둘을 더하거나 같은 원천의 동시 속성으로 바꾸지 않았다. 기존 내부 곱셈 주소 표지75/45도 덧셈 부품 소수표지5/47과 수치 동일시하지 않는다. 외부 이론의 QCD/약한 미분 진폭을 실제 이번 계산에서 실행하지 않았으므로 그것을 통합 완료라고 부르지 않는다.
공통 산술 입력은 N=1,000,000, 홀수합성수421,502개, 소수5·47의 중성자 모티프 배정이다. 주소 가중치에서 통과 비율 {100*n['filtered_address_fraction']:.6f}%는 산술 분모의 값이다. 우주의 물리 에너지 중 보통 물질5%로 자동 치환하지 않는다.
질량(MeV)은 mn=939.56542194, mp=938.27208943, me=0.51099895069, md=1875.61294500, m_alpha=3727.3794118, 중성자 수명은878.3초다. 중수소·alpha 질량은0.5부터 검증값으로 보정한다. c는0.8 이후 고정 이동 척도이며 예측값이 아니다. 중성미자 질량0은 이 운동학 모듈의 근사다.

2. K15 작은 우선 공통 원천 → 유한 공동풀의 실제 연결
주소 조건부 평균 공통 B는 {n['common_B_per_conditional_address']:.12f}모티프/통과주소, 공통 에너지는 {n['common_energy_MeV_per_conditional_address']:.9f}MeV/통과주소다. 0.4·0.5 원천값을 직접 대조했다.
0.5의 K15 작은 우선 공동풀은 공통 B={n['K15_finite_pool_source_B']:,d}, 그중 초기 활성 B={n['K15_pool_initial_active_B']:,d}, 중성자={n['K15_pool_initial_neutron_B']:,d}, 비활성 저장 B=781, 초기 네 핵자 묶음={n['K15_pool_initial_quartets']:,d}개다. 원천 에너지는 {n['K15_pool_common_source_MeV']:,.6f}MeV/풀이다. 주소당 공통 E/B를100만 B에 적용한 값과0.5/0.6 풀의 에너지가 일치한다. 주소 개수, 조건부 주소 가중치 및 유한 물리 모티프 수는 서로 별개다.
포획·융합율을 각각 중성자 수명 율의100배로 선택하고180초를 쓰면0.6 재실행의 풀 기대 사건은 포획 {n['K15_pool_capture_count']:,.9f}, 융합 {n['K15_pool_fusion_count']:,.9f}, 새 베타 {n['K15_pool_new_beta_count']:,.9f}다. 사건 기대수는 정수 인구에서 나온 실수이고 단일 역사에 반 개 사건이 생긴다는 뜻이 아니다.
0.6의 융합 수×4/초기 활성B={100*n['K15_pool_alpha_fraction_active']:.9f}%는0.5 헬륨 바리온 비율과 일치한다. 남은 포획 수 C−2F에2를 곱해 활성B로 나눈 중수소 비율과 새 베타 사건 수도0.5 자료와 일치했다. 이는 숫자 인용이 아니라 동일 부품 원천·유한 짝·핵 사건 장부를 실제 수식으로 대조한 것이다.
0.5의 보정 핵 질량은 포획 결합2.22456637MeV, 두 d→alpha 추가 결합23.84647820MeV를 준다.0.6 방사 계산에서 포획/융합 광자+각 반동이 이 결합 방출과 각각 일치한다. 풀의 남은 전체 광자 에너지는 {n['K15_pool_photon_MeV']:,.6f}MeV, 모든 비정지 방출은 {n['K15_pool_release_MeV']:,.6f}MeV다. 활성 정지에너지+보호 저장+비정지 방출이 공통 {n['K15_pool_common_source_MeV']:,.6f}MeV와 일치한다. 기존 양성자 모티프 베타 예산과 새 붕괴 사건을 따로 세어 중복 방출하지 않는다.

3. 같은 출처 계보의 선택6바리온 모듈
0.5 유한풀의 K15 작은 우선 실제 출처에서 원천 np쌍(0,129234),(1,129235)와 별도 표적 np쌍(129232,258466)을 추출했다. 소수 표지는5/2,5/2,47/2이고 원천 슬롯 여섯 개가 겹치지 않는다. 선택 원천은 네 바리온(4mn), 선행 결합을 포함해 준비된 표적은 두 바리온(2mn)으로 합계 {n['selected_six_baryon_source_MeV']:.9f}MeV다. 이것은 유한풀과 출처 계보는 같지만 다른 조건부 실험 준비다. 풀에서 이 슬롯을 떼어낸 나머지 핵 인구까지 재진화시킨 결과가 아니다.
0.7은 유한 냉각·다음 반응 준비 문턱과 방사 기록 반환, 자체 광자선의 냉각 표적 역반응 문턱을 계산했다. 자기 포획 광자로 냉각 d를 분해하는 경로는 닫히지만 고에너지 융합 광자의 d 분해는 운동학적으로 열린다.0.8은 그 교차 광자의 비행·흡수 후 냉각/베타/재포획을 한6바리온 장부에 연결했다.
0.9는 여섯 동등 방사축, 유한 격자 배치와 최대10회의 접촉을 시행했다. 소수 슬롯은 출처 표지이고 공간 좌표는 별도 입력이다. 기준 배치(광자10초 비행, 정렬1/6, 접촉 시도확률0.1, 냉각0.1초^-1)의180초 흡수 확률은 {100*n['selected_ray_180s_absorption_probability']:.6f}%, 재포획을 포함한 표적 중수소 잔존은 {100*n['selected_ray_180s_surviving_deuteron_probability']:.6f}%다. 이는 확정한 준비의 조건부 WRRA 산출이다.0.8의 연속 접촉율과0.9의 이산 접촉확률은 시간이 다른 규칙이므로 같은 숫자로 취급하지 않는다.
0.10은 선택된 방향·흡수·베타/재포획 분기에 대해 {n['selected_event_witnesses']}개 전체 사건 경로에서 핵·광자·환경·외부 작업의4운동량을 검사했다. 광자가10광초 거리를 이동했고 반동과 흡수 운동량은 유한 환경에 이전됐다.0.7 원천의0.002MeV 작업 은행은 원천 내부 준비에만 적용된다. 이 값을 광자 이동이나 물리 핵자의10광초 수송비로 중복 사용하지 않는다.

4. 분모와 규칙의 충돌 거부
종류·단위·분모·조립이 다른 양을 더하면 계산이 거부되도록 실행했다. K15 공동풀 전체 photon MeV를 선택6바리온의 흡수 확률과 바로 곱하면 재료 소비·표적 배정·출처 수송이 없어서 이중 계상이 생긴다. K16 작은 순서의0.5 기본 예시(활성 헬륨 약24.476%)를 현재 K15 풀의25.357%와 같은 준비라고 합치지 않는다.
0.1의 산술 통과5%, 0.4 주소당 공통 B/E, 0.5~0.6 백만 B 공동풀, 0.7~0.10 선택 여섯 바리온은 각각 분모가 다르다. 전체 우주 물리 에너지의5/26.8/68.2% 구성이나 중성미자 절대질량에 이번 부품 계산을 바로 대응시키지 않는다.
표지·원천·입자 판독·핵·광자·환경이 한 모형에서 연결되는 부분은 모두 실제 계산 파일로 재실행됐다. 한정된 선택 실험의 결과를 우주 전체 결과로 외삽한 문장은 통합 판정에 포함하지 않는다.

5. 재현·반증·1.0으로 넘기는 정확한 조건
0.1~0.5를 원본 보존 폴더를 복사해 재실행하고0.4/0.5 별도 감사도 통과했다.0.6~0.10도 분리된 폴더에서 계산과 별도 감사가 모두 통과했다.0.1·0.2의 JSON 수치는 같지만 직렬화 바이트가 달랐고,0.3~0.10은 계산 결과 바이트도 같았다. 원고/코드/계산을 혼동하지 않고 값의 동일성과 파일 바이트 동일성을 따로 기록했다.
이번 교차 연결 {r['passed']}/{r['total']}개, 별도 Decimal·원자료 대조 {v['passed']}/{v['total']}개 검사를 통과했다. 검사 횟수는 관측 독립증거 수가 아니다.
현재0.11 통합 범위는 고정한 공통 질량·원천·K15 공동풀의 핵/방사 장부와 별도 선택6바리온의 방사 되먹임 및 사건 운동량이다. 검증 입력을 채택해 q·공간 배치를 확정하는 일은 정당한 구성이고 독립예측을 이론의 필수조건으로 두지 않는다. 그 값을 고정한 뒤 미측정 출력을 계산하면 WRRA의 조건부 예측이다.
부품1.0을 ‘공동풀 전체의 방사·공간 되먹임까지 동일 원천에서 실행된 모형’으로 확정하려면, K15 활성 전체의 공간 배치와 표적 대응 규칙을 하나로 고정하고 원래 출처를 소비·보존하면서 다수 광자의 교차 흡수·재포획을 공동풀에 실제 반영해야 한다. 그 연결이 현재 미실행이므로0.11을1.0으로 자동 개명하지 않는다. 미시 흡수율이나 냉각력의 독창적 유도 자체가 필수라는 뜻은 아니다. 고정/보정된 값을 써도 된다. 필요한 것은 선언된 값을 같은 장부 안에서 실제 실행하고 확인하는 것이다.
재현: OPENBLAS_NUM_THREADS=1 python replay_early.py; OPENBLAS_NUM_THREADS=1 python replay_late.py; python compute.py; python verify.py; python generate_report.py. 원본0.1~0.6 묶음,0.7~0.10 단계 소스/결과, 교차 계산·감사, 한영 원고, 해시를 제공한다. 이0.11에 새 DOI나 GitHub/Zenodo 게시 완료를 배정하지 않았다. 기존 상류·하류 통합 연구와 이 부품 계열을 자동 합치지 않는다.
'''
en=f'''WRRA Prime Parts Rendering Followup 0.11 — Common-Ledger Synthesis
Linking origin, source, particles, binding, radiation and a finite selected route
Wonsik Choi / 최원식 — sole author
ORCID 0009-0001-4263-9772 | janefather@gmail.com
2026-10-04
Baseline Prime Parts 1.0: https://doi.org/10.5281/zenodo.23128482

Verified inputs → WRRA transformation → outputs → falsification
Inputs: rerun original0.1–0.10 packages separately. Keep N=1,000,000, calibrated arithmetic weights, prime labels5/47, measured masses and neutron lifetime, K15 small-order preparation, plus each declared spatial/contact/cooling choice. Calibration to known values is legitimate model construction.
Transformation: finite address/part decomposition → Q/B/L and common source → origin-preserving internal transition → nuclear capture/binding → recoil-resolved radiation → photon flight/contact/recapture for a disjoint selected source and target → event four-momentum. Denominators are never silently merged.
Outputs: all ten stored numerical results match isolated replays. The K15 small-order common source, finite pool, nuclear counts and radiation are reconciled across0.4–0.6. The separately prepared six-baryon module links0.7–0.10 kinematics, conditional photon absorption/recapture and event momentum. New synthesis checks: {r['passed']}/{r['total']} plus {v['passed']}/{v['total']} independent Decimal/raw-data audits.
Falsification: duplicated origins or radiation; incompatible units/denominators; failed B/Q/L, source/nuclear/release/work/momentum accounting; or measurement mismatch under the frozen preparation. Retuning q or embedding after a result requires a new declared configuration.
Verdict: both computed conditional links are WRRA's structural explanatory results and its outputs after calibration are conditional predictions. Known calibration values do not negate that status. A calculation that propagates the selected six-baryon photon feedback through every member of the finite pool has not yet been executed. This0.11 synthesis is complete within its stated scope; an unconditional whole-pool Parts1.0 is not certified by this calculation.

1. Stages and shared inputs
0.1 typed address/part/load/energy denominators;0.2 candidate energy-supply envelopes;0.3 conditional L=0 neutron or complete p+electron+antineutrino decoding;0.4 common B/E source, protected reserve, origin-preserving internal current and lifetime-calibrated finite transition. The0.2 energy-only envelopes and0.4 common B/E envelope are different constructions; they are not summed. Original additive prime labels5/47 are not numerically identified with legacy multiplicative internal tags75/45. Archived external weak/QCD amplitudes are not claimed to have been executed here.
The shared arithmetic input has1,000,000 cutoff and421,502 odd-composite addresses. The {100*n['filtered_address_fraction']:.6f}% weighted address passage is an arithmetic denominator, not automatically the physical ordinary-matter energy fraction. Measured rest energies(MeV): neutron939.56542194, proton938.27208943, electron0.51099895069, deuteron1875.612945, alpha3727.3794118; neutron lifetime878.3s. c is fixed for later photon flight. Neutrino mass zero is this kinematic approximation.

2. Actually reconciled K15 small-order finite pool
Common source per conditionally admitted address: B={n['common_B_per_conditional_address']:.12f} motifs, E={n['common_energy_MeV_per_conditional_address']:.9f}MeV. Direct0.4/0.5 comparison agrees. The distinct finite-pool preparation has common B={n['K15_finite_pool_source_B']:,}, active B={n['K15_pool_initial_active_B']:,}, initial neutron B={n['K15_pool_initial_neutron_B']:,}, protected B=781 and {n['K15_pool_initial_quartets']:,} initial quartets. Source E={n['K15_pool_common_source_MeV']:,.6f}MeV per pool; the address-average E/B scaled to one million B equals the0.5 and0.6 pool value.
With capture/fusion hazards100 times the calibrated free-neutron decay rate at180s, expected capture={n['K15_pool_capture_count']:,.9f}, fusion={n['K15_pool_fusion_count']:,.9f}, new beta={n['K15_pool_new_beta_count']:,.9f} per pool. Fractional expected events do not mean fractional actual events. Four fusion baryons per fusion over active B yield {100*n['K15_pool_alpha_fraction_active']:.9f}% alpha B, matching0.5. Remaining deuteron B follows2(C−2F)/active B and beta counts match as well.
Calibrated nuclear masses give2.22456637MeV capture binding and23.84647820MeV additional fusion release. The0.6 photon+recoil amounts equal each release. Total retained photons={n['K15_pool_photon_MeV']:,.6f}MeV and all resolved nonrest release={n['K15_pool_release_MeV']:,.6f}MeV. Active rest+protected source+resolved nonrest release equals common {n['K15_pool_common_source_MeV']:,.6f}MeV. Inherited initial proton-motif beta budget and new beta events are counted separately.

3. Selected disjoint six-baryon branch
The same K15 finite-origin registry contains source pairs(0,129234),(1,129235) and separately selected target pair(129232,258466), tagged5/2,5/2,47/2. Six origin slots are distinct. The conditional source quartet has4mn; prepared target has2mn including its prior capture record; combined {n['selected_six_baryon_source_MeV']:.9f}MeV. This selects a different experiment from the full pool's preparation. It does not rerun the pool after removing these slots.
0.7 calculates finite readiness/cooling, record returns and cold own-line thresholds. A higher-energy fusion photon can break a cold deuteron.0.8 couples that cross-channel to flight, breakup, cooling and beta/recapture populations.0.9 adds six axial directions, an external finite embedding and up to ten discrete contact attempts. With10s flight, alignment1/6, q=.1, cooling0.1/s at180s, absorption={100*n['selected_ray_180s_absorption_probability']:.6f}% and surviving target deuteron={100*n['selected_ray_180s_surviving_deuteron_probability']:.6f}%. These are WRRA conditional outputs after inputs are frozen; 0.8's continuous contact hazard has a different clock and should not be identified with0.9's per-attempt probability.
0.10 verifies {n['selected_event_witnesses']} chosen full four-momentum histories for source, target, photons, finite bath and separate readiness-work account. The photon, not a nucleon, traverses the ten-light-second path. The0.002MeV readiness bank is not silently charged again to photon flight or a hypothetical massive-particle journey.

4. Typed-denominator and integration boundaries
Executable typed quantities reject addition when kind, units, denominator or assembly differ. It would double count to multiply the full pool's photon MeV by the selected six-baryon absorption probability without a target assignment, source depletion and rerun of all interactions. The default K16 small-order example in0.5 (roughly24.476% active alpha B) is not the present K15 small-order result (roughly25.357%).
Weighted address passage, per-admitted-address common B/E, one-million-B pool, and selected six-baryon module are distinct denominators. The present parts calculations are not automatically physical cosmic5/26.8/68.2% energy fractions or absolute neutrino-mass outputs.

5. Verification, scope and next gate
0.1–0.5 were run in separate copied folders;0.4/0.5 audit scripts passed.0.6–0.10 compute and independent verification passed in isolated copies. Stage0.1/0.2 normalized numerical JSON matches although serialization bytes differ; stages0.3–0.10 results match byte for byte. The synthesis reports {r['passed']}/{r['total']} cross-stage checks and {v['passed']}/{v['total']} separate Decimal/raw-data checks. These are implementation and ledger audits, not independent physical experiments.
Neither independent novel predictions nor derivation of all fitted constants are required for this WRRA assessment. Once verified geometry/absorption/cooling inputs are frozen, unmeasured outputs produced by its own transformations are conditional WRRA predictions. The remaining whole-pool gate is a calculation: fix an embedding and target-matching rule for all active K15 origins, apply many emitted photons and repeat absorption/recapture with origin consumption, then close the full pool ledger. Microscopic q or cooling force may instead be calibrated; it need not be invented independently. Until this many-origin spatial feedback is actually run,0.11 should not be relabelled as an unconditional whole-pool Parts1.0.
Run OPENBLAS_NUM_THREADS=1 python replay_early.py, then replay_late.py, python compute.py, python verify.py, python generate_report.py. Original0.1–0.6 archives,0.7–0.10 code snapshots, common inputs, cross-stage results, bilingual reports and hashes are packaged. No new DOI or completed GitHub/Zenodo posting is asserted. This parts program remains separate from the upstream/downstream synthesis.
'''
(P/'WRRA_Parts_Followup_0_11_KO.txt').write_text(ko)
(P/'WRRA_Parts_Followup_0_11_EN.txt').write_text(en)
(P/'inputs.json').write_text(json.dumps(dict(stage='0.11',author='Wonsik Choi',arithmetic_cutoff=1000000,prime_neutron_labels=[5,47],assembly='K15 small order',finite_common_pool_B=1000000,reference_capture_over_beta_rate=100,reference_fusion_over_beta_rate=100,reference_time_s=180,conditional_micro_alignment=1/6,conditional_micro_attempt_q=.1,conditional_micro_flight_s=10,conditional_micro_cooling_per_s=.1,scope='distinct address, finite pool and selected-six-baryon denominators; no whole-pool spatial photon feedback inferred'),indent=2)+'\n')
(P/'requirements.txt').write_text('numpy\nscipy\n')
