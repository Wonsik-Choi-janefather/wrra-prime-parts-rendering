from pathlib import Path
import json
P=Path(__file__).resolve().parent
r=json.loads((P/'results.json').read_text()); x=r['reference']; v=json.loads((P/'verification.json').read_text())
ko=f'''WRRA 소수 부품 렌더링 후속 연구 0.12 — 유한 공동풀의 첫 광자 되먹임
저자: 최원식 / Wonsik Choi (단독) | ORCID 0009-0001-4263-9772
2026년 10월 4일 | 부품 계열, WRRA_M 상하류 통합과 별개

검증 입력 → WRRA 고유 변환 → 산출값 → 반증조건
검증 입력: 0.11의 K15 작은 우선 공동풀 B=1,000,000, 네 핵자 자리 Q=64,617, 180초 기준 융합 F={x['source_fusion_photons']:.9f}, 융합 후 남은 중수소 D={x['initial_deuterons']:.9f}, 공통 출처 에너지 {x['original_pool_energy_MeV']:.6f} MeV. 검증 질량·광자선·붕괴율은 0.6~0.9에서 승계한다. 선택 배치는 한 줄의 자리 간격 10광초, +x 방향만 이웃 표적에 정렬(6방향 중 하나), 10회 접촉 시도당 q=0.1, 냉각률 0.1초^-1, 흡수 이후 180초 반응이다.
WRRA 고유 변환: 각 자리에서 융합 F/Q, 잔류 중수소 D/Q의 인접 독립 주변확률을 배정한다. i번째 융합원에서 i+1번째 표적만 수신하며 마지막 광자는 탈출한다. 정렬·표적 존재·유한 접촉을 순서대로 적용하고, 실제 흡수만 광자 에너지에서 차감한다. 0.8 표적 상태 전이(X 뜨거운 np, A 냉각 np, B 베타 말단, H/D 재포획)를 풀 전체 기대수에 적용한다. 포획 광자, 휴지에너지, 베타·반동·냉각 에너지를 같은 출처 장부에 재기록한다.
산출값: 정렬하여 줄 안에 남은 광자 {x['aligned_photons_within_line']:.9f}건, 표적까지 있는 접촉 기회 {x['aligned_photons_with_target']:.9f}건, 실제 흡수 {x['absorbed_photons']:.9f}건, 재포획 {x['new_capture_photons']:.9f}건, 베타 말단 {x['target_beta_endpoint']:.9f}건. 중수소 기대수는 {x['initial_deuterons']:.9f}→{x['target_deuterons_after']:.9f}. 전체 광자 에너지는 {x['source_photon_MeV']:.9f}→{x['pool_photon_MeV_after']:.9f} MeV이고, 전체 장부는 {x['energy_before_MeV']:.9f}→{x['energy_after_MeV']:.9f} MeV다. 교차 장부 {r['passed']}/{r['total']}, 별도 대조 {v['passed']}/{v['total']} 통과.
반증조건: 출처 광자를 이중 사용하거나 표적을 중복 점유, 확률 합·바리온·에너지 불일치, q=0에서 비영 흡수, 고정 배치에서 실제 관측과 조건부 출력 불일치가 나타나면 이 구성은 기각·수정한다.

모형 구성과 판정 범위
이것은 전체 K15 유한풀에서 첫 세대 융합 광자와 이웃 표적의 기대수 반응을 계산한 조건부 공간 모형이다. 원래 공동풀의 F와 D를 사용하며 선택된 여섯 바리온 한 건의 흡수 확률을 공동풀 전체에 단순 곱하지 않는다. 인접 자리의 상태가 독립이라는 배치 주변확률과 180초 원천 상태를 고정한 뒤 광자 펄스를 보내는 시간 규칙은 새로 선언한 구성이다. 소수 표지로 물리 거리를 자동 유도했다는 주장은 없다. 네 핵자 자리 간 원자 수준 이동이 10광초를 수행한다고 가정하지 않는다. 공간 배치는 초기 준비이며 광자만 고정 광속으로 이동한다.
원천 광자 {x['source_fusion_photons']:.9f}건은 흡수 {x['absorbed_photons']:.9f}건과 탈출 {x['escaping_photons']:.9f}건으로 분할된다. 흡수된 융합 광자 한 건의 {r['cases'][0]['absorbed_energy_MeV']/r['cases'][0]['absorbed_photons'] if r['cases'][0]['absorbed_photons'] else 23.770682374952738:.9f} MeV는 표적 상태 변화와 새 포획 광자·환경으로 전달된다. 전체 에너지 장부는 원천 에너지와 일치한다. 첫 번째 단계의 새 포획 광자는 에너지·개수에 이미 반영했지만 그 광자를 또 다른 이웃으로 보내는 두 번째 공간 수송은 계산하지 않았다.
q=0, 0.1, 0.5, 1 및 냉각률 0.01, 0.1초^-1의 8개 구성에서 보존 검사를 통과했다. 수치 기대수는 단일 역사에서 분수 사건이 발생했다는 뜻이 아니다. 본문 수치는 선택한 조건에서 미측정 출력으로 사용할 수 있는 WRRA 조건부 예측이지만 배치와 독립 주변확률의 실험적 검증을 대신하지 않는다.

1.0 판정: 0.11의 미실행 공동풀 공간 연결 중 첫 세대 광자 수송과 표적 반응은 0.12에서 실제 계산했다. 동시 시간 진화, 이웃 점유의 상관, 새 포획 광자의 다음 수송, 다중 세대 재흡수까지 같은 출처 장부에서 돌린 결과는 아직 없다. 따라서 이 버전은 0.12 완료이며 완전한 시공간 되먹임을 뜻하는 부품 1.0은 아직 확정하지 않는다. 독립적인 새 물리 상수의 유도가 필수라는 뜻은 아니다.
재현: OPENBLAS_NUM_THREADS=1 python3 compute.py; python3 verify.py; python3 generate_report.py. 입력 파일과 코드·결과·한영 원고를 재현 묶음에 수록한다. 새 DOI나 공개 저장소 게시는 수행하지 않았다.
'''
en=f'''WRRA Prime Parts Rendering Followup 0.12 — First Photon Feedback Across a Finite Pool
Wonsik Choi (sole author) | ORCID 0009-0001-4263-9772 | October 4, 2026
Distinct from the WRRA_M upstream/downstream synthesis.

Verified inputs → WRRA-specific transformation → outputs → falsifiers
Inputs: inherited K15 small-first common pool B=1,000,000, Q=64,617 quartet sites, fusion expectation F={x['source_fusion_photons']:.9f}, residual deuteron expectation D={x['initial_deuterons']:.9f} at 180 s, and source energy {x['original_pool_energy_MeV']:.6f} MeV. The declared spatial preparation places sites on a line ten light-seconds apart; one of six photon directions points to the next site. There are ten Bernoulli contacts with q=.1; the target then relaxes for 180 s at cooling rate .1/s.
Transformation: Assign adjacent-site independent marginal occupancies F/Q and D/Q. Each source i can address distinct target i+1; the last source exits. Apply direction, occupancy and finite contacts, consume only absorbed photons, and evolve the target through the five states from stage 0.8. Reallocate rest, beta, photon, recoil and bath energies in the same pool ledger.
Outputs: {x['aligned_photons_with_target']:.9f} aligned photons have a deuteron target; {x['absorbed_photons']:.9f} absorb; {x['new_capture_photons']:.9f} recapture; {x['target_beta_endpoint']:.9f} reach beta endpoint. Pool deuterons change {x['initial_deuterons']:.9f}→{x['target_deuterons_after']:.9f}. Photon energy changes {x['source_photon_MeV']:.9f}→{x['pool_photon_MeV_after']:.9f} MeV. The complete pool energy remains {x['energy_after_MeV']:.9f} MeV. Internal checks {r['passed']}/{r['total']}; separate arithmetic checks {v['passed']}/{v['total']}.
Falsifiers: duplicated source consumption or targets, failure of probability/baryon/energy conservation, absorption at q=0, or observational disagreement under the fixed preparation.

This is a first-generation conditional pool-wide spatial feedback calculation. Site independence, the pulse following the frozen 180 s source population, and spatial placement are explicit model choices. Prime tags do not imply positions; baryons do not travel ten light-seconds. Photon flight is at fixed c. The expected fractional event counts describe an ensemble. Eight choices (q=0,.1,.5,1; cooling=.01,.1/s) pass the conservation and null controls. A new capture photon enters the energy ledger but does not undergo a second transport pass. Correlated target occupancies, simultaneous production and transport, and secondary photon reabsorption remain uncomputed. Accordingly 0.12 is complete, while full spatiotemporal Parts 1.0 is not certified. Calibrated constants are legitimate inputs, and an independent new prediction is not required for the model's structural contribution.

Reproduce: OPENBLAS_NUM_THREADS=1 python3 compute.py; python3 verify.py; python3 generate_report.py. No new DOI or public repository publication is claimed.
'''
(P/'WRRA_Parts_Followup_0_12_KO.txt').write_text(ko)
(P/'WRRA_Parts_Followup_0_12_EN.txt').write_text(en)
