from pathlib import Path
import csv,json,math
P=Path(__file__).resolve().parent
r=json.loads((P/'results.json').read_text()); old=json.loads((P/'source_0_11_results.json').read_text())
x=r['reference']; Q=64617; F=old['numeric_links']['K15_pool_fusion_count']; C=old['numeric_links']['K15_pool_capture_count']; D=C-2*F
checks={
 'source_fusion':abs(x['source_fusion_photons']-F)<1e-8,
 'target_pool':abs(x['initial_deuterons']-D)<1e-8,
 'spatial_matches':abs(x['aligned_photons_with_target']-F*(Q-1)*D/(6*Q*Q))<1e-8,
 'bernoulli_absorption':abs(x['absorbed_photons']-x['aligned_photons_with_target']*(1-.9**10))<1e-8,
 'photon_partition':abs(x['absorbed_photons']+x['escaping_photons']-F)<1e-8,
 'target_partition':abs(sum(x[k] for k in ('target_hot_np','target_cold_np','target_beta_endpoint','target_recaptured_hot_d','target_recaptured_cold_d'))-x['absorbed_photons'])<1e-8,
 'target_d':abs(x['target_deuterons_after']-(D-x['absorbed_photons']+x['new_capture_photons']))<1e-8,
 'source_absolute_energy':abs(x['energy_before_MeV']-old['numeric_links']['K15_pool_common_source_MeV'])<1e-5,
 'energy_conserved':abs(x['energy_after_MeV']-x['energy_before_MeV'])<1e-5,
 'bounds':0<x['absorbed_photons']<D and 0<x['target_deuterons_after']<D,
 'null_control':all(z['absorbed_photons']==0 and z['target_deuterons_after']==D for z in r['cases'] if z['q']==0),
 'coupling_monotone':all(a['absorbed_photons']<=b['absorbed_photons'] for a,b in zip([z for z in r['cases'] if z['cooling_s_inv']==.1][:-1],[z for z in r['cases'] if z['cooling_s_inv']==.1][1:])),
}
assert all(checks.values()),checks
(P/'verification.json').write_text(json.dumps({'checks':checks,'passed':sum(checks.values()),'total':len(checks)},indent=2)+'\n')
print(f"independent checks: {sum(checks.values())}/{len(checks)}")
