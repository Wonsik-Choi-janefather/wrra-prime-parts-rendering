"""0.12 finite K15 spatial ensemble, with an explicitly declared pulse clock.

All 64,617 quartet sites lie on a line separated by ten light seconds. A
fusion photon can reach only the next site on its +x ray. The other five
directions escape. Marginal fusion/deuteron occupancies at adjacent sites are
independent by preparation, so this is an ensemble calculation, not a claim
about an observed configuration or an exact correlated microstate.
"""
from pathlib import Path
import csv, hashlib, json, math
import numpy as np
from scipy.linalg import expm

HERE=Path(__file__).resolve().parent
R=json.loads((HERE/'source_0_6_results.json').read_text())
OLD=json.loads((HERE/'source_0_11_results.json').read_text())
with (HERE/'source_0_6_release_grid.csv').open() as f:
 rows=list(csv.DictReader(f))
base=next(z for z in rows if z['mode']=='finite_pool' and z['K']=='15' and z['order']=='small' and all(float(z[k])==v for k,v in [('capture_ratio',100),('fusion_ratio',100),('time_s',180),('eta',0)]))
f=lambda k:float(base[k])
Q=int(OLD['numeric_links']['K15_pool_initial_quartets'])
F=f('fusion_events'); C=f('capture_events'); D=C-2*F
assert 0<D<Q and 0<F<Q and Q==64617
m=R['inherited_masses_MeV']; n,p,e,d=(m[x] for x in ('neutron','proton','electron','deuteron'))
qb=n-p-e; gc=R['nuclear_lines']['capture']['photon_MeV']; tc=R['nuclear_lines']['capture']['recoil_MeV']; gf=R['nuclear_lines']['fusion']['photon_MeV']
K=gf-(n+p-d)
T0=np.array([d+e,qb,gc,0,tc])
TL=np.array([[n+p+e,qb,gc,K,tc],[n+p+e,qb,gc,0,tc+K],
 [2*p+2*e,2*qb,gc,0,tc+K],[d+e,qb,2*gc,tc,tc+K],
 [d+e,qb,2*gc,0,2*tc+K]])
assert abs(T0.sum()-2*n)<1e-8
assert all(abs(x.sum()-T0.sum()-gf)<1e-8 for x in TL)

def kernel(cooling,elapsed):
 g=np.zeros((5,5))
 for i,j,rate in [(0,1,cooling),(1,2,1/878.3),(1,3,100/878.3),(3,4,cooling)]:
  g[i,j]+=rate;g[i,i]-=rate
 return np.eye(5)[0]@expm(g*elapsed)

def run(q=.1,cooling=.1,elapsed=180):
 # At t=180 the 0.6 population is frozen for a photon pulse. Ten light
 # seconds of flight, then 10 independent contact trials. Fate is read after
 # elapsed seconds following absorption; no later secondary-photon transport.
 q_eff=1-(1-q)**10
 # Each emitter i=0..Q-2 points to distinct target i+1. The last exits.
 # Marginals F/Q and D/Q have their initial-pool quartet denominator.
 directional=F*(Q-1)/Q/6
 aligned_target=directional*D/Q
 absorbed=aligned_target*q_eff
 missing_target=directional-aligned_target
 escaped=F-directional+missing_target+aligned_target*(1-q_eff)
 outcome=kernel(cooling,elapsed)*absorbed
 target_d_after=D-absorbed+outcome[3]+outcome[4]
 component_change=outcome@TL-absorbed*T0
 source_gamma_before=f('total_photon_MeV')
 before=np.array([f('active_rest_MeV')+f('protected_storage_MeV'),
                 f('electron_kinetic_MeV')+f('antinu_energy_MeV'),
                 source_gamma_before,
                 f('capture_recoil_cooling_MeV')+f('fusion_recoil_cooling_MeV')+f('beta_proton_cooling_MeV')])
 # Correction is allocated by the 0.8 target ledger: rest, beta nonrest,
 # photons, hot recoil and bath. Gamma consumption is separate.
 after=before.copy(); after[0]+=component_change[0]
 after[1]+=component_change[1]
 after[2]+=component_change[2]-gf*absorbed
 after[3]+=component_change[3]+component_change[4]
 return dict(q=q,cooling_s_inv=cooling,response_time_s=elapsed,sites=Q,
  source_fusion_photons=F,initial_deuterons=D,source_photon_MeV=source_gamma_before,
  aligned_photons_within_line=directional,aligned_photons_with_target=aligned_target,
  absorbed_photons=absorbed,escaping_photons=escaped,
  photon_partition_residual=F-absorbed-escaped,
  target_hot_np=float(outcome[0]),target_cold_np=float(outcome[1]),
  target_beta_endpoint=float(outcome[2]),target_recaptured_hot_d=float(outcome[3]),
  target_recaptured_cold_d=float(outcome[4]),target_deuterons_after=target_d_after,
  new_capture_photons=outcome[3]+outcome[4],
  absorbed_energy_MeV=gf*absorbed,
  pool_photon_MeV_after=float(after[2]),
  pool_rest_and_storage_MeV_after=float(after[0]),
  pool_beta_nonrest_MeV_after=float(after[1]),
  pool_recoil_and_bath_MeV_after=float(after[3]),
  energy_before_MeV=float(before.sum()),energy_after_MeV=float(after.sum()),
  energy_residual_MeV=float(after.sum()-before.sum()),
  target_state_residual=float(outcome.sum()-absorbed),
  baryon_residual=float(2*D-2*(D-absorbed+outcome[3]+outcome[4])-2*sum(outcome[:3])),
  photon_fate_MeV=float(gf*escaped),
  original_pool_energy_MeV=f('common_source_MeV'))

cases=[run(q,c) for q in (0,.1,.5,1) for c in (.01,.1)]
checks={}
for a in cases:
 for k,v,limit in [('photon_partition',a['photon_partition_residual'],1e-8),
                   ('target_states',a['target_state_residual'],1e-8),
                   ('baryons',a['baryon_residual'],1e-8),
                   ('energy',a['energy_residual_MeV'],1e-5)]:
  checks[f"q={a['q']},c={a['cooling_s_inv']}:{k}"]=abs(v)<limit
 checks[f"q={a['q']},c={a['cooling_s_inv']}:bounds"]=(0<=a['absorbed_photons']<=D and 0<=a['target_deuterons_after']<=D and a['pool_photon_MeV_after']>=0)
checks['zero_contact_zero_feedback']=all(a['absorbed_photons']==0 for a in cases if a['q']==0)
checks['same_source']=abs(F-OLD['numeric_links']['K15_pool_fusion_count'])<1e-8
checks['same_total']=abs(f('common_source_MeV')-OLD['numeric_links']['K15_pool_common_source_MeV'])<1e-6
checks['absolute_initial_energy']=all(abs(a['energy_before_MeV']-a['original_pool_energy_MeV'])<1e-5 for a in cases)
assert all(checks.values()),[k for k,v in checks.items() if not v]
result=dict(version='0.12',author='Wonsik Choi',construction='finite-line adjacent-quartet ensemble; 180 s parent population then ten-light-second pulse and 180 s target relaxation',
 inputs=dict(Q=Q,F=F,D=D,axis_count=6,spacing_light_seconds=10,contact_attempts=10,independent_neighbor_marginals=True,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in HERE.glob('source_*')}),
 cases=cases,reference=next(a for a in cases if a['q']==.1 and a['cooling_s_inv']==.1),
 checks=checks,passed=sum(checks.values()),total=len(checks),
 scope='Full finite-pool expected first-generation photon-target response for declared spatial ensemble and pulse. Not a simultaneous time-resolved many-photon coupled dynamics; secondary capture photons are accounted in energy but not re-routed.')
(HERE/'results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'absorbed':result['reference']['absorbed_photons'],'deuteron_after':result['reference']['target_deuterons_after'],'checks':result['passed']}))
